# includeDirectories.py - Class for getting all of the 
#  include directories from within a directory
#
# G. Robinson (AE-BE/ENG3)
# 25-09-2008
#
# Revision history:
#
# Version 001.00 - 25.09.2008 - G. Robinson (AE-BE/ENG3)
#   Initial revision.
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 002.00 - 07.04.2010 - C. Baudry (AE-BE/ENG3)
# - The environment variable is splited in 2, it can be too big for windows (max 8192 bytes)
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 002.01 - 15.12.2011 - C. Baudry (AE-BE/ENG3)
# - The environment variable is splited in 4, it can be too big for windows (max 8192 bytes)
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 002.02 - 06.07.2012 - C. Baudry (AE-BE/ENG3)
# - Dynamically create the environment variables
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 002.03 - 19.11.2012 - C. Baudry (AE-BE/ENG3)
# - Correct max tested len for the env variables
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 002.04 - 23.06.2014 - C. Baudry (AE-BE/ENG3)
# - Add comment after change from A. Krasnych: the command max lenght has been reduced to 8100 because of problems with 8191
#--------------------------------------------------------------------------------------------------------------------------------------

''' required for directory listings and executing etc '''
import os

''' required for system arguments '''
import sys


''' Class for the complete projects resources '''
class IncludeDirectories:

    def __init__(self, outputFile, subDirectories):
        
        self.setCommandNumber = 1
        __setCommandTmp = "SET BCMF_INCLUDES_" + str(self.setCommandNumber) + "="
        __wholeSetCommandTmp = ""
        
        ''' we create in this loop as many environment variables as required '''
        ''' the maximal size of an environment variable is 8192 bytes '''
        for dir in subDirectories:
        
            # the len test is done with 8100 (it should be smaller than 8192, 8191 has shown problems)
            if((len(__setCommandTmp) + len(dir)) < 8100):
                __setCommandTmp = __setCommandTmp + dir + ";" 
            else:
                ''' the current variable is full, incrementation for the next one '''
                self.setCommandNumber = self.setCommandNumber + 1
                
                __wholeSetCommandTmp = __wholeSetCommandTmp + __setCommandTmp
                __setCommandTmp = "\nSET BCMF_INCLUDES_" + str(self.setCommandNumber) + "=" + dir + ";"

        ''' at the end of the loop, the tmp variable is written in the batch file '''
        __wholeSetCommandTmp = __wholeSetCommandTmp + __setCommandTmp
        __output_file = open(outputFile, 'w')
        print >> __output_file, __wholeSetCommandTmp
        __output_file.close()
        
        
    def GetSetCommandNumber(self):
            
        return self.setCommandNumber
        

        
if __name__ == '__main__':

    actualProject = IncludeDirectories(sys.argv[1], sys.argv[2], sys.argv[3:])
