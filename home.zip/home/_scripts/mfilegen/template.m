classdef(Enumeration) _TYPENAME_ < Simulink.IntEnumType
    % Linked enum typedef from Can API headerfile
  enumeration
_ENUMVALUES_  end
  methods (Static = true)
    function retVal = getHeaderFile()
      retVal = '_HEADERNAME_';
    end
  end
end
