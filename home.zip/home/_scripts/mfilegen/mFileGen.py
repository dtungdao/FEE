# mFileGen.py - Class for generating m files for simulink aout of CAN headers
#
# S.Weber (AE-BE/ENG31-AU)
# 14-01-2010
#
# Revision history:
#
# Version 001.00 - 14.01.2010 - S. Weber (AE-BE/ENG31-AU)
#   Initial revision.
# Version 001.10 - 20.01.2010 - S. Weber (AE-BE/ENG31-AU)
#   remove comments from the header file data before parsing it,
#   that way commented out typedefs are not used
# Version 001.20 - 11.02.2010 - S. Weber (AE-BE/ENG31-AU)
#   handle case sensitivity in filenames - cleartool is case-sensitive
#   handle more than on headerpath
#

''' required for system arguments '''
import sys

''' import subprocess for executing commands '''
import subprocess

''' import re for regular expressions '''
import re

''' import time for time features '''
import time

''' import os for reading user details '''
import os

'''import filename match unix style'''
import fnmatch

''' import the configuration file handler '''
from configFile import ConfigFile

''' config file definitions '''
CFG_MGEN_HEADERPATHS = "MGEN_HEADERPATHS"
CFG_MGEN_OUTPATH     = "MGEN_OUTPATH"
CFG_MGEN_TEMPLATE    = "MGEN_TEMPLATE"
CFG_MGEN_LOGFILE     = "MGEN_LOGFILE"


''' class for the tools versions '''
class MFileGen:

    def __init__(self):
        pass

    def MFileGenerate(self, configuration_file):

        changedFilesList = []
        newFilesList = []
        unchangedFilesList = []
        obsoleteFilesList = []

        ''' read the configurations from the configuration file '''
        configuration = ConfigFile(configuration_file).ConfigDictionary()
        #for key in configuration:
        #    print "key: %s; value: %s", key, configuration[key]

        ''' get the configuration items '''
        headerPaths = configuration[CFG_MGEN_HEADERPATHS]
        outputPath = configuration[CFG_MGEN_OUTPATH]
        templateFile = configuration[CFG_MGEN_TEMPLATE]
        logFile = configuration[CFG_MGEN_LOGFILE]

        sepHeaderPaths = headerPaths.split(';')

        try:
            templateFileHandle = open(templateFile, 'r')
            templateFileData = templateFileHandle.read()

            ''' check out the file '''
            command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + logFile
            subprocess.call(command_string)
            logFileHandle = open(logFile, 'w')

        except IOError:
            error_message = "Problem opening the template file!"
            print "Error:"
            print error_message
            ''' stop the program as this error is fatal '''
            return

        '''go through all the given headerfiles'''
        errFlag = False
        for index in range(len(sepHeaderPaths)):
            try:
                ''' open the header file '''
                headerFileName = sepHeaderPaths[index]
                headerFileHandle = open(headerFileName, 'r')
                headerFileData = headerFileHandle.read()
            except IOError:
                error_message = "Problem opening the header file %s!" % headerFileName
                print "Error:"
                print error_message
                errFlag = True
                ''' stop the program as this error is fatal '''
                break


            '''first remove all comments as we don't want any commented out typedefs'''
            #print "\nSearching now for comments with /**/...\n"
            searchexpr = re.compile('/\*.*?\*/',re.DOTALL)
            searchok = True
            while (searchok == True):
                searchresult = re.search(searchexpr, headerFileData)
                if searchresult != None:
                    #print searchresult.group(0)
                    headerFileData = headerFileData.replace(searchresult.group(0), "")
                else:
                    searchok = False
            #print "\nSearching now for comments with //...\n"
            searchexpr = re.compile('//.*?\n',re.DOTALL)
            searchok = True
            while (searchok == True):
                searchresult = re.search(searchexpr, headerFileData)
                if searchresult != None:
                    #print searchresult.group(0)
                    headerFileData = headerFileData.replace(searchresult.group(0), "")
                else:
                    searchok = False

            '''split the whole thing into units using the semicolon'''
            headerFileList = headerFileData.split(';')
            for codeSnippet in headerFileList:
                #print codeSnippet
                enumString = ""
                '''check if its a typedef enum'''
                if "typedef enum" in codeSnippet:
                    '''look for the type name. This should be the last name at the end and after a closing bracket'''
                    searchexpr = re.compile('(\w+)($)')
                    enumType = re.search(searchexpr, codeSnippet).group(1)
                    #print "enumType: " + enumType
                    '''then look for the enum values. They are between {} brackets'''
                    searchexpr = re.compile('(.*)({)(.*)(})(.*)',re.DOTALL)
                    allEnumValues = re.search(searchexpr, codeSnippet).group(3)
                    #print "allEnumValues: " + allEnumValues
                    allEnumValuesList = allEnumValues.split(',')

                    '''ideally, the line looked like this: "value_name = value"
                       but it could be the enum is all in one line or formatted differently'''
                    indexValue = 0
                    for element in allEnumValuesList:
                        #print "element: " + element
                        searchexpr=re.compile('(\W*)(\w+)(\s*)(=*)(\s*)(\d*)(\W*)')
                        searchresult = searchexpr.search(element)
                        '''if it does fit our pattern'''
                        if searchresult != None:
                            enumValueName = searchresult.group(2)
                            #print "enumValueName: " + enumValueName
                            if element.find('=') != -1:
                                enumValue=int(searchresult.group(6),10)
                            else:
                                enumValue=indexValue
                            #print "enumValue: " + str(enumValue)

                            '''increase the index'''
                            indexValue = enumValue+1
                            '''now compile the string for the m file'''
                            mfileString = "    " + enumValueName + "(" + str(enumValue) + ")\n"
                            enumString = enumString + mfileString
                            '''there was other stuff in that line, like { or ;, but nothing of
                            interest to us'''
                        else:
                            pass

                    '''now create the m file'''
                    '''replace the keywords in the template file string with our stuff'''
                    newMFileString = templateFileData
                    #print newMFileString
                    '''get just the haderfilename'''
                    headerFileNameShort =os.path.split(headerFileName)[1]
                    newMFileString = newMFileString.replace('_TYPENAME_', enumType)
                    newMFileString = newMFileString.replace('_ENUMVALUES_', enumString)
                    newMFileString = newMFileString.replace('_HEADERNAME_', headerFileNameShort)
                    #print newMFileString
                    '''determine the filename'''
                    MFileName = outputPath + enumType + ".m"
                    MFileNameShort = enumType + ".m"
                    #rint MFileNameShort
                    fileExists = False
                    '''does the file exist already?'''
                    '''check if the case is correct too! Cleartool is case sensitive...'''
                    for file in os.listdir(outputPath):
                        if fnmatch.fnmatchcase(file, MFileNameShort):
                            #print "found it!"
                            fileExists = True
                            '''check if the contents of the file and the new string are identical'''
                            MFileHandle = open(MFileName, 'r')
                            MFileContents = MFileHandle.read()
                            if MFileContents != newMFileString:
                                MFileHandle.close()
                                '''checkout and open again'''
                                ''' check out the file '''
                                command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + MFileName
                                subprocess.call(command_string)
                                MFileHandle = open(MFileName, 'w')
                                MFileHandle.write(newMFileString)
                                MFileHandle.close()
                                changedFilesList.append(MFileNameShort)
                            else:
                                '''do nothing, the file does not have to be changed'''
                                unchangedFilesList.append(MFileNameShort)
                            break
                        else:
                            '''filename might be the same the same but different case, so we'll have to check again to
                               find and rename the old file and then create a new one'''
                            if fnmatch.fnmatch(file, MFileNameShort):
                                '''check out the directory'''
                                command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + outputPath
                                subprocess.call(command_string)
                                '''rename the file'''
                                oldFileName = outputPath + file
                                newFileName = outputPath + "\\x" + file
                                command_string = "cleartool mv " + oldFileName + " " + newFileName
                                subprocess.call(command_string)

                    if  fileExists == False:
                        '''opening the file will create a new view private file'''
                        MFileHandle = open(MFileName, 'w')
                        MFileHandle.write(newMFileString)
                        MFileHandle.close()
                        print "new File: " + MFileNameShort
                        newFilesList.append(MFileNameShort)

        if errFlag == True:
            print "Generation aborted"
            return

        '''parse through the directory and find out which files are now obsolete'''
        for fileRoot, fileDirs, fileList in os.walk(outputPath):
            for file in fileList:
                if file[-2:] == ".m":
                    if file in changedFilesList:
                        pass
                    else:
                        if file in unchangedFilesList:
                            pass
                        else:
                            if file in newFilesList:
                                pass
                            else:
                                fileName = outputPath + file
                                ''' check out the file '''
                                command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + fileName
                                subprocess.call(command_string)
                                fileHandle = open(fileName, 'w')
                                fileHandle.write("")
                                fileHandle.close()
                                obsoleteFilesList.append(file)

        '''generate the log file'''
        logFileString = "Changed files:\n"
        for file in changedFilesList:
            logFileString = logFileString + "\t" + file + "\n"
        logFileString = logFileString + "New files:\n"
        for file in newFilesList:
            logFileString = logFileString + "\t" + file + "\n"
        logFileString = logFileString + "Unchanged files:\n"
        for file in unchangedFilesList:
            logFileString = logFileString + "\t" + file + "\n"
        logFileString = logFileString + "Obsolete files:\n"
        for file in obsoleteFilesList:
            logFileString = logFileString + "\t" + file + "\n"

        logFileHandle.write(logFileString)

        '''housekeeping'''
        logFileHandle.close()
        headerFileHandle.close()
        templateFileHandle.close()


if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        test_class = MFileGen()
        test_class.MFileGenerate(sys.argv[1])

    except IndexError:

        error_message = "Usage: python ecuversion.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
