# Rb_QacWarningsNotifier.py
#
# C. Baudry (AE_BE/ENG3)
# 15.07.2013
#
# Description:
#   This script parses the QAC warnings summary.
#   It looks for the files responsibles in the PAD and
#   creates a warning report for each found user.
#   It creates a result log file and an error log file. The error log file 
#   can be printed out on the console.
#
# Parameters:
# - 1 - QAC summary
# - 2 - Project database (xlsx)
# - 3 - Linked workspace where the QAC output is
# - 4 - Print error log on console
#           "Yes"
#           "No"
# - 5 - QAC start level
#           0 -> 9 
#
# Other inputs which are not parameters
# - Notifier configuration file configNotifications.txt
#
# Outputs:
# - error log
# - results log with all warnings
# - results log per user
#
# Open points:
# - see TODO
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 15.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 19.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Remove the general message: it is done in the mail sender module 
#   Add a title in the module message
#---------------------------------------------------------------------------
# Version 003.00 - 22.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Send the email with html format: the paddings are not required anymore 
#---------------------------------------------------------------------------
# Version 003.01 - 23.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Highlight the QAC warnings above the configured threshold
#---------------------------------------------------------------------------
# Version 003.02 - 10.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Comments fixes
#---------------------------------------------------------------------------
# Version 003.03 - 18.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - Add a check for the project analysis database version
#   - Modify the mail general text
#---------------------------------------------------------------------------
# Version 003.04 - 14.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 003.05 - 16.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#   - Remove database checks: done in the database manager
#---------------------------------------------------------------------------
# Version 003.06 - 18.02.2014 -  C. Baudry (AE-BE/ENG3)
#   - Correct comment for the QAC level
#---------------------------------------------------------------------------
# Version 004.00 - 04.08.2014 -  C. Baudry (AE-BE/ENG3)
#   - Remove possibility to send a mail: done by the notification manager
#   - The listed source files in the mail are setup as link to the Jenkins
#     workspace
#   - Add a parameter which contain the workspace address used for the links
#   - Modify the way the log files are handled: the env var WORKSPACE has to 
#     exist, the scrip does no check that anymore
#---------------------------------------------------------------------------
# Version 004.01 - 04.08.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add explanations in the mail
#---------------------------------------------------------------------------


''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' csv functions '''
import csv
import operator

''' Excel 2007 library '''
import openpyxl

import shutil


if __name__ == '__main__':

    ''' inits '''
    __inputSummaryFile     = sys.argv[1]
    __inputProjectDatabase = sys.argv[2]
    __inputLinkedWorkspace = sys.argv[3]
    __printErrorLog        = sys.argv[4]
    __startLevel           = int(sys.argv[5])
    __columnFile           = 0 
    __columnResponsibleID  = 3
    __strErrorLog = "\n"
    __strResultsLog = ""
    __userList = []
    __tempUserList = []
    __tempOutpath          = os.environ.get("BCMF_TEMP_OUT")
    __sofwarePath          = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolchainConfigPath  = os.environ.get("BCMF_CFG_ROOT")
    __outputFileName       = "QacWarningsNotifierResults.txt"
    __qacWarningsPerLevel  = range(10)
    __levelDict            = {}
    
    __mailMessageModule    = "<hr><B><U>QAC warnings notifications</U></B><br><br>For this project the QAC warnings from level %s have to be removed. The following listed files contain warnings from level %s.<br><br>\
    Warnings details:<br>\
    - Source files: You can directly access to the QAC html reports clicking on the files name in the table below.<br>\
    - Header files: A QAC module analysis of the related module has to be done via the BCMF GUI<br>\
    You can find the warnings of a given level searching with your browser the following pattern (e.g. for level 3): Msg(3" % ( str(__startLevel),str(__startLevel) )
        
    
    ''' get environment config '''
    # read the config file to get the current output path
    try:
        __configFileHandler = open(__tempOutpath + "\\configNotifications.txt")
        __tempOutPath = __configFileHandler.read()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the config file " + __tempOutpath + "\\configNotifications.txt!!\n")
    
        
    ''' parse the QAC summary file '''
    try:
        __summaryFileHandler = open(__inputSummaryFile)
        __summaryFileContent = __summaryFileHandler.readlines()
        __summaryFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the QAC summary file " + __inputSummaryFile + "!!\n")
    
    
    ''' parse the project databases '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_QacWarningsNotifier.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' Default user is used in case no responsible is defined '''
    __userDefault = __worksheetGeneral.cell('B3').value
    
    
    ''' create a csv file containing all required information '''
    ''' format: fileName, warnings level 9-0, user '''
    with open(__tempOutPath + '\\QacWarningsNotifier.csv', 'wb') as csvfile:
        __csvWritter = csv.writer(csvfile, delimiter=';', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        
        for __line in __summaryFileContent:
            
            # check if the line is valid: first element should be a c or a h file, if not OK, skip this line
            if re.search("^\S+\.(c|h)",__line):
            
                __lineFound = __line.split()
                
                # get the file name
                __fileName = __lineFound[0]
                
                # get the warnings per level
                for index in range(len(__qacWarningsPerLevel)):
                    __qacWarningsPerLevel[index] = __lineFound[10-index]
                
                ''' get the file responsible from the project analysis database '''
                # if no responsible is found the default user is used (has to be configured in the database)
                __found = False
                __rowNumber = 0
                
                # first check in the sources database
                for __row in __worksheetDatabaseSources.rows:
                    __rowNumber += 1
                    # database and QAC warnings summary comparison
                    # -> compare only the file name
                    if __fileName.lower() == os.path.basename(__row[__columnFile].value).lower():
                        # case the responsible cell is empty
                        if __row[__columnResponsibleID].value == None:
                            __userList.append(__userDefault)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __userDefault])
                            __strErrorLog += "-- QAC Warnings Notifier warning: Responsible not given in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                        # case the responsible cell contains non-word characters
                        elif re.search("\W",__row[__columnResponsibleID].value):
                            __userList.append(__userDefault)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __userDefault])
                            __strErrorLog += "-- QAC Warnings Notifier warning: Responsible synthax not correct in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                        # good case
                        else:
                            __userList.append(__row[__columnResponsibleID].value)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __row[__columnResponsibleID].value])
                        __found = True
                
                # then check in the headers database
                __rowNumber = 0
                for __row in __worksheetDatabaseHeaders.rows:
                    __rowNumber += 1
                    # database and QAC warnings summary comparison
                    # -> compare only the file name
                    if __fileName.lower() == os.path.basename(__row[__columnFile].value).lower():
                        # case the responsible cell is empty
                        if __row[__columnResponsibleID].value == None:
                            __userList.append(__userDefault)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __userDefault])
                            __strErrorLog += "-- QAC Warnings Notifier warning: Responsible not given in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                        # case the responsible cell contains non-word characters
                        elif re.search("\W",__row[__columnResponsibleID].value):
                            __userList.append(__userDefault)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __userDefault])
                            __strErrorLog += "-- QAC Warnings Notifier warning: Responsible synthax not correct in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                        # good case
                        else:
                            __userList.append(__row[__columnResponsibleID].value)
                            __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                               __qacWarningsPerLevel[1],
                                                               __qacWarningsPerLevel[2],
                                                               __qacWarningsPerLevel[3],
                                                               __qacWarningsPerLevel[4],
                                                               __qacWarningsPerLevel[5],
                                                               __qacWarningsPerLevel[6],
                                                               __qacWarningsPerLevel[7],
                                                               __qacWarningsPerLevel[8],
                                                               __qacWarningsPerLevel[9],
                                                               __row[__columnResponsibleID].value])
                        __found = True                
                
                if __found == False:
                    # if the file containing a QAC warning has not been found, the warning is communicated to the default user
                    __userList.append(__userDefault)
                    __csvWritter.writerow([__fileName, __qacWarningsPerLevel[0],
                                                       __qacWarningsPerLevel[1],
                                                       __qacWarningsPerLevel[2],
                                                       __qacWarningsPerLevel[3],
                                                       __qacWarningsPerLevel[4],
                                                       __qacWarningsPerLevel[5],
                                                       __qacWarningsPerLevel[6],
                                                       __qacWarningsPerLevel[7],
                                                       __qacWarningsPerLevel[8],
                                                       __qacWarningsPerLevel[9],
                                                       __userDefault])
                    __strErrorLog += "-- QAC Warnings Notifier warning: File %s not found in the databases\n    --> Default user used for notification\n" % __fileName
                
        
    
    # sort the user list alphabetically and remove the doubles
    for __user in __userList:
        try:
            ind = __tempUserList.index(__user)
        except:
            __tempUserList.append(__user)
    __userList = __tempUserList
    __userList.sort()
   
    
    ''' create a QAC warning report per user '''
    for __user in __userList:
        
        __strResultsUser = "<FONT FACE='Arial' SIZE=-1>%s<br><br>" % __mailMessageModule
        __userMail = ""
        __found = False
        __userNotificationRequired = False
        __highlightStr = ""
        
        # if not already done: create a folder especially for the user with as name the user id
        __tempUserFolder = __tempOutPath + "\\" + __user
        if not os.path.exists(__tempUserFolder):
            os.makedirs(__tempUserFolder)
        
        #colums names
        __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th width='50'>9</th><th width='50'>8</th><th width='50'>7</th><th width='50'>6</th><th width='50'>5</th><th width='50'>4</th><th width='50'>3</th><th width='50'>2</th><th width='50'>1</th><th width='50'>0</th></tr>"
        
        with open(__tempOutPath + '\\QacWarningsNotifier.csv', 'rb') as csvfile:
            __csvReader = csv.reader(csvfile, delimiter=';', quotechar='|')
            for __currentFileName, __levelDict["__currentQacLevel_0"], \
                                   __levelDict["__currentQacLevel_1"], \
                                   __levelDict["__currentQacLevel_2"], \
                                   __levelDict["__currentQacLevel_3"], \
                                   __levelDict["__currentQacLevel_4"], \
                                   __levelDict["__currentQacLevel_5"], \
                                   __levelDict["__currentQacLevel_6"], \
                                   __levelDict["__currentQacLevel_7"], \
                                   __levelDict["__currentQacLevel_8"], \
                                   __levelDict["__currentQacLevel_9"], \
                                   __currentUser in __csvReader:
                
                if __user == __currentUser:
                    
                    # create the report string if the user has warnings in the prohiben levels
                    for index in range(__startLevel,10):
                        __corruptedFile = False
                        try:
                            if int(__levelDict["__currentQacLevel_" + str(index)]) > 0:
                                __userNotificationRequired = True
                                __corruptedFile = True
                                break
                        except:
                            pass
                    
                    if __corruptedFile == True:
                        # create a link to the analysed file (only for c files)
                        if re.search("\.c", __currentFileName):
                            __strResultsUser += "<tr><td align='left'><a href='%s/%s.html'>%s</a></td>" % (__inputLinkedWorkspace,__currentFileName,__currentFileName)
                        else:
                            __strResultsUser += "<tr><td align='left'>%s</td>" % __currentFileName
                        for index in range(10):
                            # highlight the QAC warnings above the configured threshold
                            if 9-index >= __startLevel:
                                if int(__levelDict["__currentQacLevel_" + str(9-index)]):
                                    __highlightStr = "bgcolor='#BDBDBD'"
                            __strResultsUser += "<td %s align='center'>%s</td>" % (__highlightStr,__levelDict["__currentQacLevel_" + str(9-index)])
                            __highlightStr = ""
                        __strResultsUser += "</tr>"
                        
        
        # user notification if required
        if __userNotificationRequired == True:
        
            __strResultsUser += "</table><br><br><br></FONT>"
            __strResultsLog  += __strResultsUser 
            
            try:
                __tempFileHandler = open(__tempUserFolder + "\\" + __outputFileName, 'w')
                __tempFileHandler.write(__strResultsUser)
                __tempFileHandler.close()
                print "-- QAC Warnings Notifier: create a warning list for user %s" % __user
            except:
                raise Exception("ERROR: Impossible to create the QAC Warnings Notifier results user file!!\n")
    
    
    ''' results log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\QacWarningsNotifierResultsLog.html", 'w')
        __tempFileHandler.write(__strResultsLog)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the QAC Warnings Notifier results log file!!\n")
    # copy the log file into the Jenkins workspace. The WORKSPACE variable has to exist
    shutil.copy(__tempOutPath + "\\QacWarningsNotifierResultsLog.html", os.environ.get("WORKSPACE"))
        
        
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\QacWarningsNotifierErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the QAC Warnings Notifier error log file!!\n")
    # copy the log file into the Jenkins workspace. The WORKSPACE variable has to exist
    shutil.copy(__tempOutPath + "\\QacWarningsNotifierErrorLog.txt", os.environ.get("WORKSPACE"))
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    ''' end of file '''
