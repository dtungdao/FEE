# Rb_BCMF_2_RunQAC.py
#
# C. Baudry (AE_BE/ENG3)
# 22.02.2013
#
# Description:
#   This script calls the QAC tools (QAC, ERR, PRJ) for each given source file.
#   It creates a lst file which can be later used for other QAC tools (viewer...)
#   This lst file is copied into the Jenkins workspace (if it exists). 
#
# Parameters (inputs):
# - 1 - QAC configuration file
#
# Outputs:
# - QAC analysis outputs
# - filelist.lst used for the QAC viewer
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 22.02.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 09.04.2013 -  C. Baudry (AE-BE/ENG3)
#   Add the time for each analyzed file
#   Add a flush after printing each file name (Jenkins output improvment)
#---------------------------------------------------------------------------
# Version 001.02 - 10.04.2013 -  C. Baudry (AE-BE/ENG3)
#   Remove output directory creation: done in the preparation script
#---------------------------------------------------------------------------
# Version 001.03 - 07.05.2013 -  C. Baudry (AE-BE/ENG3)
#   Remove option -op from source file list: used for the PRQA plugin
#---------------------------------------------------------------------------
# Version 001.04 - 18.06.2013 -  C. Baudry (AE-BE/ENG3)
#   Copy the HTML report file of each analyzed file in the Jenkins workspace
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

import shutil

import datetime

''' import the configuration file handler '''
from configFile import ConfigFile


if __name__ == '__main__':
    
    ''' the qac tool is sequencially called according to the source files list '''
    
    ''' parameters: QAC configuration file '''
    __qac_configuration_file = sys.argv[1]
    
    ''' get configuration for QAC '''
    __qac_configuration = ConfigFile(__qac_configuration_file).ConfigDictionary()
    
    ''' initializations '''
    __tempOutpath = os.environ.get("BCMF_TEMP_OUT")
    
    # get qacTmp.txt file content to initialize some variables
    __qacTmpFile = __tempOutpath + "\\qacTmp.txt"
    __qacTmpFileHd = open(__qacTmpFile)
    __qacTmpFileData = __qacTmpFileHd.read()
    __qacTmpFileHd.close()
    __qacTmpFileDataLines = __qacTmpFileData.splitlines()
    
    __viaFile         = __qacTmpFileDataLines[3]
    __sourceTmpFile   = __qacTmpFileDataLines[4]
    __prefix          = __qacTmpFileDataLines[6]
    __qacOutputFolder = __qac_configuration["QAC_OUTPATH"] + "\\" + __prefix + "_Output"
    __toolsPath       = os.environ.get("BCMF_TOOLS_ROOT")
    
    ''' set QAC special env variables '''
    os.environ['QACBIN']       = __toolsPath + "\\QAC\\bin"
    os.environ['QACOUTPATH']   = __qacOutputFolder
    os.environ['QACHELPFILES'] = __toolsPath + "\\QAC\\help"
    
    ''' read source file list and create a list'''
    __sourcesListFile = open(__sourceTmpFile)
    __sourcesListFileData = __sourcesListFile.read()
    __sourcesListFile.close()
    
    __sourcesList = __sourcesListFileData.splitlines()
    #the first element is removed: it is the option -op
    __sourcesList.pop(0)
    
    ''' run QAC for each file '''
    print "- Run QAC for each file"
    
    __startTime = datetime.datetime.now()
    print "  Analysis start time: " + str(__startTime)[:-7]
    
    __listLength = len(__sourcesList)
    print "  Number of files to analyze: " + str(__listLength)
    __index = 0
    for sourceFile in __sourcesList:
        __index = __index + 1
        __currentStatePercent = 100 * __index / __listLength
        print "  - " + str(__currentStatePercent) + "% - " + str(__index) + "/" + str(__listLength) + " - " + str(datetime.datetime.now())[:-7] + " - " + sourceFile
        sys.stdout.flush()
        
        ''' QAC analysis '''
        __command = __qac_configuration["QAC_EXE"] + " -via " + __viaFile + " -op " + __qacOutputFolder + " " + sourceFile
        os.system(__command)

        ''' Annotated source generation '''
        __sourceFileName = os.path.split(sourceFile)[1]
        __command = __qac_configuration["QAC_ERR"] + " QAC " + __qac_configuration["OUT_OPTS_ASC"] + " -via " + __viaFile + " -file " + __sourceFileName + "."     + __qac_configuration["OUT_FORM_ASC"] + " -op " + __qacOutputFolder + " " + sourceFile
        os.system(__command)
        
        ''' Copy HTML report in the Jenkins workspace '''
        try:
            shutil.copy(__qacOutputFolder + "\\" + __sourceFileName + "." + __qac_configuration["OUT_FORM_ASC"], os.environ.get("WORKSPACE"))
        except:
            pass
        
        
        ''' Warning summary for each file '''
        __command = __qac_configuration["QAC_PRJ"] + " QAC " + __qac_configuration["OUT_OPTS_REP"] + " -via " + __viaFile + " -file " + __sourceFileName + "_rep." + __qac_configuration["OUT_FORM_REP"] + " -op " + __qacOutputFolder + " " + sourceFile
        os.system(__command)
        
        
    __endTime = datetime.datetime.now()
    print "  Analysis end time: " + str(__endTime)[:-7]
    __buildDuration = __endTime - __startTime
    print "  Analysis duration: " + str(__buildDuration)[:-7]
    
    ''' create lst file for the CMA analysis and the viewer '''
    shutil.copyfile(__sourceTmpFile, __qacOutputFolder + "\\filelist.lst")
    
    ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
    try:
        shutil.copy(__qacOutputFolder + "\\filelist.lst", os.environ.get("WORKSPACE"))
    except:
        pass

    
    ''' end of file '''
    