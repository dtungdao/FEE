# Rb_QAC_SpecificWarningsNotifier.py
#
# C. Baudry (AE_BE/ENG3)
# 22.05.2014
#
# Description:
#   This script creates a report for each user who has some specific QAC warnings in his modules. 
#   It is based on the JSON database which is created in the script Rb_QAC_SpecificWarnings.py.
#   It uses the project analysis database to get the file responsible names.
#
# Parameters (inputs):
# - 1 - JSON database from the QAC specific warnings analysis script
# - 2 - Project database (xlsx)
# - 3 - Print error log on console
#           "Yes"
#           "No"
#
# Other inputs which are not parameters
# - Notifier configuration file configNotifications.txt
#
# Outputs:
# - error log
# - results log
# - results log per user
#
# Open points:
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 22.05.2014 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 23.05.2014 -  C. Baudry (AE-BE/ENG3)
#   The warning level is not given in the user mail
#   Title "Line,Column" instead of "Position" in the user mail
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' Excel 2007 library '''
import openpyxl

import shutil

import json


if __name__ == '__main__':

    ''' inits '''
    __JsonDatabasePath       = sys.argv[1]
    __inputProjectDatabase   = sys.argv[2]
    __printErrorLog          = sys.argv[3]
    __columnFile             = 0 
    __columnResponsibleID    = 3
    __strErrorLog            = "\n"
    __strResultsLog          = ""
    __userList               = []
    __dictFileResponsibles   = {}
    __tempUserList           = []
    __tempOutpath            = os.environ.get("BCMF_TEMP_OUT")
    __sofwarePath            = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolchainConfigPath    = os.environ.get("BCMF_CFG_ROOT")
    __outputFileName         = "QacSpecificWarningsNotifierResults.txt"
    __mailMessageModule      = "<hr><B><U>QAC specific warnings notifications</U></B><br><br>The QAC warnings levels 1-2-3 listed below could lead to SW errors and must be verified."
        
    
    ''' get environment config '''
    # read the config file to get the current notification output path
    try:
        __configFileHandler = open(__tempOutpath + "\\configNotifications.txt")
        __tempNotificationOutPath = __configFileHandler.read()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the config file " + __tempOutpath + "\\configNotifications.txt!!\n")
    
    
    ''' parse the project databases '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_QAC_SpecificWarningsNotifier.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' Default user is used in case no responsible is defined '''
    __userDefault = __worksheetGeneral.cell('B3').value    
    
    
    ''' JSON metrics database import '''
    
    __jsonData = open(__JsonDatabasePath)
    __jsonImportDict = json.load(__jsonData)
    __jsonData.close()
    
    #get files responsible
    __dictFileResponsibles = {}
    for __file in __jsonImportDict:
        
        __found = False
        __rowNumber = 0
    
        # first check in the sources database
        for __row in __worksheetDatabaseSources.rows:
            __rowNumber += 1
            # database and metrics file comparison
            # -> compare only the file name
            if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
            
                # case the responsible cell is empty
                if __row[__columnResponsibleID].value == None:
                    __userList.append(__userDefault)
                    __userID = __userDefault
                    __strErrorLog += "-- QAC specific warnings notifier warning: Responsible not given in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                
                # case the responsible cell contains non-word characters
                elif re.search("\W",__row[__columnResponsibleID].value):
                    __userList.append(__userDefault)
                    __userID = __userDefault
                    __strErrorLog += "-- QAC specific warnings notifier warning: Responsible syntax not correct in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                
                # good case
                else:
                    __userList.append(__row[__columnResponsibleID].value)
                    __userID = __row[__columnResponsibleID].value
                
                __found = True
        
        # then check in the headers database if not found in the sources database
        if __found == False:
            __rowNumber = 0
            for __row in __worksheetDatabaseHeaders.rows:
                __rowNumber += 1
                # database and metrics file comparison
                # -> compare only the file name
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                
                    # case the responsible cell is empty
                    if __row[__columnResponsibleID].value == None:
                        __userList.append(__userDefault)
                        __userID = __userDefault
                        __strErrorLog += "-- QAC specific warnings notifier warning: Responsible not given in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    
                    # case the responsible cell contains non-word characters
                    elif re.search("\W",__row[__columnResponsibleID].value):
                        __userList.append(__userDefault)
                        __userID = __userDefault
                        __strErrorLog += "-- QAC specific warnings notifier warning: Responsible syntax not correct in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    
                    # good case
                    else:
                        __userList.append(__row[__columnResponsibleID].value)
                        __userID = __row[__columnResponsibleID].value
                    
                    __found = True
                
        
        if __found == False:
            # if the file has not been found in the project database, the default user is used
            __userList.append(__userDefault)
            __userID = __userDefault
            __strErrorLog += "-- QAC specific warnings notifier warning: File %s not found in the databases\n    --> Default user used for notification\n" % __file


        #responsible for this file: __userID
        __dictFileResponsibles[__file] = __userID  
    
    
    ''' sort the user list alphabetically and remove the doubles '''
    for __user in __userList:
        try:
            ind = __tempUserList.index(__user)
        except:
            __tempUserList.append(__user)
    __userList = __tempUserList
    __userList.sort()
    
    
    ''' create a QAC specific warnings report per user '''
    for __user in __userList:
        __strResultsUser = "<FONT FACE='Arial' SIZE=-1>%s<br><br>" % __mailMessageModule        
        
        # if not already done: create a folder especially for the user with as name the user id
        __tempUserFolder = __tempNotificationOutPath + "\\" + __user
        if not os.path.exists(__tempUserFolder):
            os.makedirs(__tempUserFolder)
        
        
        #columns names
        __strResultsUser += "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File</th><th align='left'>Line,Column</th><th align='left'>Warning number</th><th align='left'>Description</th></tr>"
        
        for __currentFileName in __jsonImportDict:
            __currentUser = __dictFileResponsibles[__currentFileName]
            for __currentPosition in __jsonImportDict[__currentFileName]:
                if __user == __currentUser:
                    __reducedFileName = os.path.basename(__currentFileName)
                    __splitedLine = __jsonImportDict[__currentFileName][__currentPosition].split("::::")
                    __warningLevel = __splitedLine[0] # not used
                    __warningNumber = __splitedLine[1]
                    __warningDescription = __splitedLine[2]
                    __strResultsUser += "<tr><td align='left'>%s</td><td align='left'>%s</td><td align='left'>%s</td><td align='left'>%s</td></tr>" % (__reducedFileName,__currentPosition,__warningNumber,__warningDescription)
        
        __strResultsUser += "</table></FONT>"
        __strResultsLog  += __strResultsUser
        
        try:
            __tempFileHandler = open(__tempUserFolder + "\\" + __outputFileName, 'w')
            __tempFileHandler.write(__strResultsUser)
            __tempFileHandler.close()
            print "-- QAC specific warnings notifier: create a QAC specific warnings list for user %s" % __user
        except:
            raise Exception("ERROR: Impossible to create the QAC specific warnings notifier results user file!!\n")
    
    
    ''' results log file '''
    try:
        __tempFileHandler = open(__tempNotificationOutPath + "\\QacSpecificWarningsNotifierResultsLog.html", 'w')
        __tempFileHandler.write(__strResultsLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempNotificationOutPath + "\\QacSpecificWarningsNotifierResultsLog.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the QAC specific warnings notifier results log file!!\n")
        
        
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempNotificationOutPath + "\\QacSpecificWarningsNotifierErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempNotificationOutPath + "\\QacSpecificWarningsNotifierErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the QAC specific warnings notifier error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    ''' end of file '''
