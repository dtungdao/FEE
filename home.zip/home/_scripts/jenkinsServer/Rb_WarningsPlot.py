# Rb_WarningsPlot.py
#
# C. Baudry (AE_BE/ENG3)
# 12.11.2013
#
# Description:
#   This script parses the Jenkins Warnings plugin output to look for the 
#   compiler warnings in the project.
#   It sums all warnings and create a csv file with this sum.
#   The csv file can be used later with the Jenkins Plot plugin
#
# Parameters:
# - 1 - XML input file
#
# Other inputs which are not parameters:
#
# Outputs:
# - csv file for the Jenkins Plot plugin
#
# Open points:
# - see TODO
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 12.11.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' xml parser '''
import xml.etree.ElementTree as ET

import shutil


if __name__ == '__main__':

    ''' inits '''
    __inputXmlFile         = sys.argv[1]
    __strCsv               = ""
    __outputFile           = os.environ.get("WORKSPACE") + "\\PlotWarningsAnalysis.csv"
    __sumWarnings          = 0
    
        
    ''' parse the XML input file provided by the Jenkins warnings plugin '''
    __tree = ET.parse(__inputXmlFile)
    __root = __tree.getroot()
    
    
    ''' get the sum of all warnings '''
    for __warning in __root.iter('warning'):
        __sumWarnings += 1
    
    __strCsv = "WarningsSum;\n" + str(__sumWarnings) + ","
    
    ''' create the csv file '''
    try:
        __tempFileHandler = open(__outputFile, 'w')
        __tempFileHandler.write(__strCsv)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the Warnings Plot file!!\n")
    

    ''' end of file '''
