# Rb_BCMF_4_Reporting.py
#
# C. Baudry (AE_BE/ENG3)
# 25.02.2013
#
# Description:
#  This script generates different kind of report according to the given input 
#  parameter. To generate more than 1 report, the script has to be called again. 
#
# Parameters (inputs):
# - 1 - QAC configuration file
# - 2 - Report type:
#           "ExcelReport"
#           "SummaryReport"
#           "QACViewer"
# - 3 - Jenkins used or not
#           "Yes"
#           "No"
#
# Outputs:
# - Reports available in the QAC output directory
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 25.02.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 23.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Create a csv file containing the QAC summary results for Plot plugin
#---------------------------------------------------------------------------
# Version 002.01 - 10.01.2014 -  C. Baudry (AE-BE/ENG3)
#   Add the sum of the required qac warnings in the csv file
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

''' import the configuration file handler '''
from configFile import ConfigFile

import datetime

import shutil


if __name__ == '__main__':
    
    ''' parameters: QAC configuration file, selected report/output'''
    __qac_configuration_file = sys.argv[1]
    __selectedOutput         = sys.argv[2]
    __jenkinsUsed            = sys.argv[3]
    
    ''' get configuration for QAC '''
    __qac_configuration = ConfigFile(__qac_configuration_file).ConfigDictionary()
    
    ''' initializations '''
    __tempOutpath = os.environ.get("BCMF_TEMP_OUT")
    
    # get qacTmp.txt file content to initialize some variables
    __qacTmpFile = __tempOutpath + "\\qacTmp.txt"
    __qacTmpFileHd = open(__qacTmpFile)
    __qacTmpFileData = __qacTmpFileHd.read()
    __qacTmpFileHd.close()
    __qacTmpFileDataLines = __qacTmpFileData.splitlines()
    
    __qacMessagesPerso    = __qacTmpFileDataLines[2]
    __viaFile             = __qacTmpFileDataLines[3]
    __prefix              = __qacTmpFileDataLines[6]
    __qacOutputFolder     = __qac_configuration["QAC_OUTPATH"] + "\\" + __prefix + "_Output"
    __toolsPath           = os.environ.get("BCMF_TOOLS_ROOT")
    __sofwarePath         = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolchainConfigPath = os.environ.get("BCMF_CFG_ROOT")
    __qacLstFile          = __qacOutputFolder + "\\filelist.lst"
    __qacErrorSummary     = __qacOutputFolder + "\\QAC_ErrorSummary_" + __prefix + ".txt"
    __csvPlotFile         = __qacOutputFolder + "\\QAC_Plot_Results.csv"
    __strCSVtitle         = ""
    __strCSV              = ""
    __qacResults          = range(10)

    
    ''' set QAC special env variables '''
    os.environ['QACBIN']       = __toolsPath + "\\QAC\\bin"
    os.environ['QACOUTPATH']   = __qacOutputFolder
    os.environ['QACHELPFILES'] = __toolsPath + "\\QAC\\help"
    
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' run perl script to generate Excel report        '''
    ''' should be run sequentialy with the QAC analysis '''
    if __selectedOutput == "ExcelReport":
        print "- Generate Excel report"
        
        __reportName = "QAC_Report_" + __prefix
        __excelReportFile = __reportName + ".xls"
        __reportSettings = __toolchainConfigPath + "\\report_settings.txt"
        
        ''' clean output file '''
        if os.path.isfile(__excelReportFile):
            os.remove(__excelReportFile)
        
        __startTime = datetime.datetime.now()
        print "  Excel report start time: " + str(__startTime)[:-7]
        

        __command = "perl " + __toolsPath + "\\QAC\\ae_extras\\qac_report.pl -out " + __qacOutputFolder + " -rep " + __qacOutputFolder + " -set " + __reportSettings + " -format xls -mper " + __qacMessagesPerso + " -name " + __reportName
        os.system(__command)
        
        __endTime = datetime.datetime.now()
        print "  Excel report end time: " + str(__endTime)[:-7]
        __duration = __endTime - __startTime
        print "  Excel report duration: " + str(__duration)[:-7]
        
        ''' if Jenkins is used: copy the result file into the Jenkins workspace '''
        if __jenkinsUsed == "Yes":
            shutil.copy(__reportName + ".xls", os.environ.get("WORKSPACE"))        
    
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Summary Diagnostic Output                       '''
    ''' should be run sequentialy with the QAC analysis '''
    if __selectedOutput == "SummaryReport":
        print "- Generate summary diagnostic output"
        
        ''' clean output file '''
        if os.path.isfile(__qacErrorSummary):
            os.remove(__qacErrorSummary)
        
        __startTime = datetime.datetime.now()
        print "  Summary diagnostic output start time: " + str(__startTime)[:-7]
        
        __command = __qac_configuration["QAC_SUM"] + " QAC -via " + __viaFile + " -cmaf " + __qacOutputFolder + " -list " + __qacLstFile + " -file " + __qacErrorSummary
        os.system(__command)
        
        __endTime = datetime.datetime.now()
        print "  Summary diagnostic output end time: " + str(__endTime)[:-7]
        __duration = __endTime - __startTime
        print "  Summary diagnostic output duration: " + str(__duration)[:-7]
        
        
        ''' if Jenkins is used:
            - copy the file in the Jenkins workspace
            - generate a csv file for the plot plugin '''
        if __jenkinsUsed == "Yes":
            
            shutil.copy(__qacErrorSummary, os.environ.get("WORKSPACE"))
            
            try:
                __qacErrorSummaryHandler = open(__qacErrorSummary)
                __qacErrorSummarydata = __qacErrorSummaryHandler.readlines()
                __qacErrorSummaryHandler.close()
            except:
                raise Exception("ERROR: The file " + __qacErrorSummary + " can not be read.\n") 
            
            for index in range(0,10):
                __strCSVtitle += "Level %s," % str(9-index)
    
            for __line in __qacErrorSummarydata:
                if re.search("Total +",__line):
                    __resultLine = __line.split()
                    for index in range(1,11):
                        __strCSV += __resultLine[index] + "," 
                        __qacResults[10-index] = int(__resultLine[index])
                    break
            
            #add a sum in the csv file
            #sum level 4 to 9
            __sumTmp = 0
            for index in range(4,10):
                __sumTmp += __qacResults[index]
            __strCSVtitle += "SumLevels_4_to_9"
            __strCSV      += str(__sumTmp)
                    
            try:
                __csvFileHandler = open(__csvPlotFile, "w")
                __csvFileHandler.write(__strCSVtitle + "\n" + __strCSV)
                __csvFileHandler.close()
            except:
                raise Exception ("ERROR: The file " + __csvPlotFile + " can not be written or created.\n")
            
            shutil.copy(__csvPlotFile, os.environ.get("WORKSPACE"))
            
    
    '''-----------------------------------------------------------------------------------------------------------'''    
    ''' QAC Viewer '''
    
    if __selectedOutput == "QACViewer":
        print "- Run the QAC Viewer"
        __command = __qac_configuration["QAC_VWR"] + " QAC -via " + __viaFile + " -list "  + __qacOutputFolder + "\\filelist.lst"
        os.system(__command)
    
    
    ''' end of file '''
    