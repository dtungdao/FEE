# Rb_BCMF_1_PrepareQAC.py
#
# C. Baudry (AE_BE/ENG3)
# 19.02.2013
#
# Description:
#   This script prepare the inputs for the required QAC analysis.
#   It can be used for a project analysis, a third party SW analysis, a module analysis 
#   and also a file analysis.
#   It uses the PAD (Project Analysis Database) to get the list of 3rd party files or folder
#   and the list of files or folders to be excluded or ignored for an analysis.
#   !! It only work with projects using a Green Hills compiler and the gbuild system !!
#   It creates a specific output folder for the data to be generated.
#
# Parameters (inputs):
# - 1 - BCMF toolchain configuration file
# - 2 - BCMF QAC configuration file
# - 3 - Selected variant (as in the toolchain configuration file)
# - 4 - QAC analysis type:    
#           "ProjectAnalysis"
#           "ModuleAnalysis"
#           "FileAnalysis"
# - 5 - For project analysis: ignore third party SW or not or only analyze third party: 
#           "NoThird"
#           "WithThird"
#           "OnlyThird"
# - 6 - For module analysis: Path to analyze from
# - 7 - For module analysis: Module name
# - 8 - For module analysis: Dependencies: 
#           "AllDependencies"
#           "ModuleDependencies"
# - 9 - PAD: Project Analysis Database (xlsx)
# - 10 - For file analysis: Path + file name to analyze (optional)
#
# Outputs:
# - Source files list for the QAC tools
# - Input files list (not directly used for QAC)
# - QAC personalities
# - QAC VIA file
# - QAC configuration batch file used to set the QAC env variables for Jenkins
# - QAC Tmp file which contains the outputs file names
# - QAC project file
#
# Open points:
# - enhance the script with a possibility to not use a GHS compiler:
#   the lists should be created in this case only from the PAD.
# - replace all parameters with an own configuration file?
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 19.02.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 09.04.2013 -  C. Baudry (AE-BE/ENG3)
#   Add file analysis support
#---------------------------------------------------------------------------
# Version 003.00 - 10.04.2013 -  C. Baudry (AE-BE/ENG3)
#   Add the QAC project file creation support
#   Correct and update error messages
#   Correct copy of the via file in the Jenkins workspace
#---------------------------------------------------------------------------
# Version 003.01 - 03.05.2013 -  C. Baudry (AE-BE/ENG3)
#   Remove header files from source file list
#---------------------------------------------------------------------------
# Version 003.02 - 07.05.2013 -  C. Baudry (AE-BE/ENG3)
#   Add option -op in the source file list: used for the PRQA plugin
#---------------------------------------------------------------------------
# Version 003.03 - 03.02.2014 -  C. Baudry (AE-BE/ENG3)
#   Correct case sensitive comparisons with the 3rd party list
#---------------------------------------------------------------------------
# Version 004.00 - 03.07.2014 -  C. Baudry (AE-BE/ENG3)
#   The 3rd party SW and the ignore SW is now configured in the PAD
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

''' import the configuration file handler '''
from configFile import ConfigFile

import shutil

''' Excel 2007 library '''
import openpyxl 


if __name__ == '__main__':
    
    ''' this script uses environment variables which have to be defined previously '''
    
    ''' At this point we suppose the project has been successfully built '''
    ''' this will be check while creating the GHS header file list '''
 
    ''' initializations '''
    __tempOutpath                   = os.environ.get("BCMF_TEMP_OUT")
    __sofwarePath                   = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolsPath                     = os.environ.get("BCMF_TOOLS_ROOT")
    __compilerPath                  = os.environ.get("BCMF_COMPILER_ROOT")
    __toolchainConfigPath           = os.environ.get("BCMF_CFG_ROOT")
    __allSubdirsC                   = []                                        # source file list used for the QAC tool as input
    __allSubdirsH                   = []                                        # header folder list used for the QAC tool as input
    __tempAllSubdirsC               = []                                        # tmp list
    __tempAllSubdirsH               = []                                        # tmp list
    __qacThirdPartySourceList       = []                                        # file list of third party sources based on the PAD
    __qacThirdPartyHeaderList       = []                                        # folder list of third party headers based on the PAD
    __tempQacThirdPartyHeaderList   = []                                        # tmp list
    __qacIgnoreSourceList           = []                                        # file list of sources to be ignored based on the PAD
    __qacIgnoreHeaderList           = []                                        # folder list of headers to be ignored based on the PAD
    __tempQacIgnoreHeaderList       = []                                        # tmp list
    __columnFile                    = 0                                         # file column index in the PAD
    __columnQacExclude              = 7                                         # QAC exclude column index in the PAD
    __columnQacThird                = 8                                         # QAC third party SW column index in the PAD
    __toolchain_configuration_file  = sys.argv[1]
    __qac_configuration_file        = sys.argv[2]
    __selectedVariant               = sys.argv[3]
    __qacAnalysisType               = sys.argv[4]
    __thirdPartySW                  = sys.argv[5]
    __modulePath                    = sys.argv[6]
    __moduleName                    = sys.argv[7]
    __moduleDependencies            = sys.argv[8]
    __inputProjectDatabase          = sys.argv[9]
    
    ''' initialization for the file analysis '''
    try:
        __filePath        = sys.argv[10]
        __fileName        = os.path.basename(__filePath)[:-2]
    except: pass
    
    ''' get BCMF toolchain configuration '''
    __toolchain_configuration = ConfigFile(__toolchain_configuration_file).ConfigDictionary()
    
    ''' get BCMF QAC configuration '''
    __qac_configuration          = ConfigFile(__qac_configuration_file).ConfigDictionary()
    
    ''' parse the project databases and check the project analysis database version '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_BCMF_1_PrepareQAC.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    ''' Create the third party files list '''
    print "- Parse the project analysis database"
    # go through the source files in the project analysis database
    for __row in __worksheetDatabaseSources.rows:
        # try/except used in the case the cell is empty
        # check if the file is selected in the project database
        try:
            if __row[__columnQacExclude].value.lower() == "x":
                __qacIgnoreSourceList.append(__row[__columnFile].value)
        except:
            pass
        try:
            if __row[__columnQacThird].value.lower() == "x":
                __qacThirdPartySourceList.append(__row[__columnFile].value)
        except:
            pass
    for __row in __worksheetDatabaseHeaders.rows:
        # try/except used in the case the cell is empty
        # check if the file is selected in the project database
        try:
            if __row[__columnQacExclude].value.lower() == "x":
                __qacIgnoreHeaderList.append(__row[__columnFile].value)
        except:
            pass
        try:
            if __row[__columnQacThird].value.lower() == "x":
                __qacThirdPartyHeaderList.append(__row[__columnFile].value)
        except:
            pass
    
    ''' for all lists: complete the path to go from the script folder and convert the elements in lower case '''
    
    # ignore source file list
    for index in range(len(__qacIgnoreSourceList)):
        __qacIgnoreSourceList[index] = (__sofwarePath + "\\" + __qacIgnoreSourceList[index]).lower()
        
    # 3rd party source file list
    for index in range(len(__qacThirdPartySourceList)):
        __qacThirdPartySourceList[index] = (__sofwarePath + "\\" + __qacThirdPartySourceList[index]).lower()
        
    # ignore header folders
    for index in range(len(__qacIgnoreHeaderList)):
        __qacIgnoreHeaderList[index] = (__sofwarePath + "\\" + os.path.split(__qacIgnoreHeaderList[index])[0]).lower()
    # we delete the double entries in the list
    for __element in __qacIgnoreHeaderList:
        try:
            __ind = __tempQacIgnoreHeaderList.index(__element)
        except:
            __tempQacIgnoreHeaderList.append(__element)
    __qacIgnoreHeaderList = __tempQacIgnoreHeaderList
        
    # 3rd party header folders
    for index in range(len(__qacThirdPartyHeaderList)):
        __qacThirdPartyHeaderList[index] = (__sofwarePath + "\\" + os.path.split(__qacThirdPartyHeaderList[index])[0]).lower()
    # we delete the double entries in the list
    for __element in __qacThirdPartyHeaderList:
        try:
            __ind = __tempQacThirdPartyHeaderList.index(__element)
        except:
            __tempQacThirdPartyHeaderList.append(__element)
    __qacThirdPartyHeaderList = __tempQacThirdPartyHeaderList
        
    
    ''' prepare variant dictionaries '''
    __variants = ConfigFile(__toolchain_configuration_file).SegmentDictionary()
    
    ''' QAC personalities template files '''
    __qacAnalyzerPersoTemplate = __qac_configuration["QAC_ANALYSER_PERSO_TMPL"]
    __qacCompilerPersoTemplate = __qac_configuration["QAC_COMPILER_PERSO_TMPL"]
    __qacMessagesPersoTemplate = __qac_configuration["QAC_MESSAGE_PERSO_TMPL"] 
    
    ''' analysis postfix used for directories and files name: depending on the kind of analysis: 
        - project with third party             : __selectedVariant_with_thirdParty
        - project without third party          : __selectedVariant_without_thirdParty
        - project third party alone            : __selectedVariant_only_thirdParty
        - module with all dependencies         : __moduleName_allDependencies 
        - module with only module dependencies : __moduleName_moduleDependencies 
        - file                                 : __fileName '''
    if __qacAnalysisType == "ProjectAnalysis" and __thirdPartySW == "WithThird":
        __postfix = __selectedVariant + "_project_with_thirdParty"
    elif __qacAnalysisType == "ProjectAnalysis" and __thirdPartySW == "NoThird":
        __postfix = __selectedVariant + "_project_without_thirdParty"
    elif __qacAnalysisType == "ProjectAnalysis" and __thirdPartySW == "OnlyThird":
        __postfix = __selectedVariant + "_project_only_thirdParty"
    elif __qacAnalysisType == "ModuleAnalysis" and __moduleDependencies == "AllDependencies":
        __postfix = __selectedVariant + "_module_" + __moduleName + "_allDependencies"
    elif __qacAnalysisType == "ModuleAnalysis" and __moduleDependencies == "ModuleDependencies":
        __postfix = __selectedVariant + "_module_" + __moduleName + "_moduleDependencies"
    elif __qacAnalysisType == "FileAnalysis":
        __postfix = "file_" + __fileName
    else:
        raise Exception("ERROR: Rb_BCMF_1_PrepareQAC.py: Wrong parameters combination!\n") 
     
    ''' Output files '''
    __qacAnalyzerPerso  = __tempOutpath + "\\QacAnalyzerPersonality_" + __postfix + ".p_a"
    __qacCompilerPerso  = __tempOutpath + "\\QacCompilerPersonality_" + __postfix + ".p_c"
    __qacMessagesPerso  = __tempOutpath + "\\QacMessagesPersonality_" + __postfix + ".p_s"
    __qacViaFile        = __tempOutpath + "\\QacViaFile_" + __postfix + ".via"
    __qacConfFile       = __tempOutpath + "\\QacConfFile" + __postfix + ".bat"
    __SourcesFileOutput = __tempOutpath + "\\ListSourcesTempFile_" + __postfix + ".txt"
    __IncludeFileOutput = __tempOutpath + "\\ListIncludesTempFile_" + __postfix + ".txt"
    __qacTmp            = __tempOutpath + "\\qacTmp.txt"
    __qacOutputFolder   = __qac_configuration["QAC_OUTPATH"] + "\\" + __postfix + "_Output"
    
    ''' Write these files names into the qacTmp.txt file: used for the next analysis steps'''
    try:
        __qacTmpHd = open(__qacTmp, "w")
        __qacTmpHd.write(__qacAnalyzerPerso + "\n" + __qacCompilerPerso + "\n" + __qacMessagesPerso + "\n")
        __qacTmpHd.write(__qacViaFile + "\n" + __SourcesFileOutput + "\n" + __IncludeFileOutput + "\n" + __postfix + "\n")
        __qacTmpHd.close()
    except:
        raise Exception("ERROR: The file " + __qacTmp + " can not be written or created.\n") 
    
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create GHS source file list '''

    print "- Create GHS source file list"
    __SourcesTempFile = __tempOutpath + "\\GHSListSourcesTempFile_" + __postfix + ".txt"
    __GHScommand = __toolchain_configuration["GET_SRC_" + __selectedVariant] + " > " + __SourcesTempFile
    os.system(__GHScommand)
    
    ''' read the temporary file where the command results is saved'''
    __GHSListFile = open(__SourcesTempFile)
    __GHSListFileData = __GHSListFile.read()
    __GHSListFile.close()
    
    ''' the file content is converted in a list '''
    __allSubdirsC = __GHSListFileData.splitlines()
    
    ''' the spaces are deleted '''
    for index in range(len(__allSubdirsC)):
        __allSubdirsC[index] = __allSubdirsC[index].lstrip()
            
    ''' we delete from the list what we do not need '''
    ''' .gpj files are not required '''
    __allSubdirsC = [element for element in __allSubdirsC if (re.search("\.gpj", element) == None)]
    ''' .ld files are not required '''
    __allSubdirsC = [element for element in __allSubdirsC if (re.search("\.ld", element) == None)]
    ''' .s files are not required '''
    __allSubdirsC = [element for element in __allSubdirsC if (re.search("\.s", element) == None)]
    ''' .ppc files are not required '''
    __allSubdirsC = [element for element in __allSubdirsC if (re.search("\.ppc", element) == None)]
    ''' .h files are not taken as source files '''
    __allSubdirsC = [element for element in __allSubdirsC if (re.search("\.h", element) == None)]
    
    ''' if the path is absolute (without ".." at the beginning), we remove it: it is not part of the RB SW; ex: compiler include files '''
    __allSubdirsC = [element for element in __allSubdirsC if (element[:2] == "..")]
    
    ''' we delete the double entries in the list '''
    for element in __allSubdirsC:
        try:
            ind = __tempAllSubdirsC.index(element)
        except:
            __tempAllSubdirsC.append(element)
    
    ''' we delete the first double points of each entry if required'''
    ''' we complete the path to go from the script folder '''
    for index in range(len(__tempAllSubdirsC)):
        if __tempAllSubdirsC[index][:2] == "..":
            __tempAllSubdirsC[index] = __tempAllSubdirsC[index][2:] 
            __tempAllSubdirsC[index] = __sofwarePath + __tempAllSubdirsC[index]
    
    ''' the temporary list is saved on the result list '''
    __allSubdirsC = __tempAllSubdirsC
    
    ''' the list is converted with lower char '''
    for index in range(len(__allSubdirsC)):
        __allSubdirsC[index] = __allSubdirsC[index].lower()
        
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create GHS header file list '''
    print "- Create GHS header file list"
    __IncludesTempFile = __tempOutpath + "\\GHSListIncludesTempFile_" + __postfix + ".txt"
    __GHScommand = __toolchain_configuration["GET_INC_" + __selectedVariant] + " > " + __IncludesTempFile
    os.system(__GHScommand) 
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Arrange the GHS header file list, if empty: error, analysis not possible '''
    
    ''' read the temporary file where the command results is saved'''
    __GHSListFile = open(__IncludesTempFile)
    __GHSListFileData = __GHSListFile.read()
    __GHSListFile.close()
    
    ''' the file content is converted in a list '''
    __allSubdirsH = __GHSListFileData.splitlines()
    
    ''' if the list is empty, the command did not return any result which means that the project has still not been compiled '''
    ''' the user has to compile at least the project once to get the dependency list '''
    if len(__allSubdirsH) != 0: 
        # the spaces are deleted
        for index in range(len(__allSubdirsH)):
            __allSubdirsH[index] = __allSubdirsH[index].lstrip()
            
        # the list is converted with lower char
        for index in range(len(__allSubdirsH)):
            __allSubdirsH[index] = __allSubdirsH[index].lower()
            
        # we remove the file name to keep only the directory name
        for index in range(len(__allSubdirsH)):
            result = os.path.split(__allSubdirsH[index])
            __allSubdirsH[index] = result[0]
        
        # we delete the double entries in the list
        for element in __allSubdirsH:
            try:
                ind = __tempAllSubdirsH.index(element)
            except:
                __tempAllSubdirsH.append(element)
        
        # we delete the first double points of each entry when it is required
        # we complete the path to go from the script folder when it is required
        for index in range(len(__tempAllSubdirsH)):
            if __tempAllSubdirsH[index][:2] == "..":
                __tempAllSubdirsH[index] = __tempAllSubdirsH[index][2:] 
                __tempAllSubdirsH[index] = __sofwarePath + __tempAllSubdirsH[index]
        
        # the temporary list is saved on the result list
        __allSubdirsH = __tempAllSubdirsH
        
        # a temp file is created with this list
        try:
            __IncludesTempFileArrangedFile = open(__IncludeFileOutput, "w")
            for element in __allSubdirsH:
                __IncludesTempFileArrangedFile.write(element + "\n")
            __IncludesTempFileArrangedFile.close()
        except:
            raise Exception ("ERROR: The file " + __IncludeFileOutput + " can not be written or created.\n")
        
    else:
        raise Exception ("ERROR: Not possible to create the GHS include list: please compile the project\n")
        
        
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Adapt source file list according to the project analysis database filter                                  '''
    '''         Some files are ignored depending on the selected analysis type:                                   '''
    '''         - Without third party SW (and without the totally ignored files)                                  '''
    '''         - Only the third party SW                                                                         '''
    
        
    ''' No Third Party analysis '''
    if __thirdPartySW == "NoThird":
        print "- Project analysis without 3rd party SW: remove the 3rd party SW files from the source list"
        for __element in __qacThirdPartySourceList:
            for __sourceFile in __allSubdirsC:
                try:
                    __ind = __allSubdirsC.index(__element)
                    __allSubdirsC.remove(__element)
                except:
                    pass
        print "- Project analysis without 3rd party SW: remove the excluded files"
        for __element in __qacIgnoreSourceList:
            for __sourceFile in __allSubdirsC:
                try:
                    __ind = __allSubdirsC.index(__element)
                    __allSubdirsC.remove(__element)
                except:
                    pass
        
    
    ''' Only Third Party analysis '''
    ''' in this case the list is directly built from the project analysis database '''
    if __thirdPartySW == "OnlyThird":
        print "- Project 3rd party SW only analysis"
        __allSubdirsC = __qacThirdPartySourceList

    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Module analysis: create a source file list based on the given path '''
    
    if __qacAnalysisType == "ModuleAnalysis":
        # every c file found in the given directory or in its sub-directory is kept, the others are removed
        # we then only keep the files which are found in the GHS list.
        
        __tempAllSubdirsC = []
        __modulePath = __modulePath.lower()
        
        for __sourceFile in __allSubdirsC:
            __sourceFileTmp = __sourceFile.lower()
            # we look for the module string with a "\" to be sure to catch the right directory
            if __sourceFileTmp.find(__modulePath + "\\") == 0:
                __tempAllSubdirsC.append(__sourceFileTmp)                   
        
        __allSubdirsC = __tempAllSubdirsC
        __tempAllSubdirsC = []
        
        # we delete the double entries in the list
        for element in __allSubdirsC:
            try:
                index = __tempAllSubdirsC.index(element)
            except:
                __tempAllSubdirsC.append(element)
        
        __allSubdirsC = __tempAllSubdirsC
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' File analysis: create a source file list with only one entry: given file path + name '''
    
    if __qacAnalysisType == "FileAnalysis":
        __allSubdirsC = []
        __allSubdirsC.append(__filePath)
        
    
    ''' a temp file is created with this list '''
    try:
        __SourcesTempFileArrangedFile = open(__SourcesFileOutput, "w")
        __SourcesTempFileArrangedFile.write("-op \"" + __qacOutputFolder + "\"\n")
        for element in __allSubdirsC:
            __SourcesTempFileArrangedFile.write(element + "\n")
        __SourcesTempFileArrangedFile.close()
    except:
        raise Exception("ERROR: The file " + __SourcesFileOutput + " can not be written or created.\n")
            
            
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create analyzer personality '''
    
    print "- Create analyzer personality"
    
    # the template is used as base
    shutil.copyfile(__qacAnalyzerPersoTemplate, __qacAnalyzerPerso)
    
    try:
        __qacAnalyzerPersoFile = open(__qacAnalyzerPerso, "a")
        
        '''------ For all cases ------'''
        # all project include paths are considered, QAC needs to be able to understand the whole SW
        # the project include paths are added in the personality file with the prefix -i
        for element in __allSubdirsH:
            __qacAnalyzerPersoFile.write("-i " + element + "\n")
            
            
        '''------ Project analysis ------'''
        if __qacAnalysisType == "ProjectAnalysis":
        
            ''' Case project analysis WITH THIRD PARTY '''
            if __thirdPartySW == "WithThird":
                # nothing to add or to ignore in this case
                pass
            
            ''' Case project analysis WITHOUT THIRD PARTY '''
            if __thirdPartySW == "NoThird":
                # ignore the folders containing 3rd party header files (in the project analysis database)
                for __element in __qacThirdPartyHeaderList:
                    __qacAnalyzerPersoFile.write("-q " + __element + "\n")
            
            ''' Case project analysis ONLY THIRD PARTY '''
            if __thirdPartySW == "OnlyThird":
                # we ignore everything but the third party include paths
                for __element in __allSubdirsH:
                    if __element.lower() not in  __qacThirdPartyHeaderList:
                        __qacAnalyzerPersoFile.write("-q " + __element + "\n")
        
        
        '''------ Module analysis ------'''
        if __qacAnalysisType == "ModuleAnalysis":
            # case AllDependencies: the user wants to get the warnings of all included header files
            if __moduleDependencies == "AllDependencies":
                # nothing to add or to ignore in this case, we keep the already created header list
                pass
            
            # case ModuleDependencies: the user wants only to get the warnings of its module header files
            if __moduleDependencies == "ModuleDependencies":
                # same principle as for the "Only Third Party" analysis: we ignore everything but the module path
                __modulePathTmp = __modulePath.lower()
                for element in __allSubdirsH:
                    __elementTmp = element.lower()
                    if __elementTmp.find(__modulePath + "\\") == -1:
                        __qacAnalyzerPersoFile.write("-q " + element + "\n")         
        
        
        '''------ File analysis ------'''
        if __qacAnalysisType == "FileAnalysis":        
            # we ignore ALL include files, we just want to analyse a c file
            for __element in __allSubdirsH:
                __qacAnalyzerPersoFile.write("-q " + __element + "\n")
        
            
        '''------ For all cases ------'''
        # some include paths are ignored (PAD QAC ignore filter)
        for __element in __qacIgnoreHeaderList:
            __qacAnalyzerPersoFile.write("-q " + __element + "\n")
        
        __qacAnalyzerPersoFile.close()
        
    except:
        raise Exception("ERROR: The file " + __qacAnalyzerPerso + " can not be written or created.\n")

    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create compiler personalty '''
    
    print "- Create compiler personalty"
    
    ''' the template is used as base '''
    shutil.copyfile(__qacCompilerPersoTemplate, __qacCompilerPerso)
    
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create message personality '''
    
    print "- Create message personalty"
    
    ''' the template is used as base '''
    shutil.copyfile(__qacMessagesPersoTemplate, __qacMessagesPerso)
    
    ''' save the file content in a list to be able to modify it '''
    __qacMessagesPersoHd = open(__qacMessagesPerso)
    __qacMessagesPersoData = __qacMessagesPersoHd.readlines()
    __qacMessagesPersoHd.close()
    
    ''' change the helpfiles path for the viewer later '''
    __helpPath = __toolsPath + "\QAC\\ae_cg_impro\\"
    ''' search for -up option '''
    boese_zeile = ''
    for line in __qacMessagesPersoData:
        if '-up' in line:
            boese_zeile = line
    index = __qacMessagesPersoData.index(boese_zeile)
    __qacMessagesPersoData.remove(boese_zeile)
    __qacMessagesPersoData.insert(index, '\n-up ' + __helpPath + '\n\n')

    ''' add deactivated warnings '''
    __deactMessages = __qac_configuration["QAC_MESSAGE_PERSO_DEACTIVATE_WARNINGS"]
    if __deactMessages != "[]":
        for msg in __deactMessages:
            if msg == "[":
                deactivate = '-n '
            else:
                if msg == ",":
                    deactivate = '\n-n '
                else:
                    if msg == "]":
                        break
                    else:
                        deactivate = msg
            __qacMessagesPersoData.append(deactivate)
    else:
        pass

    __qacMessagesPersoHd = open(__qacMessagesPerso, 'w')
    __qacMessagesPersoHd.writelines(__qacMessagesPersoData)
    __qacMessagesPersoHd.close()
    
    
    
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create VIA file '''
    
    print "- Create VIA file"
    __str = "-via \"" + __qacAnalyzerPerso + "\"\n" + "-via \"" + __qacCompilerPerso + "\"\n" + "-via \"" + __qacMessagesPerso + "\"\n"
    try:
        __qacViaFileHd = open(__qacViaFile, "w")
        __qacViaFileHd.write(__str)
        __qacViaFileHd.close()
    except:
        raise Exception("ERROR: The file " + __qacViaFile + " can not be written or created.\n")
        
    ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
    try:
        shutil.copy(__qacViaFile, os.environ.get("WORKSPACE") + "\\qacViaFile.via")
    except:
        pass
        
        
        
    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create a specific QAC directory output '''
    print "- Create specific QAC output directory"

    if os.path.exists(__qacOutputFolder) == False:
        try:
            os.makedirs(__qacOutputFolder)
        except:
            raise Exception("ERROR: The folder " + __qacOutputFolder + " can't be created.\n")



    '''-----------------------------------------------------------------------------------------------------------'''
    ''' Create QAC project file '''
    print "- Create QAC project file"
    
    __qacProjectFile        = __qacOutputFolder + "\\QAC_Project.prj"
    __qacProjectFileContent = "VersionTag45\nStartProjectMarker\nFolderName=project_out\n"
    
    ''' source path '''
    ''' diferenciate relative with absolute paths '''
    if __qacOutputFolder[0] == ".":
        __pathBegin = "..\\"
    else:
        __pathBegin = ""
    __qacProjectFileContent = __qacProjectFileContent + "SourcePath=" + __pathBegin + __qacOutputFolder + "\\\n"
    __qacProjectFileContent = __qacProjectFileContent + "OutputPath=" + __pathBegin + __qacOutputFolder + "\\\n"

    for line in __allSubdirsC:
        if line[1] == ".":
            __qacProjectFileContent = __qacProjectFileContent + "..\\" + line + "\n"
        elif line[0] != "-":
            __qacProjectFileContent = __qacProjectFileContent + line + "\n"
            
    __qacProjectFileContent = __qacProjectFileContent + "EndContainedFilesMarker"
    
    ''' try to create the file '''
    try:
        __qacProjectFileHandler = open(__qacProjectFile, 'w')
        __qacProjectFileHandler.write(__qacProjectFileContent)
        __qacProjectFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create QAC project file!!\n")
        
    ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
    try:
        shutil.copy(__qacProjectFile, os.environ.get("WORKSPACE"))
    except:
        pass
    
    
    
    ''' end of file '''
    