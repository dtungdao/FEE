# Rb_ProjectAnalysisDatabase_Manager.py
#
# C. Baudry (AE_BE/ENG3)
# 15.01.2014
#
# Description:
#   This module checks the project analysis database (PAD). 
#   If required, it can inform (per mail) a database admin user about required changes:
#    - files are missing in the database
#    - files are not required anymore
#    - Responsible IDs are missing
#   The PAD CC users can also be informed if configured
#
# Parameters (inputs):
# - 1 - Temporary directory
# - 2 - Project database (xlsx) path + name
# - 3 - GPJ source file list path + name
# - 4 - GPJ header file list path + name
# - 5 - Send mail to the database admin
#           "Yes"
#           "No"
# - 6 - Send mail to the database cc users
#           "Yes"
#           "No"
#
# Outputs:
# - Report file containing all findings
#   This file is also used as content for the mail to be sent
#
# Open points:
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 15.01.2014 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 04.02.2014 -  C. Baudry (AE-BE/ENG3)
#   Dynamic project name for the mail object 
#---------------------------------------------------------------------------
# Version 001.02 - 30.07.2014 -  C. Baudry (AE-BE/ENG3)
#   The mail can also be sent to the PAD cc users
#---------------------------------------------------------------------------
# Version 001.03 - 26.08.2014 -  C. Baudry (AE-BE/ENG3)
#   Missing header files: correct the case: do not lower
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' Excel 2007 library '''
import openpyxl

''' mail functions '''
import smtplib
from email.mime.text import MIMEText

''' LDAP library '''
import ldap

    
if __name__ == '__main__':
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' inits '''
    __tempOutPathBase                 = sys.argv[1]
    __inputProjectDatabase            = sys.argv[2]
    __gpjSourceFileList               = sys.argv[3]
    __gpjHeaderFileList               = sys.argv[4]
    __sendMail                        = sys.argv[5]
    __sendMailCC                      = sys.argv[6]
    __reportFile                      = __tempOutPathBase + "\\ProjectAnalysisDatabaseCheckReport.txt"
    __projectCompleteSourceList       = []              # project complete source file list
    __tmpProjectCompleteSourceList    = []              # project temporary complete source file list
    __projectCompleteHeaderList       = []              # project complete header file list
    __tmpProjectCompleteHeaderList    = []              # project temporary complete header file list
    __columnFile                      = 0               # column file index in the project analysis database
    __columnResponsibleID             = 3               # column responsible id index in the project analysis database
    __report                          = ""              # final report (also mail content)
    __reportMissingSourceFiles        = ""              # string containing the list of all missing source files
    __reportMissingHeaderFiles        = ""              # string containing the list of all missing header files
    __reportNotRequiredSourceFiles    = ""              # string containing the list of all non required source files
    __reportNotRequiredHeaderFiles    = ""              # string containing the list of all non required header files
    __reportMissingSourceResponsible  = ""              # string containing the list of all db entries without responsible (source tab)
    __reportMissingHeaderResponsible  = ""              # string containing the list of all db entries without responsible (header tab)
    __usersCCList                     = []              # PAD CC users list
    __usersCCMail                     = []              # PAD CC users mail list
    
    __stringIntroMail = "You receive this email because you are the PAD (project analysis database) administrator.\nPlease update the PAD according to the findings listed below.\nDatabase path: %s" % __inputProjectDatabase
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' parse the project database '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')    
    __userAdminDatabase        = __worksheetGeneral.cell('B5').value                # get user admin database
    __projectName              = __worksheetGeneral.cell('B1').value                # get project name from the database
    

    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' gpj source file list '''
    
    #read the file
    __GHSListFile = open(__gpjSourceFileList)
    __GHSListFileData = __GHSListFile.read()
    __GHSListFile.close()
    
    #the file content is converted in a list
    __projectCompleteSourceList = __GHSListFileData.splitlines()
    
    #the spaces are deleted
    for index in range(len(__projectCompleteSourceList)):
        __projectCompleteSourceList[index] = __projectCompleteSourceList[index].lstrip()
    
    #we delete from the list what we do not need
    #.gpj files are not required
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (re.search("\.gpj", element) == None)]
    #.ld files are not required
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (re.search("\.ld", element) == None)]
    #.s files are not required
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (re.search("\.s", element) == None)]
    #.ppc files are not required
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (re.search("\.ppc", element) == None)]
    #.h files are not taken as source files
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (re.search("\.h", element) == None)]
    #if the path is absolut (without ".." at the beginning), we remove it: it is not appart of the RB SW; ex: compiler include files
    __projectCompleteSourceList = [element for element in __projectCompleteSourceList if (element[:2] == "..")]
    
    #we delete the double entries in the list
    for element in __projectCompleteSourceList:
        try:
            ind = __tmpProjectCompleteSourceList.index(element)
        except:
            __tmpProjectCompleteSourceList.append(element)
    
    #we delete the first double points and the first slash of each entry if required
    for index in range(len(__tmpProjectCompleteSourceList)):
        if __tmpProjectCompleteSourceList[index][:3] == "..\\":
            __tmpProjectCompleteSourceList[index] = __tmpProjectCompleteSourceList[index][3:] 
    
    #the temporary list is saved on the result list
    __projectCompleteSourceList = __tmpProjectCompleteSourceList
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' gpj header file list '''
    
    #read the temporary file where the command results is saved
    __GHSListFile = open(__gpjHeaderFileList)
    __GHSListFileData = __GHSListFile.read()
    __GHSListFile.close()
    
    #the file content is converted in a list
    __projectCompleteHeaderList = __GHSListFileData.splitlines()
    
    #if the list is empty, the command did not return any result which means that the project has still not been compiled
    #the user has to compile at least the project once to get the dependency list
    if len(__projectCompleteHeaderList) != 0: 
        # the spaces are deleted
        for index in range(len(__projectCompleteHeaderList)):
            __projectCompleteHeaderList[index] = __projectCompleteHeaderList[index].lstrip()
        
        # we delete the double entries in the list
        for element in __projectCompleteHeaderList:
            try:
                ind = __tmpProjectCompleteHeaderList.index(element)
            except:
                __tmpProjectCompleteHeaderList.append(element)
        
        # we delete the first double points of each entry when it is required
        # we complete the path to go from the script folder when it is required
        for index in range(len(__tmpProjectCompleteHeaderList)):
            if __tmpProjectCompleteHeaderList[index][:3] == "..\\":
                __tmpProjectCompleteHeaderList[index] = __tmpProjectCompleteHeaderList[index][3:] 
        
        # the temporary list is saved on the result list
        __projectCompleteHeaderList = __tmpProjectCompleteHeaderList
        
    else:
        raise Exception ("ERROR: Not possible to create the GHS include list: please compile the project\n")
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Missing source files: compare the project c files used for gbuild with the project analysis database '''
    
    for __file in __projectCompleteSourceList:
        __fileFound = False
        for __row in __worksheetDatabaseSources.rows:
            # compare the file name with the extension
            if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                __fileFound = True
                break
        # in case the file has not been found, an entry is added in the report
        if __fileFound == False:
            __reportMissingSourceFiles += "- %s\n" % __file
            
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Missing header files: compare the project h files used for gbuild with the project analysis database '''
    for __file in __projectCompleteHeaderList:
        __fileFound = False
        for __row in __worksheetDatabaseHeaders.rows:
            # compare the file name with the extension
            if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                __fileFound = True
                break
        # in case the file has not been found, an entry is added in the report
        if __fileFound == False:
            __reportMissingHeaderFiles += "- %s\n" % __file
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Not required source files: compare the project analysis database c files with the gbuild files '''
    __rowIndex = 0
    for __row in __worksheetDatabaseSources.rows:
        __rowIndex += 1
        # the first row is ignored
        if __rowIndex > 1:
            __fileFound = False
            for __file in __projectCompleteSourceList:
                # compare the file name with the extension
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                    __fileFound = True
                    break
            # in case the file has not been found, an entry is added in the report
            if __fileFound == False:
                __reportNotRequiredSourceFiles += "- Line %s, %s\n" % (str(__rowIndex),__row[__columnFile].value)
            
            
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' Not required header files: compare the project analysis database h files with the gbuild files '''
    __rowIndex = 0
    for __row in __worksheetDatabaseHeaders.rows:
        __rowIndex += 1
        # the first row is ignored
        if __rowIndex > 1:
            __fileFound = False
            for __file in __projectCompleteHeaderList:
                # compare the file name with the extension
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                    __fileFound = True
                    break
            # in case the file has not been found, an entry is added in the report
            if __fileFound == False:
                __reportNotRequiredHeaderFiles += "- Line %s, %s\n" % (str(__rowIndex),__row[__columnFile].value)
            
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' check if all required cells are filled '''
    
    ''' Responsible IDs '''
    
    __rowIndex = 0
    for __row in __worksheetDatabaseSources.rows:
        __rowIndex += 1
        # the first row is ignored
        if __rowIndex > 1:
            if __row[__columnResponsibleID].value == None:
                __reportMissingSourceResponsible += "- Line %s\n" % str(__rowIndex)
            
    __rowIndex = 0
    for __row in __worksheetDatabaseHeaders.rows:
        __rowIndex += 1
        # the first row is ignored
        if __rowIndex > 1:
            if __row[__columnResponsibleID].value == None:
                __reportMissingHeaderResponsible += "- Line %s\n" % str(__rowIndex)
    
    
    ''' Add checks here if required '''
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' create report '''
    
    # if all database checks are OK (report strings empty), the report is created but empty
    if (__reportMissingSourceFiles       == "") & \
       (__reportMissingHeaderFiles       == "") & \
       (__reportNotRequiredSourceFiles   == "") & \
       (__reportNotRequiredHeaderFiles   == "") & \
       (__reportMissingSourceResponsible == "") & \
       (__reportMissingHeaderResponsible == ""):
        report = ""
    else:
        __report = "Missing source files:\n%s\n\nMissing header file:\n%s\n\nNot required source files:\n%s\n\nNot required header files:\n%s\n\nMissing responsible IDs (sources tab):\n%s\n\nMissing responsible IDs (headers tab):\n%s"\
        % (__reportMissingSourceFiles,__reportMissingHeaderFiles,__reportNotRequiredSourceFiles,__reportNotRequiredHeaderFiles,__reportMissingSourceResponsible,__reportMissingHeaderResponsible)
    
    try:
        __reportFileHandler = open(__reportFile, 'w')
        __reportFileHandler.write(__report)
        __reportFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the txt project analysis database report file!!\n")

    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' send mail if required '''
    
    # the mail is sent only in case of findings
    if __report != "":
    
        if __sendMail.lower() == "yes":
            
            # get the name and the mail of the user using the BOSCH LDAP server
            try:
                con = ldap.initialize ('ldap://rb-gc-12.DE.bosch.com:3268')
                dn = "ad08fe@de.bosch.com"
                pw = "ad08fead08fe"
                con.simple_bind_s( dn, pw ) 
                baseDN = "DC=bosch,DC=com"
                searchScope = ldap.SCOPE_SUBTREE
                searchFilter = "cn=" + __userAdminDatabase
                result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                blub,myDict = result[0]  # works because ther's only one result
                __userMail     = str(myDict["mail"])[2:][:-2]
                __userLastname = str(myDict["givenName"])[2:][:-2]
            except:
                #the script is stopped if a user can't be found in the LDAP
                raise Exception("Project analysis database manager ERROR: No mail address has been found for the following user: " + __userAdminDatabase + "!!!")
            
            # CC users if required
            if __sendMailCC.lower() == "yes":
                
                # get the user(s) to be mailed as CC if any from the database
                __usersCC = __worksheetGeneral.cell('B4').value
                try:
                    __usersCClist = __usersCC.split()
                except:
                    # do nothing, no users defined to receive the mails as CC
                    __usersCClist = []
                
                # get the CC users mail addresses using the BOSCH LDAP server
                for __userCC in __usersCClist:
                    try:
                        con = ldap.initialize ('ldap://rb-gc-12.DE.bosch.com:3268')
                        dn = "ad08fe@de.bosch.com"
                        pw = "ad08fead08fe"
                        con.simple_bind_s( dn, pw ) 
                        baseDN = "DC=bosch,DC=com"
                        searchScope = ldap.SCOPE_SUBTREE
                        searchFilter = "cn=" + __userCC
                        result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                        blub,myDict = result[0]  # works because ther's only one result
                        __usersCCMail.append(str(myDict["mail"])[2:][:-2])
                    except:
                        # in case a CC user is not found, the scripts breaks. It makes no sense to send the mail to the default user as CC
                        raise Exception("ERROR: No mail address has been found for the following CC user: " + __userCC + "!!!")
            
            __report = "Dear %s,\n\n%s\n\n%s" % (__userLastname,__stringIntroMail,__report)
                    
            # send the mail to the user and print on the console some information
            msg = MIMEText(__report)
            msg['Subject']  = "Jenkins notifications - %s - A PAD update is required" % __projectName
            msg['From']     = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
            msg['To']       = __userMail
            msg['Cc']       = ', '.join(__usersCCMail)
            __mailSender    = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
            __mailReceivers = __usersCCMail[:] # create a copy of the list
            __mailReceivers.append(__userMail)
            s = smtplib.SMTP('rb-smtp-int.bosch.com')
            s.sendmail(__mailSender, __mailReceivers, msg.as_string())
            s.quit()
            print "-- Project analysis database manager: a mail has been sent to the database administrator %s %s\n\n" % (__userAdminDatabase,__userMail)
        else:
            # script parameter: no mail will be sent
            print "-- Project analysis database manager: No mail has been sent (project configuration).\n   To see the database check findings, please check the file %s\n\n" % __reportFile
    else:
        # no findings: no mail will be sent
        print "-- Project analysis database manager: No findings in the database, no mail has been sent.\n\n"
        
        
        
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' end of file '''
