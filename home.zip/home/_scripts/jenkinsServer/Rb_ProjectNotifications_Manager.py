# Rb_ProjectNotifications_Manager.py
#
# C. Baudry (AE_BE/ENG3)
# 09.07.2013
#
# Description:
#   This module is the first to be executed for the notification system.
#   It prepares the environment for the other sub-modules:
#    - create temp directory so that each module can save its results
#    - create a config file containing the temp directory name
#
# Parameters (inputs):
# - 1 - Temp directory
#
# Outputs:
# - temporary directory used later to save all user notifications
# - configNotifications.txt: config file containing the temp directory name
#
# Open points:
# - see TODO
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 09.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 15.01.2014 -  C. Baudry (AE-BE/ENG3)
#   Remove preparation for the database check function
#   -> this functionality will be done in a special module
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' current date '''
import datetime


def PrepareEnvironment(tempDir):
    
    # create a new temp directory for the notifications which will be started in this job
    __now = datetime.datetime.now()
    uniqueTempDir = str(__now.year) + str(__now.month) + str(__now.day) + "_" + str(__now.hour) + str(__now.minute)
    __tempUserFolder = tempDir + "\\" + uniqueTempDir
    try:
        if not os.path.exists(__tempUserFolder):
            os.makedirs(__tempUserFolder)
    except:
        raise Exception("ERROR: Impossible to create the temp folder " + __tempUserFolder + "!!\n")
    
    # create a config file containing the temp directory name
    try:
        __configFileHandler = open(os.environ.get("BCMF_TEMP_OUT") + "\\configNotifications.txt", "w")
        __configFileHandler.write(__tempUserFolder)
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to create the config file " + os.environ.get("BCMF_TEMP_OUT") + "\\configNotifications.txt" + "!!\n")



if __name__ == '__main__':

    ''' inits '''
    __tempOutPathBase = sys.argv[1]
    
    PrepareEnvironment(__tempOutPathBase)
    
    ''' end of file '''
