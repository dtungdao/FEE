# Rb_ResourcesPlot.py
#
# C. Baudry (AE_BE/ENG3)
# 10.12.2013
#
# Description:
#   This script creates a csv file containing the project ressources status:
#       - RAM in KB and in percent
#       - ROM in KB and in percent
#       - EEPROM in KB and in percent
#   For the RAM and the ROM, it gets the values reading the resource analysis
#   results of the last build.
#   For the EEPROM values, it reads an Excel file where the data is available
#   The csv file can be used later with the Jenkins Plot plugin
#
# Parameters:
# - 1 - Excel file for the EEPROM (with path)
# - 2 - Excel Worksheet for the EEPROM
# - 3 - Excel row for the EEPROM
# - 4 - Excel column for the EEPROM 
# - 5 - Resource analysis configuration file (with path)
#
# Other inputs which are not parameters:
# - resource analysis temporary file tempResourceAnalysis.txt
#   created by the script mapFileResourceAnalysis.py
#
# Outputs:
# - csv file for the Jenkins Plot plugin
#
# Open points:
# - see TODO
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 10.12.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

import shutil

''' Excel 2003 library '''
import xlrd

''' import the configuration file handler '''
from configFile import ConfigFile

''' Configuration file definitions '''
CFG_MAX_RAM              = "MAX_RAM"
CFG_MAX_ROM              = "MAX_ROM"
CFG_MAX_EEPROM           = "MAX_EEPROM"
CFG_RESOURCE_OUTPUT_PATH = "RESOURCE_OUTPUT_PATH"


if __name__ == '__main__':

    ''' inits '''
    __inputExcelEepromFile      = sys.argv[1]
    __inputExcelEepromWorksheet = sys.argv[2]
    __inputExcelEepromRow       = sys.argv[3]
    __inputExcelEepromColumn    = sys.argv[4]
    __configurationFile         = sys.argv[5]
    __strPlotReport             = ""
    __outputFile                = os.environ.get("WORKSPACE") + "\\PlotResourcesAnalysis.csv"
    
    ''' load the configuration and segment dictionaries '''
    __configurationClass = ConfigFile(__configurationFile)
    __configuration = __configurationClass.ConfigDictionary()
    
    
    ''' get the data from the analysis results file '''
    __inputResultResourceFile = __configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\tempResourceAnalysis.txt"
    try:
        __inputResultResourceFileHandler = open(__inputResultResourceFile)
        __inputResultResourceFileContent = __inputResultResourceFileHandler.readlines()
        __inputResultResourceFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the file " + __inputResultResourceFile + "!!\n")
    
    __ROMinKB       = float(__inputResultResourceFileContent[2])
    __RAMinKB       = float(__inputResultResourceFileContent[1])
    __ROMinPercent  = __ROMinKB * 100 / int(__configuration[CFG_MAX_ROM])
    __RAMinPercent  = __RAMinKB * 100 / int(__configuration[CFG_MAX_RAM])
    
    
    ''' get the data from the Excel EEPROM file '''
    __workbook        = xlrd.open_workbook(__inputExcelEepromFile)
    __worksheet       = __workbook.sheet_by_name(__inputExcelEepromWorksheet)
    __EEPROMinKB      = float(__worksheet.cell(int(__inputExcelEepromRow)-1,int(__inputExcelEepromColumn)-1).value/1024)
    __EEPROMinPercent = __EEPROMinKB * 100 / int(__configuration[CFG_MAX_EEPROM])
    
    
    ''' create the csv file '''
    __strPlotReport = "ROM_KB,RAM_KB,EEPROM_KB,ROM_Percent,RAM_Percent,EEPROM_Percent\n%s,%s,%s,%s,%s,%s" % \
                      (str(round(__ROMinKB,3)),str(round(__RAMinKB,3)),str(round(__EEPROMinKB,3)),str(round(__ROMinPercent,2)),str(round(__RAMinPercent,2)),str(round(__EEPROMinPercent,2)))
    try:
        __plotReportHandler = open(__outputFile, 'w')
        __plotReportHandler.write(__strPlotReport)
        __plotReportHandler.close()
    except:
        print "Error while trying to create the file %s." % __outputFile
    

    ''' end of file '''
