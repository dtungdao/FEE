# Rb_Polyspace_PrepareAnalysis.py
#
# C. Baudry (AE_BE/ENG3)
# 14.05.2014
#
# Description:
#   This script prepares the inputs for the Polyspace analysis: a list with the files 
#   to be analyzed and the option file containing all project include paths.
#   The source file list can be generated in 2 ways: 
#   - only the ClearCase changes since last build
#   - or all project analysis database listed files
#   In both cases the database filter can be used or not.
#
# Parameters (inputs):
# - 1 - Project database (xlsx)
# - 2 - Database filter
#           "Yes"
#           "No"
# - 3 - Polyspace source list file to be updated
# - 4 - Polyspace option file to be created
# - 5 - Switch to select how to generate the source list: it can be done 
#       based on the project analysis database or based on the last ClearCase changes
#           "ClearCaseChanges"
#           "Database"
# - 6 - Print error log on console
#           "Yes"
#           "No"
#
# Outputs:
# - Updated Polyspace source list file
# - Polyspace option file
# - Error log
#
# Open points:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 14.05.2014 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

import shutil

''' Excel 2007 library '''
import openpyxl

''' JSON '''
import json

''' URL library '''
import urllib2


if __name__ == '__main__':

    ''' inits '''
    __inputProjectDatabase          = sys.argv[1]       # - 1 - Project database (xlsx)
    __useDatabaseFilter             = sys.argv[2]       # - 2 - Database filter
    __PolyspaceSourceList           = sys.argv[3]       # - 3 - Polyspace source list file to be updated
    __PolyspaceOptionFile           = sys.argv[4]       # - 4 - Polyspace option file to be created
    __listSourceParameter           = sys.argv[5]       # - 5 - Switch to select how to generate the source list
    __printErrorLog                 = sys.argv[6]       # - 6 - Print error log on console

    __sourceFileList                = []
    __tempSourceFileList            = []
    __headerPathList                = []
    __tempHeaderPathList            = []
    __tempOptionFile                = []
    __strErrorLog                   = "\n"
    __tempOutPath                   = os.environ.get("BCMF_TEMP_OUT")
    __swViewPath                    = os.environ.get("BCMF_VIEW_PATH")
    __swBasePath                    = os.environ.get("BCMF_SOFTWARE_BASE")
    __polyspaceProjectLoc           = os.environ.get("PROJECT_LOC")
    __PolyspaceOptionFileTemplate   = __polyspaceProjectLoc + "PolyspaceOptionsTemplate.txt"
    __columnFile                    = 0
    __columnFilterPolyspace         = 10                    
    
    
    ''' parse the project database '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_Polyspace_PrepareAnalysis.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' create the source file list '''
    
    ''' list based on the project analysis database '''
    if __listSourceParameter.lower() == "database": 
        __counter = 0
        for __row in __worksheetDatabaseSources.rows:
            # the first row is ignored
            if __counter > 0:
                __fileSelected = False
                if __useDatabaseFilter.lower() == "yes":
                    try: # try/except used in the case the cell is empty
                        # check if the file is selected in the project database for the polyspace analysis
                        if __row[__columnFilterPolyspace].value.lower() == "x":
                            __fileSelected = True
                    except:
                        pass
                else:
                    __fileSelected = True
                if __fileSelected:
                    __sourceFileList.append(__swBasePath + "\\" + __row[__columnFile].value)
            __counter += 1
    
    
    ''' list based on the ClearCase changes only '''
    if __listSourceParameter.lower() == "clearcasechanges": 
        # make the URL to get the last build changes
        __buildUrl = os.environ['BUILD_URL']
        __api = __buildUrl + 'api/json/'
        
        # call the Jenkins server and figured out what changed
        __f = urllib2.urlopen(__api)
        __build = json.loads(__f.read())
        __changeSet = __build['changeSet']
        __items = __changeSet['items']
        __changesList = []
        for __item in __items:
            __changesList += __item['affectedPaths']
        
        # arrange the list to only keep the source file changes
        for __element in __changesList:
            if __element.endswith(".c"):
                __sourceFileList.append(__swViewPath + "\\" + __element)
       
        # print the file list on the console
        if not __sourceFileList:
            print "No source file changes since last build: nothing to analyse for Polyspace!"
        else:
            print "The following files have changed:"
            for __element in __sourceFileList:
                print " - " + __element
       
        # if the database filter is used, the unrequired files are removed from the list
        if __useDatabaseFilter.lower() == "yes":
            for __element in __sourceFileList:
                __fileFound    = False
                for __row in __worksheetDatabaseSources.rows:
                    # database and Jenkins file comparison
                    # -> compare the file name with the extension
                    if os.path.basename(__element).lower() == os.path.basename(__row[__columnFile].value).lower():
                        __fileFound = True
                        try: # try/except used in the case the cell is empty
                            # check if the file is selected in the project database for the metrics analysis
                            if __row[__columnFilterPolyspace].value.lower() == "x":
                                __tempSourceFileList.append(__element)
                        except:
                            pass
                        break
                
                # log: case the file has not been found
                if __fileFound == False:
                    __strErrorLog += "-- Polyspace preparation warning: the following file has not been found in the project database: %s\n" % __element
            
            __sourceFileList = __tempSourceFileList 
            
            # print the file list on the console
            if not __sourceFileList:
                print "Project analysis database filter: nothing to analyze!"
            else:
                print "According to the project analysis database filter, from the changed files the following files will be analyzed:"
                for __element in __sourceFileList:
                    print " - " + __element
       
    ''' update the Polyspace source list file '''
    try:
        __tempFileHandler = open(__PolyspaceSourceList, 'w')
        for __element in __sourceFileList:
            __tempFileHandler.write("%s\n" % __element)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to edit the file " + __PolyspaceSourceList + "!!\n")  
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' create the header file list '''
    # get all header files
    for __row in __worksheetDatabaseHeaders.rows:
        # remove the file name to keep only the directory name
        __temp = os.path.split(__row[__columnFile].value)
        __headerPathList.append("-I " + __swBasePath + "\\" + __temp[0].lower())
        
    # delete the double entries in the list
    for __element in __headerPathList:
        try:
            __ind = __tempHeaderPathList.index(__element)
        except:
            __tempHeaderPathList.append(__element)
            
    __headerPathList = __tempHeaderPathList
    
    ''' create the Polyspace option file based on the template file '''
    # save the template file content into a list
    try:
        __tempFileHandler = open(__PolyspaceOptionFileTemplate)
        __tempFileHandlerData = __tempFileHandler.readlines()
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the file " + __PolyspaceOptionFileTemplate + "!!\n")  
    
    # remove all existing include paths in the option file if any (the synthax is "-I ")
    for __element in __tempFileHandlerData:
        if re.search("-I ",__element) == None:
            __tempOptionFile.append(__element.rstrip())
            
    # merge the remaining options and the newly created header path list
    __tempOptionFile = __tempOptionFile + __headerPathList
    
    # create the option file
    try:
        __tempFileHandler = open(__PolyspaceOptionFile, 'w')
        for __element in __tempOptionFile:
            __tempFileHandler.write("%s\n" % __element)
        __tempFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to edit the file " + __PolyspaceOptionFile + "!!\n")  
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\PolyspacePreparationErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\PolyspacePreparationErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Polyspace preparation error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    
    ''' end of file '''
