# Rb_QAC_SpecificWarnings.py
#
# C. Baudry (AE_BE/ENG3)
# 20.05.2014
#
# Description:
#   This module looks for configured QAC warnings in the whole QAC output.
#   It is possible to configure these warnings in a separate file.
#   A JSON database and a html report are created with all findings. 
#   
# Parameters (inputs):
# - 1 - Path where to find the qac output files
# - 2 - QAC specific warnings configuration
# - 3 - Print error log on console
#           "Yes"
#           "No"
#
# Outputs:
# - JSON database containing all findings: fixed name QacSpecificWarningsExport.json
# - HTML report with warnings list
# - error log
#
# Open points:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 20.05.2014 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 23.05.2014 -  C. Baudry (AE-BE/ENG3)
#   The warning level is not given in the report
#   Title "Line,Column" instead of "Position" in the report
#---------------------------------------------------------------------------
# Version 001.02 - 05.08.2014 -  C. Baudry (AE-BE/ENG3)
#   - Correct the way the QAC html files are parsed: in some cases the 
#     warnings was not seen
#---------------------------------------------------------------------------


''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

import shutil

import json


if __name__ == '__main__':

    ''' inits '''
    __qacOutputFilesPath            = sys.argv[1]
    __qacSpecificConfigFile         = sys.argv[2]
    __printErrorLog                 = sys.argv[3]

    __specificWarningsList          = []
    __specificWarningsDict          = {}
    __strErrorLog                   = "\n"
    __tempOutPath                   = os.environ.get("BCMF_TEMP_OUT")
    __completeHtmlReport            = ""    

    
    ''' parse the QAC specific warnings configuration file '''
    ''' file format: Warning_Number Comment '''
    try:
        __configFileHandler = open(__qacSpecificConfigFile)
        __configuration = __configFileHandler.readlines()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the file " + __qacSpecificConfigFile + "!!\n")

    # create a list containing the configured specific warnings
    for __element in __configuration:
        __searchResult = re.search("([0-9]+).*",__element)
        if __searchResult:
            __specificWarningsList.append(__searchResult.group(1))
        

    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' QAC output HTML files analysis '''
    # Parse the QAC output files directory looking for html files
    # There is 2 kinds of QAC HTML report: _rep.html, .html
    #    The .html reports contains the data we needs
    # Parse the html files and collect all required information
    
    for __root, __dirs, __files in os.walk(__qacOutputFilesPath):
        for __file in __files:
            if __file.endswith(".c.html"):
                try:
                    __fileHandler = open(__qacOutputFilesPath + "\\" + __file)
                    __fileContent = __fileHandler.readlines()
                    __fileHandler.close()
                except:
                    raise Exception("ERROR: Impossible to read the file " + __qacOutputFilesPath + "\\" + __file + "!!\n")
                
                # go through the output file looking for all required specific warnings
                for index in range(len(__fileContent)):
                    # remove the html tags at the end of the line
                    try:
                        __splitedLine =  __fileContent[index].split("..<")
                        __fileContent[index] = __splitedLine[0]
                    except:
                        pass
                    # if the line contains a warning, it is further analysed (Warning format: Msg(1:3227))
                    __searchResult = re.search(".*>(.*)\(([0-9]+,[0-9]+)\): Msg\(([0-9]):([0-9]+)\) (.*)\n*",__fileContent[index])
                    if __searchResult:
                        for __warning in __specificWarningsList:
                            if __warning == __searchResult.group(4):
                                # get file name
                                __fileName = __searchResult.group(1)
                                # get position
                                __position = __searchResult.group(2)
                                # get warning level
                                __warningLevel = __searchResult.group(3)
                                # get warning number
                                __warningNumber = __searchResult.group(4)
                                # get warning description
                                __warningDescription = __searchResult.group(5)

                                # init dict of dict if required
                                if not __fileName in __specificWarningsDict:
                                    __specificWarningsDict[__fileName] = {}
                                if not __position in __specificWarningsDict[__fileName]:
                                    __specificWarningsDict[__fileName][__position] = {}
                                
                                # save warning info in the dict
                                __specificWarningsDict[__fileName][__position] = "%s::::%s::::%s" %(__warningLevel,__warningNumber,__warningDescription)
                      
                      
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' JSON export '''
    json.dump(__specificWarningsDict, open(__tempOutPath + "\\" + "QacSpecificWarningsExport.json", "w"),sort_keys=True, indent=4)
    
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' HTML report '''

    __completeHtmlReport = "<FONT FACE='Arial' SIZE=-1><table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File</th><th align='left'>Line,Column</th><th align='left'>Warning number</th><th align='left'>Description</th></tr>"
    
    for __file in __specificWarningsDict:
        for __position in __specificWarningsDict[__file]:
            __splitedLine = __specificWarningsDict[__file][__position].split("::::")
            __warningLevel = __splitedLine[0]   # not used
            __warningNumber = __splitedLine[1]
            __warningDescription = __splitedLine[2]
            __completeHtmlReport += "<tr><td align='left'>%s</td><td align='left'>%s</td><td align='left'>%s</td><td align='left'>%s</td></tr>" % (__file,__position,__warningNumber,__warningDescription)
    
    __completeHtmlReport += "</table><br><br></FONT>"

    try:
        __tempFileHandler = open(__tempOutPath + "\\QacSpecificWarningsAnalysisReport.html", 'w')
        __tempFileHandler.write(__completeHtmlReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\QacSpecificWarningsAnalysisReport.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the file QacSpecificWarningsAnalysisReport.html!!\n")
        
    
    ''' ------------------------------------------------------------------------------------------------------------------------------------------'''
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\QacSpecificWarningsErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\QacSpecificWarningsErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the file QacSpecificWarningsErrorLog.txt!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    
    ''' end of file '''
