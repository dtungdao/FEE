# Rb_MetricsNotifier.py
#
# C. Baudry (AE_BE/ENG3)
# 26.07.2013
#
# Description:
#   This script creates a report for each user who has metrics outside the allowed range. 
#   It is based on the JSON database which is created in the script Rb_MetricsAnalysis.py.
#   It uses the project analysis database to get the file responsible names.
#   The metrics to be analysed and their ranges can be configured in a separate configuration file.
#
# Parameters (inputs):
# - 1 - JSON metrics database from the metrics analysis script
# - 2 - Project database (xlsx)
# - 3 - Metrics configuration file
# - 4 - Print error log on console
#           "Yes"
#           "No"
#
# Other inputs which are not parameters
# - Notifier configuration file configNotifications.txt
#
# Outputs:
# - error log
# - results log
# - results log per user
#
# Open points:
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 26.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 10.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Comments update
#   Add support for CMA metrics
#---------------------------------------------------------------------------
# Version 003.00 - 13.09.2013 -  C. Baudry (AE-BE/ENG3)
#   The metrics analysis is now done in the script Rb_MetricsAnalysis.py.
#   The analysis is imported via a JSON database file 
#---------------------------------------------------------------------------
# Version 003.01 - 12.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - Correct some comments
#   - Add a description of each metric in an HTML table and a link to the 
#     file "SW metrics.pptx"
#---------------------------------------------------------------------------
# Version 003.02 - 18.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - Put the description of each metric at the end of the notification
#   - Modify the notification general text
#   - Add a check for the project analysis database version
#---------------------------------------------------------------------------
# Version 004.00 - 10.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Add the support for the evaluated metric violations
#---------------------------------------------------------------------------
# Version 004.01 - 14.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 004.02 - 16.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#   - Remove database checks: done in the database manager
#---------------------------------------------------------------------------
# Version 004.03 - 30.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Metric configuration with min condition: add support for float values
#---------------------------------------------------------------------------

''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' Excel 2007 library '''
import openpyxl

import shutil

import json


if __name__ == '__main__':

    ''' inits '''
    __JsonDatabasePath       = sys.argv[1]
    __inputProjectDatabase   = sys.argv[2]
    __metConfigFile          = sys.argv[3]
    __printErrorLog          = sys.argv[4]
    __columnFile             = 0 
    __columnResponsibleID    = 3
    __strErrorLog            = "\n"
    __strResultsLog          = ""
    __userList               = []
    __metricsNotificationList= []
    __metricsDict            = {}
    __dictFileResponsibles   = {}
    __tempUserList           = []
    __tempOutpath            = os.environ.get("BCMF_TEMP_OUT")
    __sofwarePath            = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolchainConfigPath    = os.environ.get("BCMF_CFG_ROOT")
    __outputFileName         = "MetricsNotifierResults.txt"
    __mailMessageModule      = "<hr><B><U>Metrics notifications</U></B><br>\
    <br>The files and functions listed below report SW metrics which are outside the defined range (see grey cells).\
    <br>The metrics shown in yellow cells have already been evaluated."
    __mailMessageExplainationMetrics = \
    "<br>Metrics definition:<br>\
    <TABLE BORDER='0'><FONT FACE='Arial' SIZE=-1>\
    <TR><TD>STCYC</TD><TD></TD><TD>&nbsp;Cyclomatic Complexity</TD></TR>\
    <TR><TD>STPTH</TD><TD>&nbsp;PATH </TD><TD>&nbsp;Number of non-cyclic paths in this function</TD></TR>\
    <TR><TD>STST3</TD><TD>&nbsp;STMT </TD><TD>&nbsp;Number of statements of considered function</TD></TR>\
    <TR><TD>STPAR</TD><TD>&nbsp;PARAM</TD><TD>&nbsp;Number of interface parameters of considered function</TD></TR>\
    <TR><TD>STMIF</TD><TD>&nbsp;LEVEL</TD><TD>&nbsp;Maximum nesting level inside considered function</TD></TR>\
    <TR><TD>STCAL</TD><TD>&nbsp;CALLS</TD><TD>&nbsp;Number of distinct function calls in considered function</TD></TR>\
    <TR><TD>STM19</TD><TD>&nbsp;RETURN</TD><TD>&nbsp;Number of exit points of this function</TD></TR>\
    <TR><TD>STGTO</TD><TD>&nbsp;GOTO</TD><TD>&nbsp;Number of gotos in considered function</TD></TR>\
    <TR><TD>STM29</TD><TD>&nbsp;CALLING</TD><TD>&nbsp;Number of functions calling this function (cross project)</TD></TR>\
    <TR><TD>STNRA</TD><TD>&nbsp;ap_cg_cycle</TD><TD>&nbsp;Number of call graph recursions across project</TD></TR>\
    </TABLE></FONT>\
    <br>You can find more information about SW metrics in this document: <a href='https://inside-ilm.bosch.com/irj/go/nui/sid/download/80342652-fb28-3110-ada7-d80b1fc801c1'>Powerpoint SW metrics</a><br>"
        
    
    ''' get environment config '''
    # read the config file to get the current notification output path
    try:
        __configFileHandler = open(__tempOutpath + "\\configNotifications.txt")
        __tempNotificationOutPath = __configFileHandler.read()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the config file " + __tempOutpath + "\\configNotifications.txt!!\n")
    
    
    ''' parse the project databases '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral         = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_MetricsNotifier.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' Default user is used in case no responsible is defined '''
    __userDefault = __worksheetGeneral.cell('B3').value    
    
    
    ''' JSON metrics database import '''
    
    __jsonData = open(__JsonDatabasePath)
    __jsonImportDict = json.load(__jsonData)
    __jsonData.close()
    
    #get files responsible
    __dictFileResponsibles = {}
    for __file in __jsonImportDict:
        
        __found = False
        __rowNumber = 0
    
        # first check in the sources database
        for __row in __worksheetDatabaseSources.rows:
            __rowNumber += 1
            # database and metrics file comparison
            # -> compare only the file name
            if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
            
                # case the responsible cell is empty
                if __row[__columnResponsibleID].value == None:
                    __userList.append(__userDefault)
                    __userID = __userDefault
                    __strErrorLog += "-- Metrics Notifier warning: Responsible not given in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                
                # case the responsible cell contains non-word characters
                elif re.search("\W",__row[__columnResponsibleID].value):
                    __userList.append(__userDefault)
                    __userID = __userDefault
                    __strErrorLog += "-- Metrics Notifier warning: Responsible syntax not correct in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                
                # good case
                else:
                    __userList.append(__row[__columnResponsibleID].value)
                    __userID = __row[__columnResponsibleID].value
                
                __found = True
        
        # then check in the headers database if not found in the sources database
        if __found == False:
            __rowNumber = 0
            for __row in __worksheetDatabaseHeaders.rows:
                __rowNumber += 1
                # database and metrics file comparison
                # -> compare only the file name
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                
                    # case the responsible cell is empty
                    if __row[__columnResponsibleID].value == None:
                        __userList.append(__userDefault)
                        __userID = __userDefault
                        __strErrorLog += "-- Metrics Notifier warning: Responsible not given in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    
                    # case the responsible cell contains non-word characters
                    elif re.search("\W",__row[__columnResponsibleID].value):
                        __userList.append(__userDefault)
                        __userID = __userDefault
                        __strErrorLog += "-- Metrics Notifier warning: Responsible syntax not correct in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    
                    # good case
                    else:
                        __userList.append(__row[__columnResponsibleID].value)
                        __userID = __row[__columnResponsibleID].value
                    
                    __found = True
                
        
        if __found == False:
            # if the metric file has not been found in the project database, the default user is used
            __userList.append(__userDefault)
            __userID = __userDefault
            __strErrorLog += "-- Metrics Notifier warning: File %s not found in the databases\n    --> Default user used for notification\n" % __file


        #responsible for this file: __userID
        __dictFileResponsibles[__file] = __userID  
    
    
    
    ''' sort the user list alphabetically and remove the doubles '''
    for __user in __userList:
        try:
            ind = __tempUserList.index(__user)
        except:
            __tempUserList.append(__user)
    __userList = __tempUserList
    __userList.sort()
    
    
    ''' parse the metrics configuration file '''
    ''' file format: METRIC_NAME RANGE '''
    try:
        __metricConfigFileHandler = open(__metConfigFile)
        __metricsConfiguration = __metricConfigFileHandler.readlines()
        __metricConfigFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the metric config file " + __metConfigFile + "!!\n")

    #create a metric list for the notification based on the config file
    __metricsNotificationList = []
    for indexMetricConfig in range(len(__metricsConfiguration)):
        __metricsNotificationList.append(__metricsConfiguration[indexMetricConfig].split()[0])
        
    #create a metrics dictionary which contains the thresholds
    __metricsDict = {}
    for indexMetricConfig in range(len(__metricsConfiguration)):
        __metricsDict[__metricsConfiguration[indexMetricConfig].split()[0]] = __metricsConfiguration[indexMetricConfig].split()[1]
    
    
    ''' create a metrics report per user '''
    for __user in __userList:
        
        __strResultsUser = "<FONT FACE='Arial' SIZE=-1>%s<br><br>" % __mailMessageModule
        __strResultsUserTmp = ""
        __userMail = ""
        __found = False
        __userNotificationRequired = False
        __highlightStr = ""
        
        
        # if not already done: create a folder especially for the user with as name the user id
        __tempUserFolder = __tempNotificationOutPath + "\\" + __user
        if not os.path.exists(__tempUserFolder):
            os.makedirs(__tempUserFolder)
        
        
        #columns names
        __strResultsUser += "<table border='1'><FONT FACE='Arial' SIZE=-1><tr BGCOLOR='#D6D6D6'><th align='left'>File name</th><th align='left'>Function name</th>"
        
        #dynamic columns names (depending on how many metrics are configured)
        #the checked metrics list is used
        for __metricName in __metricsNotificationList:
            __strResultsUser += "<th width='50'>%s</th>" % __metricName
        #end of html line
        __strResultsUser += "</tr>"
        
        
        for __currentFileName in __jsonImportDict:
            
            __currentUser = __dictFileResponsibles[__currentFileName]
            
            for __currentFunctionName in __jsonImportDict[__currentFileName]:
                __corruptedFunction   = False                      
            
                if __user == __currentUser:
                
                    __strResultsUserTmp = "<tr><td align='left'>%s</td><td align='left'>%s</td>" % (os.path.basename(__currentFileName),__currentFunctionName)
                
                    #get the different metrics and their values
                    for __metricName in __metricsNotificationList:
                        __metricFound = False
                        for __currentMetric in __jsonImportDict[__currentFileName][__currentFunctionName]:
                            if __metricName == __currentMetric:
                                #we ignore the metric if it has the value "-"
                                if __jsonImportDict[__currentFileName][__currentFunctionName][__currentMetric] != "-":
                                    
                                    #get the metric value and the metric evaluation comment if present 
                                    try:
                                        __metricValue = __jsonImportDict[__currentFileName][__currentFunctionName][__currentMetric].split("***")[0]
                                        try:
                                            __metricEvaluationComment = __jsonImportDict[__currentFileName][__currentFunctionName][__currentMetric].split("***")[1]
                                        except:
                                            __metricEvaluationComment = ""
                                    except:
                                        __metricValue = __jsonImportDict[__currentFileName][__currentFunctionName][__currentMetric]
                                        __metricEvaluationComment = ""
                                        
                                    #color in the report: grey if the violation has not been evaluated, yellow if it has been.
                                    if __metricEvaluationComment == "": 
                                        __bgColor = "#BDBDBD" #grey
                                    else: 
                                        __bgColor = "#F2F5A9" #yellow
                                    
                                    __metricFound = True
                                
                                    #get the configured metric condition
                                    __checkCondition = __metricsDict[__metricName]
                                
                                    #case the condition is a range
                                    if re.search("([0-9])-([0-9])",__checkCondition):
                                        __rangeMin = float(re.split("-",__checkCondition)[0])
                                        __rangeMax = float(re.split("-",__checkCondition)[1])
                                
                                        #check the metric value according to the configured range (only if the metric has not been evaluated)
                                        if (float(__metricValue) > __rangeMax) | (float(__metricValue) < __rangeMin): 
                                            #outside range! 
                                            __strResultsUserTmp += "<td bgcolor='%s' align='center'>%s</td>" % (__bgColor,__metricValue)
                                            #corrupted function and general user notification required if the metric has not been evaluated
                                            if __metricEvaluationComment == "":
                                                __userNotificationRequired = True
                                                __corruptedFunction        = True
                                        else:
                                            __strResultsUserTmp += "<td align='center'>%s</td>" % __metricValue
                                            
                                    #case the condition is a min
                                    if re.search("[0-9]+\.*[0-9]*-\*",__checkCondition):
                                        __min = float(re.split("-",__checkCondition)[0])
                            
                                        #check the metric value according to the configured min value (only if the metric has not been evaluated)
                                        if ((float(__metricValue) < __min)): 
                                            #outside range!
                                            __strResultsUserTmp += "<td bgcolor='%s' align='center'>%s</td>" % (__bgColor,__metricValue)
                                            #corrupted function and general user notification required if the metric has not been evaluated
                                            if __metricEvaluationComment == "":
                                                __userNotificationRequired = True
                                                __corruptedFunction        = True
                                        else:
                                            __strResultsUserTmp += "<td align='center'>%s</td>" % __metricValue
                    
                        #case no metric info for the given function or file: empty cell
                        if __metricFound != True:
                            __strResultsUserTmp += "<td align='center'>-</td>"

                    #end of html line
                    __strResultsUserTmp += "</tr>"
                
                if __corruptedFunction == True:
                    __strResultsUser += __strResultsUserTmp
                        
       
        # user notification if required
        if __userNotificationRequired == True:
        
            __strResultsUser += "</table>%s<br><br></FONT>" % __mailMessageExplainationMetrics
            __strResultsLog  += __strResultsUser
            
            try:
                __tempFileHandler = open(__tempUserFolder + "\\" + __outputFileName, 'w')
                __tempFileHandler.write(__strResultsUser)
                __tempFileHandler.close()
                print "-- Metrics Notifier: create a metrics list for user %s" % __user
            except:
                raise Exception("ERROR: Impossible to create the Metrics Notifier results user file!!\n")
    
    
    ''' results log file '''
    try:
        __tempFileHandler = open(__tempNotificationOutPath + "\\MetricsNotifierResultsLog.html", 'w')
        __tempFileHandler.write(__strResultsLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempNotificationOutPath + "\\MetricsNotifierResultsLog.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Metrics Notifier results log file!!\n")
        
        
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempNotificationOutPath + "\\MetricsNotifierErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempNotificationOutPath + "\\MetricsNotifierErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Metrics Notifier error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    ''' end of file '''
