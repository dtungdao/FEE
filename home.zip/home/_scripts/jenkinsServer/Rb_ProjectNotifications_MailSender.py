# Rb_ProjectNotifications_MailSender.py
#
# C. Baudry (AE_BE/ENG3)
# 17.07.2013
#
# Description:
#   This script merges all user reports and sends for each user a mail.
#   It uses the Bosch LDAP server to get the email addresses
#
# Parameters (inputs):
# - 1 - Print error log on console
#           "Yes"
#           "No"
# - 2 - Project database (xlsx)
#
# Other inputs which are not parameters
# - Notifier configuration file configNotifications.txt
#
# Outputs:
# - Mails
# - error log
#
# Open points:
# - see TODO
#
# Information:
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 17.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 22.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Send the email with html format 
#---------------------------------------------------------------------------
# Version 001.01 - 10.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Comments update
#---------------------------------------------------------------------------
# Version 001.02 - 18.09.2013 -  C. Baudry (AE-BE/ENG3)
#   - Improve the failure cases debug possibilities
#   - Stop the script in case the default user is not found in the LDAP
#   - LDAP server alias update according to 
#     https://inside-wiki.bosch.com/confluence/x/DkNeCQ
#---------------------------------------------------------------------------
# Version 003.00 - 18.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - Add the possibility to send the mails to CC users
#   - Add a check for the project analysis database version
#   - Modify the mail general text
#---------------------------------------------------------------------------
# Version 003.01 - 14.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version: 4
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 003.02 - 16.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version: 5
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 003.03 - 13.02.2014 -  C. Baudry (AE-BE/ENG3)
#   Dynamic project name for the mail object 
#---------------------------------------------------------------------------


''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' mail functions '''
import smtplib
from email.mime.text import MIMEText

''' LDAP library '''
import ldap

import shutil

''' Excel 2007 library '''
import openpyxl


if __name__ == '__main__':

    #
    # The current output folder will be parsed to look for the different users reports.
    # These reports will be then merged and sent to the users
    #
    
    ''' inits '''
    __printErrorLog        = sys.argv[1]
    __inputProjectDatabase = sys.argv[2]
    __tempOutpath          = os.environ.get("BCMF_TEMP_OUT")
    __loopDirs             = 0
    __loopFiles            = 0
    __mailMessageGeneral   = "<br><br>This mail contains findings of the latest Jenkins run. Please have a look at them.<br>\
                              It does NOT mean that you have to modify files immediately.<br>\
                              Please contact your SW PrL to schedule the changes.<br>\
                              You receive this email because you are the module responsible according to the project analysis database.<br><br><br>"
    __strErrorLog          = ""
    __usersCCList          = []
    __usersCCMail          = []
    

    ''' open the project analysis database '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetGeneral = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_ProjectNotifications_MailSender.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
    
    
    ''' get some information from the project analysis database '''
    __userDefault = __worksheetGeneral.cell('B3').value                # get default user database
    __projectName = __worksheetGeneral.cell('B1').value                # get project name from the database
    
    
    ''' get the user(s) to be mailed as CC if any from the database '''
    __usersCC = __worksheetGeneral.cell('B4').value
    try:
        __usersCClist = __usersCC.split()
    except:
        # do nothing, no users defined to receive the mails as CC
        __usersCClist = []
    
    
    ''' get the CC users mail addresses using the BOSCH LDAP server '''
    for __userCC in __usersCClist:
        try:
            con = ldap.initialize ('ldap://rb-gc-12.DE.bosch.com:3268')
            dn = "ad08fe@de.bosch.com"
            pw = "ad08fead08fe"
            con.simple_bind_s( dn, pw ) 
            baseDN = "DC=bosch,DC=com"
            searchScope = ldap.SCOPE_SUBTREE
            searchFilter = "cn=" + __userCC
            result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
            blub,myDict = result[0]  # works because ther's only one result
            __usersCCMail.append(str(myDict["mail"])[2:][:-2])
        except:
            # in case a CC user is not found, the scripts breaks. It makes no sense to send the mail to the default user as CC
            raise Exception("ERROR: No mail address has been found for the following CC user: " + __userCC + "!!!")

    
    ''' get environment config '''
    # read the config file to get the current output path
    try:
        __configFileHandler = open(__tempOutpath + "\\configNotifications.txt")
        __tempOutPath = __configFileHandler.read()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the config file " + __tempOutpath + "\\configNotifications.txt!!\n")
    
    
    ''' prepare and send the mail for each user '''
    for __root, __dirs, __files in os.walk(__tempOutPath):
        
        # the first item is the temp dir itself, it can be ignored
        if __loopDirs > 0:
            
            # inits
            __foundUser       = False
            __reportAvailable = False
            __loopFiles       = 0
            
            # the user name is the directory name
            __user = os.path.basename(__root)
        
            # get the reports for the current user and merge them in 1 txt file
            for __currentFile in __files:
                
                __loopFiles += 1
                
                # to be done only once per user directory:
                if __loopFiles == 1:
                    # get the name and the mail of the user using the BOSCH LDAP server
                    try:
                        con = ldap.initialize ('ldap://rb-gc-12.DE.bosch.com:3268')
                        dn = "ad08fe@de.bosch.com"
                        pw = "ad08fead08fe"
                        con.simple_bind_s( dn, pw ) 
                        baseDN = "DC=bosch,DC=com"
                        searchScope = ldap.SCOPE_SUBTREE
                        searchFilter = "cn=" + __user
                        result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                        blub,myDict = result[0]  # works because ther's only one result
                        __userMail     = str(myDict["mail"])[2:][:-2]
                        __userLastname = str(myDict["givenName"])[2:][:-2]
                        __foundUser = True
                    except:
                        __strErrorLog += "-- Mail Sender warning: No mail address has been found for the following user: %s\n    --> Default configured user used: %s\n" % (__user,__userDefault)
                        try:
                            searchFilter = "cn=" + __userDefault
                            result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                            blub,myDict = result[0]  # works because ther's only one result
                            __userMail     = str(myDict["mail"])[2:][:-2]
                            __userLastname = str(myDict["givenName"])[2:][:-2]
                            __foundUser = True
                        except:
                            #the script is stopped if a user can't be found in the LDAP
                            #get the chance to see the errors before terminating the script
                            __strErrorLog += "-- Mail Sender error: No mail address has been found for the following user: %s.    --> The mail won't be sent\n" % __userDefault
                            print __strErrorLog
                            raise Exception("ERROR: No mail address has been found for the following user: " + __userDefault + "!!!")
                            __userLastname = "(Unknown)" #useful in the case we decide to change the script not raising an exception here
                            __foundUser = False          #useful in the case we decide to change the script not raising an exception here
                    
                    # if we get there that means there are 1 or more reports for the user: we can create the main report
                    try:
                        __mergedFileHandler = open(__tempOutPath + "\\mergedReport_" + __user + ".txt", 'w')
                        __mergedFileHandler.write("<FONT FACE='Arial' SIZE=-1>Dear %s,%s" % (__userLastname,__mailMessageGeneral))
                        __mergedFileHandler.close()
                        __reportAvailable = True
                    except:
                        #get the chance to see the errors before terminating the script
                        print __strErrorLog
                        raise Exception("ERROR: Impossible to create the report for the user " + __user + "!!\n")
                
                # to be repeated for each file in the user directory
                # read the report
                try:
                    __currentFileHandler = open(__root + "\\" + __currentFile)
                    __currentFileContent = __currentFileHandler.read()
                    __currentFileHandler.close()
                except:
                    #get the chance to see the errors before terminating the script
                    print __strErrorLog
                    raise Exception("ERROR: Impossible to read the report file " + __root + "\\" + __currentFile + "!!\n")
            
                # write the report in a user report where all reports are merged
                try:
                    __mergedFileHandler = open(__tempOutPath + "\\mergedReport_" + __user + ".txt", 'a')
                    __mergedFileHandler.write(__currentFileContent)
                    __mergedFileHandler.close()
                except:
                    #get the chance to see the errors before terminating the script
                    print __strErrorLog
                    raise Exception("ERROR: Impossible to create the report for the user " + __user + "!!\n")
            
            if __foundUser == True & __reportAvailable == True:

                # send the mail to the user and print on the console some information
                __tempFileHandler = open(__tempOutPath + "\\mergedReport_" + __user + ".txt", 'rb')
                msg = MIMEText(__tempFileHandler.read(),'html')
                msg['Subject']  = "Jenkins notifications - %s project" % __projectName
                msg['From']     = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
                msg['To']       = __userMail
                msg['Cc']       = ', '.join(__usersCCMail)
                __mailSender    = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
                __mailReceivers = __usersCCMail[:] # create a copy of the list
                __mailReceivers.append(__userMail)
                s = smtplib.SMTP('rb-smtp-int.bosch.com')
                s.sendmail(__mailSender, __mailReceivers, msg.as_string())
                s.quit()
                print "-- Mail Sender: send a notification mail to the user %s %s" % (__user,__userMail)
                
        __loopDirs += 1
    
    
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\MailSenderErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\MailSenderErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Mail Sender error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
        
        
    ''' end of file '''