# Rb_BCMF_3_RunCMA.py
#
# C. Baudry (AE_BE/ENG3)
# 25.02.2013
#
# Description:
#   This script calls the CMA tool.
#
# Parameters (inputs):
# - 1 - QAC configuration file
#
# Outputs:
# - QAC CMA analysis outputs
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 25.02.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess

''' import the configuration file handler '''
from configFile import ConfigFile

import datetime


if __name__ == '__main__':
    
    ''' parameters: QAC configuration file '''
    __qac_configuration_file = sys.argv[1]
    
    ''' get configuration for QAC '''
    __qac_configuration = ConfigFile(__qac_configuration_file).ConfigDictionary()
    
    ''' initializations ''' 
    __tempOutpath = os.environ.get("BCMF_TEMP_OUT")
    
    # get qacTmp.txt file content to initialize some variables
    __qacTmpFile = __tempOutpath + "\\qacTmp.txt"
    __qacTmpFileHd = open(__qacTmpFile)
    __qacTmpFileData = __qacTmpFileHd.read()
    __qacTmpFileHd.close()
    __qacTmpFileDataLines = __qacTmpFileData.splitlines()
       
    __viaFile         = __qacTmpFileDataLines[3]
    __prefix          = __qacTmpFileDataLines[6]
    __qacOutputFolder = __qac_configuration["QAC_OUTPATH"] + "\\" + __prefix + "_Output"
    __qacLstFile      = __qacOutputFolder + "\\filelist.lst"
    __toolsPath       = os.environ.get("BCMF_TOOLS_ROOT")
    
    ''' set QAC special env variables '''
    os.environ['QACBIN']       = __toolsPath + "\\QAC\\bin"
    os.environ['QACOUTPATH']   = __qacOutputFolder
    os.environ['QACHELPFILES'] = __toolsPath + "\\QAC\\help"
    
    ''' run CMA '''
    print "- Run Cross Module Analyse (CMA)"
    
    __startTime = datetime.datetime.now()
    print "  CMA start time: " + str(__startTime)[:-7]
    
    __command = __qac_configuration["QAC_CMA"] + " QAC -cmaf " + __qacOutputFolder + " -via " + __viaFile + " -list " + __qacLstFile
    os.system(__command)
    
    __endTime = datetime.datetime.now()
    print "  CMA end time: " + str(__endTime)[:-7]
    __CMADuration = __endTime - __startTime
    print "  CMA duration: " + str(__CMADuration)[:-7]
    
    ''' end of file '''
    