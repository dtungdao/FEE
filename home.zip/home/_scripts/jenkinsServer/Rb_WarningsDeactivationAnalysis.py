# Rb_WarningsDeactivationAnalysis.py
#
# C. Baudry (AE_BE/ENG3)
# 16.09.2013
#
# Description:
#   This script parses all files listed in the project analysis database.
#   It looks for the GHS pragmas used to deactivate / activate compiler warnings.
#   It create a txt report containing the list of all deactivated warnings found in the SW.
#   The deactivation comments are searched in the pragma line or the line before.
#   The warnings which are deactivated without beeing activated again are listed in the 
#   part "File deactivations".
#   This script checks also the compiler configuration and looks for globally disabled 
#   warnings. It uses for that the ghs gbuild tool.
#
# Parameters (inputs):
# - 1 - Project database (xlsx)
# - 2 - GPJ file to be analyzed to get the ghs options
# - 3 - Project ghs option file to read the comments of the globally disabled warnings
# - 4 - Print error log on console
#           "Yes"
#           "No"
#
# Outputs:
# - Txt report with all deactivated warnings
#
# Notice:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 16.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 19.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Add support for the globally disabled warnings
#---------------------------------------------------------------------------
# Version 002.01 - 19.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Correct Excel file import: the first row of both source and header 
#   sheets is not required
#---------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

import shutil

''' Excel 2007 library '''
import openpyxl

from datetime import datetime


if __name__ == '__main__':
    
    ''' inits '''
    __inputProjectDatabase         = sys.argv[1]
    __gpjFile                      = sys.argv[2]
    __ghsOptionFile                = sys.argv[3]
    __printErrorLog                = sys.argv[4]
    __sofwarePath                  = os.environ.get("BCMF_SOFTWARE_BASE")
    __tempOutPath                  = os.environ.get("BCMF_TEMP_OUT")
    __compilerPath                 = os.environ.get("BCMF_COMPILER_ROOT")
    __columnFile                   = 0
    __strErrorLog                  = ""
    __reportGlobalDeactivation     = ""
    __reportFileDeactivation       = ""
    __reportLocalDeactivation      = ""
    __numberGlobalDeactivation     = 0
    __numberFileDeactivation       = 0
    __numberLocalDeactivation      = 0
    __strReport                    = ""
    __strReportHeader              = "Warning deactivation report\nGenerated on %s\n\n\n" % str(datetime.now())
    __dictGlobalWarnings           = {}
    
    ''' parse the project database '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral  = __workbook.get_sheet_by_name('General')
    __mergedWorksheet   = __worksheetDatabaseSources.rows[1:] + __worksheetDatabaseHeaders.rows[1:]
    
    ''' parse the files looking for the warnings deactivation patterns '''
    for __row in __mergedWorksheet:
        __file = __row[__columnFile].value
        #get the file content
        try:
            __fileHandler = open(__sofwarePath + "\\" + __file)
            __fileContent = __fileHandler.readlines()
            __fileHandler.close()
        except:
            __strErrorLog = __strErrorLog + "-- Warnings Deactivation Analysis: File " + __sofwarePath + "\\" +__file + " not found in ClearCase\n    --> The project database has to be updated\n"
        
        #parse the file content
        __peerFound = 0
        for __index in range(len(__fileContent)):
            
            #look for a GHS deactivation pragma
            __searchedObj = re.search("#pragma\s+ghs\s+nowarning\s+(\d+)(.*)",__fileContent[__index])
            if __searchedObj:
                #if the previous pattern found was a deactivation and we get there without finding an activation: the previous was a file deactivation
                #the previous deactivation has to be reported as file deactivation
                if __peerFound == 1:
                    __previousDeactivationLine = __deactivationLine
                    __previousWarningNumber = __warningNumber
                    __previousComment = __comment
                    __numberFileDeactivation += 1
                    __reportFileDeactivation += "Warning %s, from line %s, file %s\nComment: %s\n\n" % (__previousWarningNumber,__previousDeactivationLine,__file,__previousComment)
                    
                __deactivationLine = __index + 1
                __warningNumber = __searchedObj.group(1)
                #get comment on the current line or if not found on the previous
                __comment = __searchedObj.group(2).lstrip().rstrip()
                if __comment == "":
                    if re.search("\s*(//|/\*).*\w+",__fileContent[__index-1]):
                        __comment = __fileContent[__index-1].lstrip().rstrip()
            
                __peerFound = 1
            
            #look for the activation pragma
            if re.search("#pragma\s+ghs\s+endnowarning",__fileContent[__index]):
                __activationLine = __index + 1
                __peerFound += 1
                if __peerFound == 2:
                    # deactivation + activation has been found
                    __numberLocalDeactivation += 1
                    __reportLocalDeactivation += "Warning %s, lines %s to %s, file %s\nComment: %s\n\n" % (__warningNumber,__deactivationLine,__activationLine,__file,__comment)
                    
                
        #end of file: check the peer state
        #if the last pattern found was a deactivation: it was a file deactivation (without activation)
        #it has to be reported as file deactivation
        if __peerFound == 1:
            __numberFileDeactivation += 1
            __reportFileDeactivation += "Warning %s, from line %s, file %s\nComment: %s\n\n" % (__warningNumber,__deactivationLine,__file,__comment)
    
    
    
    ''' check in the compiler configuration if some warnings are globally disabled '''
    #get the option list with the GHS gbuild tool

    #prepare and call gbuild command
    __ghsOptionsTempFile = __tempOutPath + "\\GHSListOptionsTempFile.txt"
    __GHScommand = __compilerPath + "\gbuild.exe -list_options -verbose -info -top " + __gpjFile + " > " + __ghsOptionsTempFile
    os.system(__GHScommand)
    
    #read the temporary file where the command results is saved
    __GHSListFile = open(__ghsOptionsTempFile)
    __GHSListFileData = __GHSListFile.read()
    __GHSListFile.close()
    
    #look for the global warning deactivation pattern in the whole list
    __matches = re.findall("--diag_suppress\s+((?:\d+,*)+)",__GHSListFileData)
    if __matches:
        for __element in __matches:
            __warningNumbers = __element.split(",")
            for __warningNumber in __warningNumbers:
                #add the warning number in a dictionnary which will contain later the warning comment
                __dictGlobalWarnings[__warningNumber] = ""
                __numberGlobalDeactivation += 1
    
    #look for the warnings comments in the given option file
    #the warnings which are disabled outside the option file get no comment -> they have to be disabled in the opt file
    #read project option file
    try:
        __ghsOptionFileHandler = open(__ghsOptionFile)
        __ghsOptionFileData = __ghsOptionFileHandler.readlines()
        __ghsOptionFileHandler.close()
    except:
        raise Exception ("ERROR: The file " + __ghsOptionFile + " can not be read.\n")
    for __line in __ghsOptionFileData:
        __searchedObj = re.search("\s*--diag_suppress\s+(\d+).*#\s*(.*)",__line)
        if __searchedObj:
            __dictGlobalWarnings[__searchedObj.group(1)] = str(__searchedObj.group(2))
    
    for __warning in __dictGlobalWarnings:
        __reportGlobalDeactivation += "Warning %s\nComment: %s\n\n" % (__warning,__dictGlobalWarnings[__warning])
    
    
    
    ''' generate a report containing the findings '''
    __strReport = __strReportHeader
    __strReport += "Global deactivations: %s\n\n%s\n\n" % (__numberGlobalDeactivation,__reportGlobalDeactivation)
    __strReport += "File deactivations: %s\n\n%s\n\n" % (__numberFileDeactivation,__reportFileDeactivation)
    __strReport += "Local deactivations: %s\n\n%s" % (__numberLocalDeactivation,__reportLocalDeactivation)
    try:
        __tempFileHandler = open(__tempOutPath + "\\WarningsDeactivationReport.txt", 'w')
        __tempFileHandler.write(__strReport)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\WarningsDeactivationReport.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Warnings Deactivation Analysis error log file!!\n")
        
        
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\WarningsDeactivationErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\WarningsDeactivationErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Warnings Deactivation Analysis error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    ''' end of file '''
    