# Rb_WarningsNotifier.py
#
# C. Baudry (AE_BE/ENG3)
# 02.07.2013
#
# Description:
#   This script parses the Jenkins Warnings plugin output to look for the 
#   compiler warnings in the project.
#   It looks for the files responsibles where the warnings are present and
#   creates a warning report for each found user.
#   It creates a result log file and an error log file. The error log file 
#   can be printed out on the console.
#
# Parameters:
# - 1 - XML input file
# - 2 - Project database (xlsx)
# - 3 - Send mail to users:
#           "Yes"
#           "No"
# - 4 - Print error log on console
#           "Yes"
#           "No"
#
# Other inputs which are not parameters
# - Notifier configuration file configNotifications.txt
#
# Outputs:
# - error log
# - results log with all warnings
# - results log per user
#
# Open points:
# - see TODO
#
# Information:
# - If 2 c files have the same name in the project, the first found is taken.
#   This scenario is for the current build environment not possible
#   (unique c file names with gbuild)
#
# Limitations:
#
#---------------------------------------------------------------------------
# Revision history:
#
# Version 001.00 - 02.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 002.00 - 08.07.2013 -  C. Baudry (AE-BE/ENG3)
#   - The file responsible is obtained from a project analysis database
#   - The Bosch LDAP server is used to get the user email
#   - The temp output directory is read from a config file
#---------------------------------------------------------------------------
# Version 002.01 - 10.07.2013 -  C. Baudry (AE-BE/ENG3)
#   - Replace some error messages with warning messages
#   - Use variables for the project analysis database cell indexes
#---------------------------------------------------------------------------
# Version 002.02 - 17.07.2013 -  C. Baudry (AE-BE/ENG3)
#   - Adapt the script to the project database version 2 (headers tab)
#   - Update Jenkins mail address
#---------------------------------------------------------------------------
# Version 002.03 - 19.07.2013 -  C. Baudry (AE-BE/ENG3)
#   - Modify mail text for the integration with the mail sender module
#---------------------------------------------------------------------------
# Version 003.00 - 22.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Send the email with html format 
#---------------------------------------------------------------------------
# Version 003.01 - 29.07.2013 -  C. Baudry (AE-BE/ENG3)
#   Encode the warning strings to utf-8 to deal with special characters
#---------------------------------------------------------------------------
# Version 003.02 - 10.09.2013 -  C. Baudry (AE-BE/ENG3)
#   Comments fixes
#---------------------------------------------------------------------------
# Version 003.03 - 18.12.2013 -  C. Baudry (AE-BE/ENG3)
#   - Add a check for the project analysis database version
#   - Modify the mail general text
#---------------------------------------------------------------------------
# Version 003.04 - 14.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#     No changes required for this new version
#---------------------------------------------------------------------------
# Version 003.05 - 16.01.2014 -  C. Baudry (AE-BE/ENG3)
#   - Update the project analysis database compatible version
#   - Remove database checks: done in the database manager
#---------------------------------------------------------------------------


''' required project analysis database version '''
REQUIRED_DATABASE_VERSION = 5

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' xml parser '''
import xml.etree.ElementTree as ET

''' csv functions '''
import csv
import operator

''' mail functions '''
import smtplib
from email.mime.text import MIMEText

''' Excel 2007 library '''
import openpyxl

''' LDAP library '''
import ldap

import shutil


if __name__ == '__main__':

    ''' inits '''
    __inputXmlFile         = sys.argv[1]
    __inputProjectDatabase = sys.argv[2]
    __sendMail             = sys.argv[3]
    __printErrorLog        = sys.argv[4]
    __strErrorLog = "\n"
    __strResultsLog = ""
    __userList = []
    __tempUserList = []
    __tempOutpath          = os.environ.get("BCMF_TEMP_OUT")
    __sofwarePath          = os.environ.get("BCMF_SOFTWARE_BASE")
    __toolchainConfigPath  = os.environ.get("BCMF_CFG_ROOT")
    __outputFileName       = "WarningsNotifierResults.txt"
    __columnFile           = 0 
    __columnResponsibleID  = 3
        
    
    ''' get environment config '''
    # read the config file to get the current output path
    try:
        __configFileHandler = open(__tempOutpath + "\\configNotifications.txt")
        __tempOutPath = __configFileHandler.read()
        __configFileHandler.close()
    except:
        raise Exception("ERROR: Impossible to read the config file " + __tempOutpath + "\\configNotifications.txt!!\n")
    
        
    ''' parse the XML input file provided by the Jenkins warnings plugin '''
    __tree = ET.parse(__inputXmlFile)
    __root = __tree.getroot()
    
    
    ''' parse the project database '''
    __workbook = openpyxl.reader.excel.load_workbook(__inputProjectDatabase)
    __worksheetDatabaseSources = __workbook.get_sheet_by_name('DatabaseSources')
    __worksheetDatabaseHeaders = __workbook.get_sheet_by_name('DatabaseHeaders')
    __worksheetGeneral  = __workbook.get_sheet_by_name('General')
    
    
    ''' check the project analysis database version '''
    if __worksheetGeneral.cell('B2').value != REQUIRED_DATABASE_VERSION:
        raise Exception("Error with the script Rb_WarningsNotifier.py! Required database version: " + str(REQUIRED_DATABASE_VERSION) + " -- Used version: " + str(__worksheetGeneral.cell('B2').value))
   
    
    ''' Default user is used in case no responsible is defined '''
    __userDefault = __worksheetGeneral.cell('B3').value
    
    
    ''' create a csv file containing all required information '''
    ''' format: file, warning, line number, user '''
    with open(__tempOutPath + '\\WarningsNotifier.csv', 'wb') as csvfile:
        __csvWritter = csv.writer(csvfile, delimiter=';', quotechar='|', quoting=csv.QUOTE_MINIMAL)
        
        for __warning in __root.iter('warning'):
            
            # get the file name and path: from Jenkins Warnings Plugin
            __file = __warning[5].text[1:][:-1]
            
            # get the warning text: from Jenkins Warnings Plugin
            __warningText = __warning[0].text.replace('\t','').replace('\n','').replace(';','')
            # encode the warning text to deal with special characters
            __warningText = __warningText.encode('utf-8')
            
            # get the line number: from Jenkins Warnings Plugin
            __lineNumber = __warning[4].text
            
            # get the file responsible from the project analysis database
            # if no responsible is found the default user is used (has to be configured in the database)
            __found = False
            
            # first check in the sources database
            __rowNumber = 0
            for __row in __worksheetDatabaseSources.rows:
                __rowNumber = __rowNumber + 1
                # database and warnings plugin output comparison
                # -> compare only the file name
                # -> compare without extension to also have a chance to get the header files.
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                    # case the responsible cell is empty
                    if __row[__columnResponsibleID].value == None:
                        __userList.append(__userDefault)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __userDefault])
                        __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: Responsible not given in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    # case the responsible cell contains non-word characters
                    elif re.search("\W",__row[__columnResponsibleID].value):
                        __userList.append(__userDefault)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __userDefault])
                        __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: Responsible synthax not correct in the database, Sources tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    # good case
                    else:
                        __userList.append(__row[__columnResponsibleID].value)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __row[__columnResponsibleID].value])
                    __found = True
            
            # then check in the headers database            
            __rowNumber = 0
            for __row in __worksheetDatabaseHeaders.rows:
                __rowNumber = __rowNumber + 1
                # database and warnings plugin output comparison
                # -> compare only the file name
                # -> compare without extension to also have a chance to get the header files.
                if os.path.basename(__file).lower() == os.path.basename(__row[__columnFile].value).lower():
                    # case the responsible cell is empty
                    if __row[__columnResponsibleID].value == None:
                        __userList.append(__userDefault)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __userDefault])
                        __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: Responsible not given in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    # case the responsible cell contains non-word characters
                    elif re.search("\W",__row[__columnResponsibleID].value):
                        __userList.append(__userDefault)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __userDefault])
                        __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: Responsible synthax not correct in the database, Headers tab, row number " + str(__rowNumber) + "\n    --> Default user used instead\n"
                    # good case
                    else:
                        __userList.append(__row[__columnResponsibleID].value)
                        __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __row[__columnResponsibleID].value])
                    __found = True
                    
            if __found == False:
                # if the file containing a warning has not been found, the warning is communicated to the default user
                __userList.append(__userDefault)
                __csvWritter.writerow([__warning[5].text[1:][:-1], __warningText, __lineNumber, __userDefault])
                __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: File " + __file + " not found in the database\n    --> Default user used for notification\n"
                
        
    
    # sort the user list alphabetically and remove the doubles
    for __user in __userList:
        try:
            ind = __tempUserList.index(__user)
        except:
            __tempUserList.append(__user)
    __userList = __tempUserList
    __userList.sort()
    
    # sort the csv content per user (not used, just in case...)
    # with open('C:\\temp\\tempWarningsNotifier.csv', 'rb') as csvfile:
    #     __csvReader = csv.reader(csvfile,delimiter=';')
    #     sortedlist = sorted(__csvReader, key=operator.itemgetter(3), reverse=True)
    
    ''' create a warning report per user '''
    for __user in __userList:
        
        __warningNumber = 0
        __strResultsUser = ""
        __userMail = ""
        __found = False
        
        # if not already done: create a folder especially for the user with as name the user id
        __tempUserFolder = __tempOutPath + "\\" + __user
        if not os.path.exists(__tempUserFolder):
            os.makedirs(__tempUserFolder)
        
        # group warnings per user and prepare the mail text in the variable __strResultsUser
        with open(__tempOutPath + '\\WarningsNotifier.csv', 'rb') as csvfile:
            __csvReader = csv.reader(csvfile, delimiter=';', quotechar='|')
            for __currentFile, __currentWarning, __currentLine, __currentUser in __csvReader:
                if __user == __currentUser:
                    __warningNumber = __warningNumber + 1
                    __strResultsUser = __strResultsUser + " -- " + __currentFile + ", line " + __currentLine + ":<br>" + "    " + __currentWarning + "<br><br>"
        __strResultsUser = __strResultsUser + "<br><br>"
        __strResultsLog = __strResultsLog + __strResultsUser
        
        # create a txt file containing the mail text in a separate folder for each user
        __strResultsUser = "<hr><B><U>Compiler warnings notifications</U></B><br><br><a href=\"http://lr-x7350.lr.de.bosch.com:8080/job/AUDI_BCM1_MLBevo_Lr-Nightly/warnings17\">Jenkins</a> has found the compiler warnings listed below (" + str(__warningNumber) + ").<br><br>" + __strResultsUser
        try:
            __tempFileHandler = open(__tempUserFolder + "\\" + __outputFileName, 'w')
            __tempFileHandler.write(__strResultsUser)
            __tempFileHandler.close()
            print "-- Warnings Notifier: create a warning list for user " + __user + " (" + str(__warningNumber) + ")"
        except:
            raise Exception("ERROR: Impossible to create the Warnings Notifier results user file!!\n")
        
        if __sendMail == "Yes":
            # get the email address from the user id using the BOSCH LDAP server
            try:
                con = ldap.initialize ('ldap://fe-bcd50.de.bosch.com:3268')
                dn = "ad08fe@de.bosch.com"
                pw = "ad08fead08fe"
                con.simple_bind_s( dn, pw ) 
                baseDN = "DC=bosch,DC=com"
                searchScope = ldap.SCOPE_SUBTREE
                searchFilter = "cn=" + __user
                result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                blub,myDict = result[0]  # works because ther's only one result
                __userMail = str(myDict["mail"])[2:][:-2]
                __found = True
            except:
                __strErrorLog = __strErrorLog + "-- Warnings Notifier warning: No mail address has been found for the following user: " + __user + "\n   The mail is sent to the default configured user: " + __userDefault + "\n"
                try:
                    searchFilter = "cn=" + __userDefault
                    result = con.search_ext_s(baseDN, ldap.SCOPE_SUBTREE,searchFilter)
                    blub,myDict = result[0]  # works because ther's only one result
                    __userMail = str(myDict["mail"])[2:][:-2]
                    __found = True
                except:
                    __strErrorLog = __strErrorLog + "-- Warnings Notifier error: No mail address has been found for the following user: " + __userDefault + ". The mail won't be sent\n"
                    __found = False
                
            if __found == True:
                # send the mail to the user and print on the console some information
                __tempFileHandler = open(__tempUserFolder + "\\" + __outputFileName, 'rb')
                msg = MIMEText(__tempFileHandler.read())
                #TODO add project name in the mail subject
                msg['Subject']  = "Jenkins warnings notifier"
                msg['From']     = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
                msg['To']       = __userMail
                __mailSender    = "Tool BCM Gruppenuser (AE-BE/ENG3) <Gruppenuser.ToolBCM@bcn.bosch.com>"
                __mailReceivers = __userMail
                s = smtplib.SMTP('rb-smtp-int.bosch.com')
                s.sendmail(__mailSender, __mailReceivers, msg.as_string())
                s.quit()
                print "-- Warnings Notifier: send a notification mail to the user " + __user + " " + __userMail
    
    
    ''' results log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\WarningsNotifierResultsLog.html", 'w')
        __tempFileHandler.write(__strResultsLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\WarningsNotifierResultsLog.html", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Warnings Notifier results log file!!\n")
        
        
    ''' error log file '''
    try:
        __tempFileHandler = open(__tempOutPath + "\\WarningsNotifierErrorLog.txt", 'w')
        __tempFileHandler.write(__strErrorLog)
        __tempFileHandler.close()
        ''' if Jenkins is used and if the file exists: copy it into the Jenkins workspace '''
        try:
            if os.environ.get("WORKSPACE") != "":
                shutil.copy(__tempOutPath + "\\WarningsNotifierErrorLog.txt", os.environ.get("WORKSPACE"))
        except:
            pass
    except:
        raise Exception("ERROR: Impossible to create the Warnings Notifier error log file!!\n")
    
    # print the error logs on the console
    if __printErrorLog == "Yes":
        print __strErrorLog
    
    ''' end of file '''
