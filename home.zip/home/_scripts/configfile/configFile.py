# configFile.py - Class for reading and accessing configuration files.
#
# G. Robinson (AE-BE/ENG5)
# 20-02-2008
#
# Revision history:
#
# Version 001.00 - 20.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision. Includes config and segment reading aswell as exception
#   handling.
# Version 002.00 - 21.02.2008 - G. Robinson (AE-BE/ENG5)
#   Added functions for storing the filename with the object so it can later
#   be reported.
# Version 003.00 - 29.05.2008 - S. Webber (AE-BE/EBS4-AU)
#   Added make / directory dictionaries.
# Version 004.00 - 30.09.2008 - G. Robinson (AE-BE/ENG3)
#   Added support for pre-processing of environment variables.
# Version 005.00 - 19.01.2009 - S. Weber (AE-BE/ENG3)
#   Generally write all data into the make file not just exes and paths
# Version 005.01 - 22.01.2009 - S. Weber (AE-BE/EBS4-AU)
#   moved generation of mak files into new class CreateMakFile
# Version 005.02 - 06.02.2009 - S. Weber (AE-BE/EBS4-AU)
#   added stuff for data that's to go into the mak-file
#   moved replacing of environment variables to the top
# Version 006.00 - 01.04.2011 - C. Baudry (AE-BE/ENG3)
#   add functions dictionary for stack checker support
# Version 007.00 - 20.04.2011 - C. Baudry (AE-BE/ENG3)
#   add parser exclude directory list support
# Version 008.00 - 28.02.2013 - C. Baudry (AE-BE/ENG3)
#   add configuration possibilities for the QAC analysis
#

''' required for system arguments '''
import sys
import re
import os

''' definition for configuration option '''
CONFIG_OPTION   = "CONFIG"

''' definition for segment details '''
CONFIG_SEGMENTS = "SEGMENT"

''' definition for function stack details '''
CONFIG_FUNCTIONS = "FUNCTION"

''' definition for parser exclude list details '''
CONFIG_EXCLUDE = "EXCLUDE"

''' definition for QAC add include directory '''
CONFIG_QAC_ADD_INCLUDE = "QAC_ADD_INCLUDE"

''' definition for QAC ignore directory '''
CONFIG_QAC_IGNORE = "QAC_IGNORE"

''' definition for QAC third party directory '''
CONFIG_QAC_THIRD = "QAC_THIRD"


# Class for configuration file
class ConfigFile:

    # Initialise a configuration dictionary
    def __init__(self, configuration_file):

        ''' prepare dictionaries '''
        self.configuration = {}
        self.segments      = {}
        self.functions     = {}
        
        self.parserExclude = []
        
        self.qacAddInclude = []
        self.qacIgnore     = []
        self.qacThird      = []
        
        self.file_name     = ""
        self.mak_name      = ""
        self.directories   = ""

        ''' try and work with data file '''
        try:
            ''' open the config file '''
            config_file = open(configuration_file)
            self.file_name = configuration_file

            try:

                ''' read all the config options '''
                line = config_file.readline()

                while line:

                    ''' first replace environment variables '''
                    line_out = ""
                    environmentVariable = ""
                    for character in line:
                        if(character == '%') and (len(environmentVariable) == 0):
                            environmentVariable = environmentVariable + character

                        elif(len(environmentVariable) > 0):
                            environmentVariable = environmentVariable + character

                            if(character == '%'):
                                try:
                                    line_out = line_out + os.environ.get(environmentVariable[1:-1])

                                except:
                                    line_out = line_out + environmentVariable
                                    ''' print "Problem with environment variable..." '''

                                environmentVariable = ""

                        else:
                            line_out = line_out + character

                    '''now evaluate the contents of the line'''
                    words = line_out.split()

                    ''' first make sure that these is data on this line '''
                    if(words):

                        try:

                            ''' check and process the applicable segment '''
                            if(words[0] == CONFIG_OPTION):
                                ''' configuration option '''

                                ''' now set the dictionary element '''
                                configuration = words[1]

                                '''this is for writing the directories for the later writing into a mak-file'''
                                ''' try and get the first option data just to ensure its there '''
                                '''get the number of options behind (may be more than one!)'''
                                option_no = len(words)
                                first_option = ""
                                for i in range(2,option_no):
                                    first_option = first_option + words[i] + " "

                                ''' write the make file with all path and EXE options '''
                                cmd_string = ""
                                if first_option[-2:] == '\\ ':
                                    cmd_string = configuration + ' = ' + first_option[:-2] + '\n'
                                else:
                                    cmd_string = configuration + ' = ' + first_option + '\n'
                                self.directories += cmd_string

                                '''write the dictionary for the python scripts'''
                                ''' remove the rubbish from the line that is no longer needed '''
                                words.remove(CONFIG_OPTION)
                                words.remove(configuration)


                                ''' join the rest of the line together as the actual configuration '''
                                option_string = ""

                                for word in words:
                                    option_string += word + " "

                                ''' strip the last space and store the configuration in the dictionary '''
                                self.configuration[configuration] = option_string[:-1]

                            elif(words[0] == CONFIG_SEGMENTS):
                                ''' segment information '''
                                self.segments[words[1]] = words[2]
                                
                            elif(words[0] == CONFIG_FUNCTIONS):
                                ''' function stack information '''
                                self.functions[words[1]] = words[2]
                                
                            elif(words[0] == CONFIG_EXCLUDE):
                                ''' parser exclude directory list '''
                                self.parserExclude.append(words[1])
                                
                            elif(words[0] == CONFIG_QAC_ADD_INCLUDE):
                                if words[1][-1:] == "\\":
                                    words[1] = words[1][:-1]
                                ''' QAC add include directory '''
                                self.qacAddInclude.append(words[1])
                                
                            elif(words[0] == CONFIG_QAC_IGNORE):
                                if words[1][-1:] == "\\":
                                    words[1] = words[1][:-1]
                                ''' QAC ignore directory '''
                                self.qacIgnore.append(words[1])

                            elif(words[0] == CONFIG_QAC_THIRD):
                                if words[1][-1:] == "\\":
                                    words[1] = words[1][:-1]
                                ''' QAC third party directory '''
                                self.qacThird.append(words[1])
                                
                        except IndexError:

                            error_message = "Problem detected with option or segment in " + configuration_file

                            print "\n" + "-" * len(error_message)
                            print "Warning:"
                            print error_message
                            print "-" * len(error_message) + "\n"

                    '''read the next line'''
                    line = config_file.readline()


            finally:
                config_file.close()

        except IOError:
            error_message = "Problem processing the configuration file " + configuration_file

            print "\n" + "-" * len(error_message)
            print "Error:"
            print error_message
            print "-" * len(error_message) + "\n"

            ''' stop the program as this error is fatal '''
            raise


    # Return the directories
    def ConfigDirectories(self):
        return self.directories

    # Return the configuration dictionary
    def ConfigDictionary(self):
        return self.configuration

    # Return the segment dictionary
    def SegmentDictionary(self):
        return self.segments
        
    # Return the function dictionary
    def StackFunctionDictionary(self):
        return self.functions
        
    # Return the parser exclude list
    def ParserExcludeList(self):
        return self.parserExclude
        
    # Return the QAC add include directory list
    def QacAddIncludeList(self):
        return self.qacAddInclude
        
    # Return the QAC ignore directory list
    def QacIgnoreList(self):
        return self.qacIgnore
            
    # Return the QAC third party directory list
    def QacThirdList(self):
        return self.qacThird

    # Return the name of the configuration file used to generate this object
    def ConfigurationFileName(self):
        return self.file_name


if __name__ == '__main__':

    ''' set up a command line instance of the class for test pruposes
        and print out its dictionaries. '''
    try:
        test_configuration = ConfigFile(sys.argv[1])

        print "\nConfiguration File Name: " + test_configuration.ConfigurationFileName() + "\n"
        print "\nConfiguration Dictionary:"
        print test_configuration.ConfigDictionary()
        print "\nSegment Dictionary:"
        print test_configuration.SegmentDictionary()
        print "\nFunction Dictionary:"
        print test_configuration.StackFunctionDictionary()
        print "\nParser exclude list:"
        print test_configuration.ParserExcludeList()
        print "\nQAC add include directory list:"
        print test_configuration.QacAddIncludeList()
        print "\nQAC ignore directory list:"
        print test_configuration.QacIgnoreList()
        print "\nQAC third party directory list:"
        print test_configuration.QacThirdList()

    except IndexError:

        error_message = "Usage: python configFile.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
