# makConfigFile.py - Class for creating mak files out of the configuration dictionaries.
#                    and saving it in the temp output path
#
# S. Weber (AE-BE/ENG3)
# 20-02-2008
#
# Revision history:
#
# Version 001.00 - 22.01.2009 - S. Weber (AE-BE/ENG3)
#   Initial revision.
# Version 001.01 - 22.01.2009 - S. Weber (AE-BE/ENG3)
#   Fixed main
# Version 001.02 - 27.01.2010 - S. Weber (AE-BE/ENG31-AU)
#   added configuration file as a parameter for extracting
#   the temporary output path. That way it can be called with
#   different filenames etc.

''' required for system arguments '''
import os
import sys
from configFile import ConfigFile

CFG_TEMP_OUT                = "TEMP_OUT"


# Class for configuration file
class CreateMakFile:

    # Initialise a configuration dictionary
    def __init__(self, main_configuration, gen_configuration):

        '''This configuration is needed to determine the temporay output path'''
        configuration = ConfigFile(main_configuration).ConfigDictionary()
        '''The handling of the actual configuration file to be converted'''
        self.file_name = gen_configuration
        self.directories = ConfigFile(gen_configuration).ConfigDirectories()

        '''set up the makefile from the configuration file'''
        '''first split the filename from the pathname'''
        self.file_name = os.path.split(self.file_name)[1]
        namestring = self.file_name.replace('.cfg', '.mak')
        newpathForMakFile = configuration[CFG_TEMP_OUT]
        makefile = open(newpathForMakFile + "\\" + namestring, 'w')
        '''write the directories form the configuration file into the mak file'''
        makefile.write(self.directories)
        makefile.close()


if __name__ == '__main__':

    ''' set up a command line instance of the class for test purposes
        and print out its dictionaries. '''
    try:
        CreateMakFile(sys.argv[1], sys.argv[2])

    except IndexError:

        error_message = "Usage: python makConfigFile.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
