# stackchecker.py - Class for statically analysing the stack usage
#
# This tool is called from the BCMF GUI.
# It is also possible to use it standalone.
#
# C. Baudry AE-BE/ENG3
# 29.03.2011
#
# Revision history:
#
# Version 001.00 - 29.03.2011 - C. Baudry AE-BE/ENG3
#   Initial revision.
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 001.01 - 11.07.2012 - C. Baudry AE-BE/ENG3
#   EBRCM00148119: The stack section name can be configured
#   Correct error management
#--------------------------------------------------------------------------------------------------------------------------------------

''' required for directory listings and executing etc '''
import os

''' required for system arguments '''
import sys

''' import the configuration file handler '''
from configFile import ConfigFile

''' import re for regular expressions '''
import re

''' config file definitions '''
CFG_USED_COMPILER            = "USED_COMPILER"
CFG_STACK_SECTION            = "STACK_SECTION"



class GHSStackChecker:

    def __init__(self, ldFileContent, stackSectionName, elfFile, configurationAddedFunctions, bcmfTmpOutPath):
        
        self.ldFileContent = ldFileContent
        self.stackSectionName = stackSectionName
        self.elfFile = elfFile
        self.configurationAddedFunctions = {}
        self.configurationAddedFunctions = configurationAddedFunctions
        self.bcmfTmpOutPath = bcmfTmpOutPath
        
        
    
    # -------------------------------------------------------------------------
    # This function is used to get the project reserved stack
    # It returns:
    # - the reserved stack in decimal
    # OR
    # - 0 if the reserved stack could not be read
    # -------------------------------------------------------------------------
    def GetReservedStack(self):
        ''' the reserved stack information is contained in the linker file '''
        
        __reservedStackFound = False
        __reString = "\s*" + self.stackSectionName + "\s*=\s*\d*.*"
        __reStringObj = "\s*" + self.stackSectionName + "\s*=\s*(\d*).*"
        
        for line in self.ldFileContent:
            if re.search(__reString, line):
                __matchObj = re.search(__reStringObj, line)
                if __matchObj:
                    __reservedStackFound = True
                    return __matchObj.group(1)
        
        if __reservedStackFound == False:
            return 0
            
            
            
    # -------------------------------------------------------------------------
    # This function is used to calculate the project required stack
    # It uses the GHS tool gstack
    # It returns:
    # - the calculated stack in decimal
    # OR
    # - 0 if the calculted stack function failed
    # -------------------------------------------------------------------------
    def CalculateStack(self):
        
        __maxFoundStack = 0
        __tmpFileGstack = self.bcmfTmpOutPath + "\\tmpGstackResults.txt"
        
        ''' for some functions, gstack can't find the required stack '''
        ''' these functions are listed in the config file '''
        __stringAddedFunctions = ""
        for function in self.configurationAddedFunctions:
            __stringAddedFunctions = __stringAddedFunctions + " -f " + function + "=" + self.configurationAddedFunctions[function]
        
        __GHScommand = "%BCMF_COMPILER_ROOT%\gstack.exe -j " + __stringAddedFunctions + " " + self.elfFile + " > " + __tmpFileGstack
        os.system(__GHScommand)
        
        ''' the file __tmpFileGstack contains the gstack results: it has to be analysed '''
        try:
            __tmpFile = open(__tmpFileGstack)
            __tmpFileGstackContent = __tmpFile.readlines()
            __tmpFile.close()
            
            for line in __tmpFileGstackContent:
                if re.search("\s*\d*\t\s*\d*\t.*", line):
                    __matchObj = re.search("\s*\d*\t\s*(\d*)\t.*", line)
                    if __matchObj:
                        if int(__matchObj.group(1)) > __maxFoundStack:
                            __maxFoundStack = int(__matchObj.group(1))
            
            return __maxFoundStack
            
        except:
            return 0
        
        
    
    def GetWarning(self):
        return "!! This result does not contain the required stack for OS context switches !!\n"\
        "Please contact the OS responsible if you need more accurate stack information\n"
    
    
    
class StackChecker:

    def __init__(self, selectedVariant, elfFile, ldFile, configurationFile, bcmfTmpOutPath, StackCheckerOutPath):
        
        ''' creating a StackChecker object analyses the stack and creates a log file '''
        
        ''' load the configuration and stack function dictionaries '''
        __configurationObject = ConfigFile(configurationFile)
        self.configurationStackChecker = __configurationObject.ConfigDictionary()
        self.configurationAddedFunctions = __configurationObject.StackFunctionDictionary()
        
        ''' class init parameters '''
        self.selectedVariant = selectedVariant
        self.elfFile = elfFile
        self.ldFile = ldFile
        self.bcmfTmpOutPath = bcmfTmpOutPath
        self.StackCheckerOutPath = StackCheckerOutPath
        
        ''' class global variables '''
        self.calculatedStack = 0
        self.reservedStack = 0
        self.stackCheckSucceeded = False
        
        self.logFileResults = self.StackCheckerOutPath + "\\StackCheckerResults.txt"
        
        ''' used compiler '''
        if CFG_USED_COMPILER in self.configurationStackChecker:
            self.usedCompiler = self.configurationStackChecker[CFG_USED_COMPILER]
        else:
            self.ManageStackCheckerError("Used compiler is not configured!")
            return
        
        ''' read file containing reserved stack information, common for all compilers '''
        try:
            __ldFile = open(self.ldFile)
            self.ldFileContent = __ldFile.readlines()
            __ldFile.close()
        except:
            self.ManageStackCheckerError("Unable to open the file " + self.ldFile)
            return
            
        ''' stack section name in linker file '''
        if CFG_STACK_SECTION in self.configurationStackChecker:
            self.stackSectionName = self.configurationStackChecker[CFG_STACK_SECTION]
        else:
            self.ManageStackCheckerError("Linker file stack section name is not configured!")
            return
                
        ''' create object according to the used compiler '''
        if self.usedCompiler == "GHS":
            self.ghsStackChecker = GHSStackChecker(self.ldFileContent, self.stackSectionName, self.elfFile, self.configurationAddedFunctions, self.bcmfTmpOutPath)
        else:
            ''' for the moment no other compiler are supported '''
            self.ManageStackCheckerError("Used compiler is wrong configured!")
            return
            
        ''' --------------------------------------------------------------------------- '''
        ''' get the reserved stack size using the linker file '''            
        if self.usedCompiler == "GHS":
            self.reservedStack = self.ghsStackChecker.GetReservedStack()
            if self.reservedStack == 0:
                self.ManageStackCheckerError("Reserved stack can not be read in the linker file!")
                return
        else:
            ''' for the moment no other compiler are supported '''
        
        ''' --------------------------------------------------------------------------- '''
        ''' check the stack '''
        if self.usedCompiler == "GHS":
            self.calculatedStack = self.ghsStackChecker.CalculateStack()
            self.compilerSpecificWarning = self.ghsStackChecker.GetWarning()
            if self.calculatedStack == 0:
                self.ManageStackCheckerError("The gstack temporary file could not be found or opened!")
                return
        else:
            ''' for the moment no other compiler are supported '''
        
        ''' --------------------------------------------------------------------------- '''
        ''' create and edit the log file '''

        ''' get the remaining stack '''
        __remainingStack  = int(self.reservedStack) - int(self.calculatedStack)
        
        if self.reservedStack <= self.calculatedStack:
            __warning = "\n!!! The reserved stack is not sufficient !!!\n"
        else:
            __warning = ""
    
        __stackCheckerResults = \
        "-----------------------------------------------------------------------------"                       +\
        "\nStack checker results for variant " + self.selectedVariant + ":"                                   +\
        "\n    Reserved stack     " + str(self.reservedStack)                                                 +\
        "\n    Calculated stack   " + str(self.calculatedStack)                                               +\
        "\n    ----------------   "                                                                           +\
        "\n    Remaining stack    " + str(__remainingStack) + "\n"                                            +\
        __warning + "\n"                                                                                      +\
        self.compilerSpecificWarning                                                                          +\
        "-----------------------------------------------------------------------------\n"
        
        try:
            __logFile = open(self.logFileResults,"w")
            __logFile.write(__stackCheckerResults)
            __logFile.close()
        except:
            self.ManageStackCheckerError("Unable to open or edit the file " + self.logFileResults)
            return
        
        
        ''' end of check '''
        self.stackCheckSucceeded = True
        

    
    def GetCalculatedStack(self):
        return int(self.calculatedStack)
    
    
    
    def GetReservedStack(self):
        return int(self.reservedStack)

        
        
    def GetCompilerSpecificWarning(self):
        return self.compilerSpecificWarning
    
    
    
    def GetResult(self):
        return self.stackCheckSucceeded
    
    
    
    def ManageStackCheckerError(self, errorString):
        print "\nStack Checker Error: " + errorString
        print "Stack Checker Error: can not continue!\n"
        self.stackCheckSucceeded = False
        
        
    
if __name__ == '__main__':

    print "\nCheck stack..."
    ''' this call checks the stack and creates a log file '''
    __stackChecker = StackChecker(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
    print "End check stack. Please check results in file " + __stackChecker.logFileResults
    os.system("PAUSE")
    