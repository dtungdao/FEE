# ecuversion.py - Class for updating embedded ecu version
#
# G. Robinson (AE-BE/ENG5)
# 01-03-2008
#
# Revision history:
#
# Version 001.00 - 01.03.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
# Version 002.00 - 11.03.2008 - G. Robinson (AE-BE/ENG5)
#   Fixed problems with reading of environment variables for
#   appending user details to comments. First tries O2K3_MBXNAME
#   then USERNAME then reverts to anonymous.
# Version 003.00 - 18.11.2008 - G. Robinson (AE-BE/ENG3)
#   Added support for major, minor, and revision versions.
# Version 003.10 - 19.01.2009 - S. Weber (AE-BE/ENG3)
#   Added bugfix for cases in which the ecuversion cannot
#   be changed (no checkout permission).
# Version 003.00 - 21.01.2009 - Silke Weber (AE-BE/EBS4-AU)
#   removed call of update funtion from init, has to be called explicitly
#   instead added reading of ecu version file to return the current
#   versions for use in the GUI
# Version 003.01 - 25.02.2009 - Silke Weber (AE-BE/EBS4-AU)
#   moved reading of ecu file in a seperate function so that
#   it can be called on variant update
# Version 003.02 - 19.11.2009 - Silke Weber (AE-BE/ENG31-AU)
#   Added handling of project specific version numbers
# Version 003.03 - 08.04.2010 - Silke Weber (AE-BE/ENG31-AU)
#   Padd out the customer version and the CAN version with
#   spaces to make up 32 bytes
#

''' required for system arguments '''
import sys

''' import subprocess for executing commands '''
import subprocess

''' import re for regular expressions '''
import re

''' import time for time features '''
import time

''' import os for reading user details '''
import os

''' import os for reading user details '''
import string

''' import the configuration file handler '''
from configFile import ConfigFile

''' config file definitions '''
CFG_ECU_VERSION_PATH     = "ECU_VERSION_PATH"
CFG_ECU_VERSION_FILE     = "ECU_VERSION_FILE"

CFG_VERSION_ROM_GENTIME  = "VERSION_ROM_GENTIME"
CFG_VERSION_ROM_MAJOR    = "VERSION_ROM_MAJOR"
CFG_VERSION_ROM_MINOR    = "VERSION_ROM_MINOR"
CFG_VERSION_ROM_REVISION = "VERSION_ROM_REVISION"
CFG_VERSION_ROM_HW       = "VERSION_ROM_HW"
CFG_VERSION_ROM_CUSTOMER = "VERSION_ROM_CUSTOMER"
CFG_VERSION_ROM_CAN      = "VERSION_ROM_CAN"


''' class for the tools versions '''
class EcuVersions:

    def __init__(self):
        pass

    def UpdateVersion(self, configuration_file, version_string_major, version_string_minor, version_string_revision, hardware_version_entry, version_string_customer, version_string_can):

        '''check if customer and CAN version are less than 32 letters and fill up with nulls'''
        version_string_customer_len = len(version_string_customer)
        if (version_string_customer_len > 32):
            version_string_customer_pad = string.ljust(version_string_customer, 32)
        else:
            version_string_customer_pad = version_string_customer
        
        print "SW String Length: %d, Content: %s" %(version_string_customer_len, version_string_customer_pad)

        version_string_can_len = len(version_string_can)
        if (version_string_can_len > 32):
            version_string_can_pad = string.ljust(version_string_can, 32)
        else:
            version_string_can_pad = version_string_can

        print "CAN String Length: %d, Content: %s" %(version_string_can_len, version_string_can_pad)

        try:
            version_file = self.configuration[CFG_ECU_VERSION_PATH] + "\\" + self.configuration[CFG_ECU_VERSION_FILE]

            ''' check out the version file '''
            command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + version_file

            subprocess.call(command_string)

            ''' open the version file for reading '''
            try:
                version_file_handle = open(version_file)

                version_file_data = version_file_handle.read()

                ''' get the environment variables if possible'''
                if ("O2K3_MBXNAME" in os.environ) and ("COMPUTERNAME" in os.environ):
                    version_string_comment = "/* Created by " + os.environ["O2K3_MBXNAME"] + " on " + os.environ["COMPUTERNAME"] + " */"

                elif ("USERNAME" in os.environ) and ("COMPUTERNAME" in os.environ):
                    version_string_comment = "/* Created by " + os.environ["USERNAME"] + " on " + os.environ["COMPUTERNAME"] + " */"

                else:
                    version_string_comment = "/* Created by anonymous user (no environment variable data) */"

                ''' create new version strings '''
                version_in_rom_write_major    = "#define RB_ECU_SW_VERSION_MAJOR         \"" + version_string_major + "\" " + version_string_comment
                version_in_rom_write_minor    = "#define RB_ECU_SW_VERSION_MINOR         \"" + version_string_minor + "\""
                version_in_rom_write_revision = "#define RB_ECU_SW_VERSION_REVISION      \"" + version_string_revision + "\""
                version_in_rom_write_hw       = "#define RB_ECU_HW_VERSION_MAJOR         \"" + version_string_major + "\" "
                version_in_rom_write_customer = "#define RB_ECU_SW_CUSTOMER_VERSION      \"" + version_string_customer_pad + "\""
                version_in_rom_write_can      = "#define RB_ECU_SW_CAN_VERSION           \"" + version_string_can_pad + "\""
                version_in_rom_gentime_write  = "#define RB_ECU_SW_VERSION_GENTIME       \"" + time.strftime("%d_%m_%Y__%H_%M_%S", time.localtime()) + "\""

                ''' find the version strings and replace with new version'''
                version_in_rom_major_re    = re.compile(".*" + self.configuration[CFG_VERSION_ROM_MAJOR] + ".*")
                version_in_rom_minor_re    = re.compile(".*" + self.configuration[CFG_VERSION_ROM_MINOR] + ".*")
                version_in_rom_revision_re = re.compile(".*" + self.configuration[CFG_VERSION_ROM_REVISION] + ".*")
                version_in_rom_hw_re       = re.compile(".*" + self.configuration[CFG_VERSION_ROM_HW] + ".*")
                version_in_rom_customer_re = re.compile(".*" + self.configuration[CFG_VERSION_ROM_CUSTOMER] + ".*")
                version_in_rom_can_re      = re.compile(".*" + self.configuration[CFG_VERSION_ROM_CAN] + ".*")
                version_in_rom_gentime_re  = re.compile(".*" + self.configuration[CFG_VERSION_ROM_GENTIME] + ".*")

                version_file_data = version_in_rom_major_re.sub(version_in_rom_write_major, version_file_data)
                version_file_data = version_in_rom_minor_re.sub(version_in_rom_write_minor, version_file_data)
                version_file_data = version_in_rom_revision_re.sub(version_in_rom_write_revision, version_file_data)
                version_file_data = version_in_rom_hw_re.sub(version_in_rom_write_hw, version_file_data)
                version_file_data = version_in_rom_customer_re.sub(version_in_rom_write_customer, version_file_data)
                version_file_data = version_in_rom_can_re.sub(version_in_rom_write_can, version_file_data)
                version_file_data = version_in_rom_gentime_re.sub(version_in_rom_gentime_write, version_file_data)

                version_file_handle.close()

                ''' open the version file for writing '''
                version_file_handle = open(version_file, 'w')

                version_file_handle.write(version_file_data)

                version_file_handle.close()
            except:
                print "Version File could not be changed"

        except IOError:
            error_message = "Problem processing the version source files"

            print "\n" + "-" * len(error_message)
            print "Error:"
            print error_message
            print "-" * len(error_message) + "\n"

            ''' stop the program as this error is fatal '''
            raise

        except KeyError, detail:
            ''' catch the errors when a configuration option is missing form the file '''

            error_message = "Following configuration needs to be added: " + str(detail)

            print "\n" + "-" * len(error_message)
            print "Error:"
            print error_message
            print "-" * len(error_message) + "\n"

            ''' stop the program as this error is fatal '''
            raise

    def UpdateVersionFromFile(self, configuration_file):
        ''' read the configurations from the configuration file '''
        self.configuration = ConfigFile(configuration_file).ConfigDictionary()

        ''' read the version file to find out what the version number currently is.'''
        version_file = self.configuration[CFG_ECU_VERSION_PATH] + "\\" + self.configuration[CFG_ECU_VERSION_FILE]

        version_file_handle = open(version_file)

        version_file_data = version_file_handle.readlines()

        for line in version_file_data:
            words = line.split()

            ''' everything with less than One words is not the sw version '''
            if (len(words)>1):
                ''' search for the defines '''
                if (words[1] == self.configuration[CFG_VERSION_ROM_MAJOR]):
                    ''' strip the the "" '''
                    self.swVersionMajor = words[2][1:3]
                if (words[1] == self.configuration[CFG_VERSION_ROM_MINOR]):
                    self.swVersionMinor = words[2][1:3]
                if (words[1] == self.configuration[CFG_VERSION_ROM_REVISION]):
                    self.swVersionRev = words[2][1:3]
                if (words[1] == self.configuration[CFG_VERSION_ROM_HW]):
                    self.hwVersion = words[2][1:3]
					


    def GetSwVersionMajor(self):
        return self.swVersionMajor

    def GetSwVersionMinor(self):
        return self.swVersionMinor

    def GetSwVersionRev(self):
        return self.swVersionRev
		
    def GetHwVersion(self):
        return self.hwVersion

if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        test_class = EcuVersions(sys.argv[1], "1234", "1234", "1234")

    except IndexError:

        error_message = "Usage: python ecuversion.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
