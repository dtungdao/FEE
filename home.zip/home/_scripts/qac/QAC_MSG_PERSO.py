# Simple script to replace a line in a given files
#
#  python QAC_MSG_PERSO.py  -f file to be changed -h path of the help files to be used
#
#  Will search the given personality file for the option -up ad replace it with the own path to the message helpfiles
#  This is so we can use the template from the tools group#

# S. Weber (AE-BE/ENG3)
# 15-07-2008
#
# Revision history:
#
# Version 001.00 - Silke Weber (AE-BE/ENG3)
#   Initial revision.
# Version 002.00 - Silke Weber (AE-BE/ENG3)
#   added changing of userfile as well
# Version 003.00 - Silke Weber (AE-BE/ENG3)
#   added bugfix in case no warnings in list
#

import os
import sys
import getopt


def main():

    file_name = ''
    help_path = ''
    ext_name = ''

    try:
        opts, args = getopt.getopt(sys.argv[1:], 'h:f:e:w:')

    except getopt.error:
        sys.exit(2)

    # process options
    for o, a in opts:

        if o in '-f':
            file_name = a

        if o in '-h':
            help_path = a

        if o in '-e':
            ext_name = a

        if o in '-w':
            deact_msg = a

    try:
        perso_file = open(file_name)
        line_list = perso_file.readlines()
        perso_file.close()

        ''' search for -up option '''
        boese_zeile = ''
        for line in line_list:
            if '-up' in line:
                boese_zeile = line

        index = line_list.index(boese_zeile)
        line_list.remove(boese_zeile)
        line_list.insert(index, '\n -up ' + help_path + '\n')

        ''' search for -usr option '''
        for line in line_list:
            if '-usr' in line:
                boese_zeile = line

        index = line_list.index(boese_zeile)
        line_list.remove(boese_zeile)
        line_list.insert(index, '\n -usr ' + ext_name + '\n')
        if deact_msg != "[]":
            for msg in deact_msg:
                if msg == "[":
                    deactivate = '-n '
                else:
                    if msg == ",":
                        deactivate = '\n-n '
                    else:
                        if msg == "]":
                            break
                        else:
                            deactivate = msg
                line_list.append(deactivate)
        else:
            pass

        perso_file = open(file_name, 'w')
        perso_file.writelines(line_list)
        perso_file.close()
    except:
        print "No valid personality template!"    


if __name__ == "__main__":

    main()





