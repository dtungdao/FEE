'''
Append a list of files to the analyser personality:
if the option is -x, the the list has to be excluded from the analysis
'''
import os
import sys
import getopt

def main():

    include = True
    try:
        opts, args = getopt.getopt(sys.argv[1:], "xh", ["help"])

    except getopt.error, msg:
        print msg
        print "for help use --help"
        sys.exit(-1)

    # process options
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(-1)
        
        if o in "-x":  # if -x option, then the list is a list of excluded file
            include = False

    # recurse
    for arg in args:
        if os.path.exists(arg):
            if include:
                print "-i %s" % (arg)
            else:
                print "-q %s" % (arg)
                
if __name__ == "__main__":
    main()                