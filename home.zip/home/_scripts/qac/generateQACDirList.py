# generateQACDirList.py - Class and fucntionality for BCMF build GUI
#
# S. Weber (AE-BE/ENG31-AU)
# 05-02-2009
#
# Revision history:
#
# Version 001.00 - 13.08.2008 - S. Weber (AE-BE/ENG3)
#   Initial revision.
#-------------------------------------------------------------------------
# Version 002.00 - 22.03.2010 - C. Baudry (AE-BE/ENG3)
#   Add 3rd party QAC analyze support
#-------------------------------------------------------------------------
# Version 002.01 - 29.09.2010 - C. Baudry (AE-BE/ENG3)
#   RCM 73104: File PROJECT_DIRS_TEMPLATE.mak: issue when no directory in 
#        3rd Party Tools and "THIRD_PARTY=\" is the last line of the file
#-------------------------------------------------------------------------
# Version 002.02 - 27.07.2011 - C. Baudry (AE-BE/ENG3)
#   Add the possibility to ONLY analyse the 3rd party SW or to
#                          INCLUDE the 3rd party SW in the project analysis
#-------------------------------------------------------------------------


''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

from generateDirList import *

''' Main class '''
class GenerateQACDirList:

    def __init__(self, srcDirs, incDirs, cfgFileTemplate, cfgFileGenerated, swEnvVar, onlyThirdParty, includeThirdParty):

        self.cfgMakFileTemplate = cfgFileTemplate
        self.cfgMakFileGenerated = cfgFileGenerated

        ''' read QAC template file '''
        cfgMakFileHandler = open(self.cfgMakFileTemplate, 'r')
        cfgList = cfgMakFileHandler.readlines()
        cfgMakFileHandler.close()

        swString = os.environ.get(swEnvVar)
        replString = "$(" + swEnvVar + ")"

        srcString = ""
        incString = ""

        for line in srcDirs:
            line = line.replace(swString, replString)
            srcString = srcString + line + "\\\n"
        ''' remove last \\\n '''
        srcString = srcString[:-2]

        incString = ""
        for line in incDirs:
            line = line.replace(swString, replString)
            incString = incString + line + "\\\n"
        ''' remove last \\\n '''
        incString = incString[:-2]

        ''' indexes definitions '''
        projectIndex = cfgList.index("PROJECT_FILES=\\\n")
        addProjectIndex = cfgList.index("ADDITIONAL_PROJECT_FILES=\\\n")
        includeIndex = cfgList.index("INCLUDE_FILES=\\\n")
        addIncludeIndex = cfgList.index("ADDITIONAL_INCLUDE_FILES=\\\n")
        ignoreIndex = cfgList.index("QAC_IGNORE_DIRECTORIES=\\\n")
        ''' RCM 73104 '''
        try:
            thirdPartyIndex = cfgList.index("THIRD_PARTY=\\\n")
        except:
            ''' in this case the string "THIRD_PARTY=\" is the last line of the file '''
            thirdPartyIndex = cfgList.index("THIRD_PARTY=\\")
        
        newCfgString = ""

        ''' build a new configuration file out of bits of the old file
        and the newly generated directorylist '''
        if onlyThirdParty == False:
            ''' Project code analyze '''
            for index in range(0,projectIndex+1):
                newCfgString = newCfgString + cfgList[index]

            newCfgString = newCfgString + srcString + "\n"
            
            ''' the 3rd party SW is included in the project part if required by the user '''
            if includeThirdParty == True:
                # we test if 3rd part SW is defined in the template file
                try:
                    if(cfgList[thirdPartyIndex+1].count('\\') != 0):
                        # in this case we concate 2 parts. We have to delete the "\n" and add a "\\n" in the last line of the QAC_IGNORE part
                        newCfgString = newCfgString[:-1] + "\\\n"
                        for index in range(thirdPartyIndex+1,len(cfgList)):
                            newCfgString = newCfgString + cfgList[index]
                except:
                    pass
            
            newCfgString = newCfgString + "\n"
            
            for index in range(addProjectIndex,includeIndex+1):
                newCfgString = newCfgString + cfgList[index]
                
            newCfgString = newCfgString + incString + "\n\n"

            ''' ADDITIONAL_INCLUDE_FILES '''
            for index in range(addIncludeIndex,ignoreIndex-1):
                newCfgString = newCfgString + cfgList[index]
            newCfgString = newCfgString + "\n"
            
            ''' QAC_IGNORE_DIRECTORIES '''
            for index in range(ignoreIndex,thirdPartyIndex-1):
                newCfgString = newCfgString + cfgList[index]
            
            ''' the 3rd party SW is included in the ignore part if not required by the user '''
            if includeThirdParty == False:
                # we test if 3rd part SW is defined in the template file
                try:
                    if(cfgList[thirdPartyIndex+1].count('\\') != 0):
                        # in this case we concate 2 parts. We have to delete the "\n" and add a "\\n" in the last line of the QAC_IGNORE part
                        newCfgString = newCfgString[:-1] + "\\\n"
                        for index in range(thirdPartyIndex+1,len(cfgList)):
                            newCfgString = newCfgString + cfgList[index]
                except:
                    pass
            
        else:
            ''' third party code analyze '''
            
            ''' before creating the file which contains the list, we have to delete 
            the enties in the project files list which are also in the third party files '''
            for index in range(len(srcDirs)):
                srcDirs[index] = srcDirs[index].replace(swString, replString)
                
            for item in range(thirdPartyIndex+1,len(cfgList)):
                try:
                    srcDirs.remove(cfgList[item][:-2])
                except:
                    pass
                
                # if it is the last element of the part, it does not have "\" at the end, we compare with a different string
                try:
                    srcDirs.remove(cfgList[item][:-1])
                except:
                    pass
                    
            ignoreString = ""
            for line in srcDirs:
                ignoreString = ignoreString + line + "\\\n"
            ''' remove last \n '''
            ignoreString = ignoreString[:-1]
        
            ''' HEADER '''
            for index in range(0,projectIndex):
                newCfgString = newCfgString + cfgList[index]
        
            ''' PROJECT_FILES are the 3rd party files '''
            newCfgString = newCfgString + cfgList[projectIndex]
            for index in range(thirdPartyIndex+1,len(cfgList)):
                newCfgString = newCfgString + cfgList[index]
            newCfgString = newCfgString + "\n"
            
            ''' ADDITIONAL_PROJECT_FILES are not present for the 3rd party analyze, 
            they are added in the ignore files'''
            newCfgString = newCfgString + cfgList[addProjectIndex]
            newCfgString = newCfgString + "\n"
            
            ''' INCLUDE_FILES are the same than the project code analyze '''
            newCfgString = newCfgString + cfgList[includeIndex]
            newCfgString = newCfgString + incString + "\n\n"
            
            ''' ADDITIONAL_INCLUDE_FILES are the same than the project code analyze '''
            for index in range(addIncludeIndex,ignoreIndex):
                newCfgString = newCfgString + cfgList[index]
                
            ''' QAC_IGNORE_DIRECTORIES '''
            newCfgString = newCfgString + cfgList[ignoreIndex]
            ''' project files '''
            newCfgString = newCfgString + ignoreString + "\n"
            
            ''' additional project files '''
            # we add the following lines only if additional SW is defined
            try:
                if(cfgList[addProjectIndex+1].count('\\') != 0):
                    for index in range(addProjectIndex+1,includeIndex-1):
                        newCfgString = newCfgString + cfgList[index]
                    newCfgString = newCfgString[:-1] + "\\\n"
            except:
                pass
                
            # we add the following lines only if ignore part is defined
            ''' ignore files '''
            try:
                if(cfgList[ignoreIndex+1].count('\\') != 0):
                    for index in range(ignoreIndex+1,thirdPartyIndex):
                        newCfgString = newCfgString + cfgList[index]
                    newCfgString = newCfgString[:-1] + "\\\n"
            except:
                pass
            
            # we delete the last "\\\n"
            newCfgString = newCfgString[:-2]
            
        #print newCfgString
        cfgMakFileHandler = open(self.cfgMakFileGenerated, 'w')
        cfgMakFileHandler.write(newCfgString)
        cfgMakFileHandler.close()



if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        bcmf_gen_main = GenerateQACDirList(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])

    except IndexError:

        error_message = "wrong number of parameters"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
