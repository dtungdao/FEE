# Append a list of files to the analyser personality:
#

#
#  python QAC_ANALYSE_PERSO.py
#  -i name of the marker for the include paths
#  -x name of the marker for the exclude paths
#  -f file where the paths are located
#
#  Will search the given directory file for the markers and copy all the paths
#  behind those markers to the analyser personality file

# S. Weber (AE-BE/ENG3)
# 26-09-2008
#
# Revision history:
#
# Version 001.00 - Silke Weber (AE-BE/ENG3)
#   Initial revision.
# Version 002.00 - Silke Weber (AE-BE/ENG3)
#   changed the script so that it uses a file not a variable as parameter
#   (the file list got too long)
# Version 002.01 - Silke Weber (AE-BE/ENG3)
#   changed the names of the environment variables.
#   optimised use of absolute paths
# Version 002.02 - Silke Weber (AE-BE/ENG31-AU)
#   Adapted the script for use of multiple blocks of include directories



import os
import sys
import getopt

def main():

    include = True

    '''get whatever environment variable is used'''
    try:
        viewpath = os.environ['BCMF_VIEWROOT']
        absViewpath = os.path.abspath(viewpath)
    except KeyError:
        print "\nEnvironment variable BCMF_VIEWROOT must be set to the viewpath"
        sys.exit(1)

    try:
        srcpath = os.environ['BCMF_SOFTWARE_BASE']
        absSrcpath = os.path.abspath(srcpath)
    except KeyError:
        print "\nEnvironment variable BCMF_SOFTWARE_BASE must be set to the viewpath"
        sys.exit(1)

    try:
        opts, args = getopt.getopt(sys.argv[1:], "i:x:f:h", ["help"])

    except getopt.error, msg:
        print msg
        print "for help use --help"
        sys.exit(-1)

    # process options
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(-1)

        if o in "-f":
            dirFile = a

    pathFile = open(dirFile)
    lineList = pathFile.readlines()
    pathFile.close()

    listLength = len(lineList)
    startIncludes = lineList.index("INCLUDE_FILES=\\\n") + 1
    startAddIncludes = lineList.index("ADDITIONAL_INCLUDE_FILES=\\\n") + 1
    startExcludes = lineList.index("QAC_IGNORE_DIRECTORIES=\\\n") + 1

    try:
        endIncludes = lineList.index("\n", startIncludes, startAddIncludes)
    except ValueError:
        endIncludes = startAddIncludes - 1

    try:
        endAddIncludes = lineList.index("\n", startAddIncludes, startExcludes)
    except ValueError:
        endAddIncludes = startExcludes - 1

    try:
        endExcludes = lineList.index("\n", startExcludes)
    except ValueError:
        endExcludes = listLength


    #print "indices %i, %i, %i, %i" start_includes, end_includes, start_excludes, end_excludes
    # recurse
    for pIndex in range(startIncludes, endIncludes):
        path = lineList[pIndex]
        if path[-2:] == "\\\n":
            cleanPath = path[:-2] + "\n"
        else:
            cleanPath = path

        ''' replace whatever environment variable was used for the path '''
        #complPath = os.path.expandvars(cleanPath)
        try:
            complPath = cleanPath.replace("$(BCMF_SOFTWARE_BASE)", absSrcpath)
        except ValueError:
            pass
        try:
           complPath2 = complPath.replace("$(BCMF_VIEWROOT)", absViewpath)
        except ValueError:
            pass
        print "-i %s" % (complPath2),

    for pIndex in range(startAddIncludes, endAddIncludes):
        path = lineList[pIndex]
        if path[-2:] == "\\\n":
            cleanPath = path[:-2] + "\n"
        else:
            cleanPath = path
        #print cleanPath,

        ''' replace whatever environment variable was used for the path '''
        #complPath = os.path.expandvars(cleanPath)
        try:
            complPath = cleanPath.replace("$(BCMF_SOFTWARE_BASE)", absSrcpath)
        except ValueError:
            pass
        try:
           complPath2 = complPath.replace("$(BCMF_VIEWROOT)", absViewpath)
        except ValueError:
            pass
        print "-i %s" % (complPath2),

    # recurse
    for pIndex in range(startExcludes, endExcludes):
        path = lineList[pIndex]
        if path[-2:] == "\\\n":
            cleanPath = path[:-2] + "\n"
        else:
            cleanPath = path
        ''' replace whatever environment variable was used for the path '''
        #complPath = os.path.expandvars(cleanPath)
        try:
            complPath = cleanPath.replace("$(BCMF_SOFTWARE_BASE)", absSrcpath)
        except ValueError:
            pass
        try:
           complPath2 = complPath.replace("$(BCMF_VIEWROOT)", absViewpath)
        except ValueError:
            pass
        print "-q %s" % (complPath2),

if __name__ == "__main__":
    main()