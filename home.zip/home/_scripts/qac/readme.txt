The batchfiles omakeQac.bat and omakeQacView.bat have to be called with following arguments 
(to be set in the configuration file):

1:      script path (usually %BCMF_SCRIPTS_ROOT%)

2: 	the type of analysis (project, module or third_party)
