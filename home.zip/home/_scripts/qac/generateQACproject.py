# generateQACproject.py - Class and fucntionality for BCMF build GUI
#
# Creates a QAC project file which can be opened with the QAC tool. 
# It can be usefull to use tools which are not available per command line.
#
# C. Baudry AE-BE/ENG3
# 25.07.2011
#
# Revision history:
#
# Version 001.00 - 25.07.2011 - C. Baudry AE-BE/ENG3
#   Initial revision.
#-------------------------------------------------------------------------
# Version 001.01 - 09.08.2012 - C. Baudry AE-BE/ENG3
#   Add the possibility to add files with relative path
#-------------------------------------------------------------------------


''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re


''' Main class '''
class GenerateQACproject:

    def __init__(self):

        __QACOutputPath = os.environ.get("QACOUTPATH")
        
        ''' check if the input file containing the QAC file list exists '''
        ''' if the file does not exist, the script is stopped and an error is printed '''
        inputFile = __QACOutputPath + "\\QAC_FILES.lst"
        qacProjectFile = os.environ.get("BCMF_SCRIPT_OUTPUT") + "\\qac_output\\QAC_Project.prj"
        
        try:
            inputFileHandler = open(inputFile, 'r')
            fileList = inputFileHandler.readlines()
            inputFileHandler.close()
        except:
            print "\n\nERROR: Impossible to create QAC project file!!\n\n"
            return
            
        ''' if the file exists and has content, we prepare the QAC project file content '''
        qacProjectFileContent = "VersionTag45\nStartProjectMarker\nFolderName=project_out\n"
        
        ''' source path '''
        ''' diferenciate relative with absolute paths '''
        if __QACOutputPath[0] == ".":
            __pathBegin = "..\\"
        else:
            __pathBegin = ""
        qacProjectFileContent = qacProjectFileContent + "SourcePath=" + __pathBegin + __QACOutputPath + "\\\n"
        qacProjectFileContent = qacProjectFileContent + "OutputPath=" + __pathBegin + __QACOutputPath + "\\\n"

            
        for line in fileList:
            if line[1] == ".":
                qacProjectFileContent = qacProjectFileContent + "..\\" + line
            elif line[0] != "-":
                qacProjectFileContent = qacProjectFileContent + line
                
        qacProjectFileContent = qacProjectFileContent + "EndContainedFilesMarker"
        
        ''' try to create the file '''
        try:
            qacProjectFileHandler = open(qacProjectFile, 'w')
            qacProjectFileHandler.write(qacProjectFileContent)
            qacProjectFileHandler.close()
        except:
            print "\n\nERROR: Impossible to create QAC project file!!\n\n"
            return


if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        bcmf_gen_main = GenerateQACproject(sys.argv[1])

    except IndexError:

        error_message = "wrong number of parameters"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
