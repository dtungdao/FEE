# generateQACDirModuleList.py - 
#
# Class and functionality for creating the file MODULE_DIRS_GENERATED.mak
#
# C. Baudry (AE-BE/ENG3)
# 04.02.2011
#
# Revision history:
#
# Version 001.00 - 04.02.2011 - C. Baudry (AE-BE/ENG3)
#   Initial revision. The function WriteDirectoryList from buildGUI.py
#                     has been included in this file
#-------------------------------------------------------------------------
# Version 001.01 - 07.02.2011 - C. Baudry (AE-BE/ENG3)
#   Add information in LOG file: include directories which are ignored 
#   while analyzing with the dependencies filter
#-------------------------------------------------------------------------
# Version 001.02 - 19.04.2011 - C. Baudry (AE-BE/ENG3)
# - Correct bug while using QAC without the parser: a copy of the 
#   PROJECT_DIRS.mak file creates a read-only file: the module file can
#   not be created and the whole project is analysed.    
#-------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os, stat

''' import re for regular expressions '''
import re

''' import subprocess for executing commands '''
import shutil

from generateDirList import *

''' Main class '''
class GenerateQACDirModuleList:

    # -------------------------------------------------------------------------
    # The init function creates the file MODULE_DIRS_GENERATED.mak based on 
    # the file PROJECT_DIRS_GENERATED.mak.
    # It also creates a LOG file QACModuleLOGFile.txt
    # -------------------------------------------------------------------------
    def __init__(self, incDirs, cfgFileGenerated, cfgFileModuleGenerated, sourceDir, moduleName, filterDependencies, configurationFile):
    
        ''' Copy the project file to get all usefull information: third party, ignore... '''
        shutil.copy(cfgFileGenerated, cfgFileModuleGenerated)
        
        ''' In the case the copied file is read only: make it writeable '''
        ''' This happens while using QAC without the parser: the file PROJECT_DIRS.mak is read-only and its copy 
            creates a read-only file '''
        fileAtt = os.stat(cfgFileModuleGenerated)[0]  
        if (not fileAtt & stat.S_IWRITE):    
            os.chmod(cfgFileModuleGenerated, stat.S_IWRITE)
    
        ''' Get the subdirectories in the toplevel directory: Source and Include '''
        self.moduleList = sourceDir + "\\" +  moduleName
        
        ''' get the source and include directories lists '''
        allSourceSubdirs = []
        allIncludeSubdirs = []
        allSourceSubdirs = GenerateDirList(self.moduleList, configurationFile).GetSourceDirList()
        allIncludeSubdirs = GenerateDirList(self.moduleList, configurationFile).GetIncludeDirList()
        
        ''' QAC Module analysis LOG file '''
        qacModuleLOG = "QAC Module analysis LOG file\n"
        qacModuleLOG = qacModuleLOG + "\n- Analyzed module: " + moduleName
        qacModuleLOG = qacModuleLOG + "\n- Found source directories (with general parser):"
        for element in allSourceSubdirs:
            qacModuleLOG = qacModuleLOG + "\n    " + element
        qacModuleLOG = qacModuleLOG + "\n- Found include directories (with general parser):"
        for element in allIncludeSubdirs:
            qacModuleLOG = qacModuleLOG + "\n    " + element
        qacModuleLOG = qacModuleLOG + "\n- List all include directories in the project (with configured parser: general or GHS):"
        for element in incDirs:
            qacModuleLOG = qacModuleLOG + "\n    " + element
        
        ''' sort out SOURCE directories with blanks in them '''
        complSourceList = []
        for entry in allSourceSubdirs:
            if entry[0].find(' ') == -1:
                entryCompl = entry + "\\\n"
                complSourceList.append(entryCompl)
        complSourceList.append("\n")
        
        ''' sort out INCLUDE directories with blanks in them '''
        ''' apply lower case for all entries '''
        complIncludeList = []
        for entry in allIncludeSubdirs:
            if entry[0].find(' ') == -1:
                entryCompl = entry.lower() + "\\\n"
                complIncludeList.append(entryCompl)
        
        ''' create a string with the list of subdirectories '''
        directoryListInFile = []
        directoryListInFile.append("PROJECT_FILES=\\\n")
        for entry in complSourceList:
            directoryListInFile.append(entry)

        try:
            directoryFile = open(cfgFileModuleGenerated, "r")
            lineList = directoryFile.readlines()
            directoryFile.close()
        except:
            print "\nError with the QAC module directory file!!"
            print "The file " + cfgFileModuleGenerated + " can not be read.\n\n"
        
        ''' MODULE_DIRS_GENERATED.mak indexes '''
        includeIndex = lineList.index("INCLUDE_FILES=\\\n")
        additionalIncludeIndex = lineList.index("ADDITIONAL_INCLUDE_FILES=\\\n")
        ignoreDirectoriesIndex = lineList.index("QAC_IGNORE_DIRECTORIES=\\\n")
        
        ''' for the module analysis, the user has the choice to filter or not 
        the dependencies which are not included in the analyzed component'''
        
        ''' with or without filter, all include paths are required '''
        directoryListInFile.extend(lineList[includeIndex:ignoreDirectoriesIndex])
        
        ''' apply filter in the QAC_IGNORE_DIRECTORIES part if required '''
        directoryListInFile.extend(lineList[ignoreDirectoriesIndex])
        
        if filterDependencies == 1:
            ''' QAC Module analysis LOG file '''
            qacModuleLOG = qacModuleLOG + "\n\n--> The dependencies filter has been selected.\n"
            firstFindElement = 0
            firstFindIgnoredElement = 0
            ignoreLOG = ""
            notIgnoreLOG = ""
            
            ''' all paths but those which belong to the component itself are ignored '''
            for element in incDirs:
                if element.lower() + "\\\n" not in complIncludeList:
                    directoryListInFile.append(element + "\\\n")
                    ''' QAC Module analysis LOG file '''
                    if firstFindIgnoredElement == 0:
                        ignoreLOG = ignoreLOG + "\n- The following include directories are ignored:"
                        firstFindIgnoredElement = 1
                    ignoreLOG = ignoreLOG + "\n    " + element
                else:
                    ''' QAC Module analysis LOG file '''
                    if firstFindElement == 0:
                        notIgnoreLOG = notIgnoreLOG + "\n- The following include directories won't be ignored:"
                        firstFindElement = 1
                    notIgnoreLOG = notIgnoreLOG + "\n    " + element
            
            ''' QAC Module analysis LOG file '''
            qacModuleLOG = qacModuleLOG + notIgnoreLOG + "\n" + ignoreLOG
            
        else:
            ''' QAC Module analysis LOG file '''
            qacModuleLOG = qacModuleLOG + "\n\n--> The dependencies filter has NOT been selected.\n"
        ''' QAC Module analysis LOG file '''
        qacModuleLOG = qacModuleLOG + "\n\n"
        
        directoryListInFile.extend(lineList[ignoreDirectoriesIndex+1:])
        
        ''' write directory list into the module file '''
        try:
            directoryFile = open(cfgFileModuleGenerated, "w")
            directoryFile.writelines(directoryListInFile)
            directoryFile.close()
        except:
            print "\n\nError with the QAC module directory file!!"
            print "The file " + cfgFileModuleGenerated + " can not be written or created.\n\n"
        
        ''' write LOG file '''
        try:
            LOGFilePath = os.environ.get("BCMF_TEMP_OUT") + "\\QACModuleLOGFile.txt"
            LOGFile = open(LOGFilePath, "w")
            LOGFile.writelines(qacModuleLOG)
            LOGFile.close()
        except:
            print "\n\nError with the QAC module LOG file!!"
            print "The file " + LOGFilePath + " can not be written or created.\n\n"
            


if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        bcmf_gen_main = GenerateQACDirModuleList(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])

    except IndexError:

        error_message = "wrong number of parameters"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
