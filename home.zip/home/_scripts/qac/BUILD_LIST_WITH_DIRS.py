# BUILD_LIST_WITH_DIRS.py - Script to list all the C-Files contained in a list of files
#
# python listFiles  -l -a -e ext1,ext2,ext3 -o replaceFilePathWithThis -n .newExtenstion -p prefrix DIR1 DIR2 DIR3 ... -f
#
# will search directories, DIR1, DIR2, and so on, looking for files with the extension ext1 or ext2 or ,... 
# and return a list of those matching files, but with new extension.
# If the GHSList option is set, it will remove the files which have not been found in the gpj files 
#
#
# Autor
# Date
#
# Revision history:
#
# Version 001.00 - date - autor
#   Initial revision.
#---------------------------------------------------------------------------------------------------
# Version 002.00 - 07.10.2010 - C. Baudry (AE-BE/ENG3)
#   RCM 75087: Add GHS List filter to delete the files which are not part of the gpj files
#---------------------------------------------------------------------------------------------------
# Version 002.01 - 14.10.2010 - C. Baudry (AE-BE/ENG3)
#   Fix GHS List filter: the comparison was case-sensitive: some files were rejected of the 
#                        analysis. It has been corrected with this fix
#---------------------------------------------------------------------------------------------------
# Version 002.02 - 17.03.2011 - C. Baudry (AE-BE/ENG3)
#   Parameter filterGHS renamed to optimisationParser (more general if using other optimizers)
#---------------------------------------------------------------------------------------------------

import os
import sys
import getopt

def main():

    prefix = ''
    extension = ''
    newExt = ''
    filePathReplacement = None
    joinLines = False
    optimisationParser = False

    try:
        opts, args = getopt.getopt(sys.argv[1:], "lhe:p:n:o:f:", ["help"])

    except getopt.error, msg:
        print msg
        print "for help use --help"
        sys.exit(2)

    # process options
    for o, a in opts:
        if o in ("-h", "--help"):
            print __doc__
            sys.exit(0)

        if o in '-p':
            prefix = a

        if o in '-o':
            filePathReplacement = a
            
        if o in '-e':
            extension = a

        if o in '-n':
            newExt = a

        if o in '-l':
            joinLines = True
            
        if o in '-f':
            optimisationParser = a

    if optimisationParser == "GHS":
        ''' Green Hills GPJ file filter preparation'''
        # if we are using a GHS compiler, we can check if the qac files are present in the gpj files
        # to do that we use the result of the script generateGHSDirList.py which is available in the file
        # GHSListSourcesTempFile.txt
        # If a qac file is not in the gpj files, we do not have to analyse it, it can be removed from the list
        
        # Read the file content
        tempOutpath = os.environ.get("BCMF_TEMP_OUT") 
        sourcesTempFile = tempOutpath + "\\GHSListSourcesTempFile.txt"
        GHSSourceFileList = open(sourcesTempFile, 'r')
        GHSListFileData = GHSSourceFileList.read()
        GHSSourceFileList.close()
        
        # the file content is converted in a list
        GHSSrcList = GHSListFileData.splitlines()
        
        # the spaces are deleted
        # for a better comparison, all characters are converted with upper letters
        for index in range(len(GHSSrcList)):
            GHSSrcList[index] = GHSSrcList[index].lstrip()
            GHSSrcList[index] = GHSSrcList[index].upper()
        
        # we only keep the file name '''
        for index in range(len(GHSSrcList)):
            result = os.path.split(GHSSrcList[index])
            GHSSrcList[index] = result[1]
        ''' END Green Hills GPJ file filter preparation'''

        
    # go
    print prefix,
    
    urgs = []
    with open ('..\\_scripts_output\\qac_output\\AnalysisSupportFiles\\VPATH_output.txt','r') as f:
        for line in f:
            print >> sys.stderr, line
            if len(line) > 4:
                elems = line.strip().split(" ")
                for elem in elems:
                    #print elem            
                    if len(elem) > 4:
                        urgs.append(elem)
    print >> sys.stderr, urgs
    # recuree
#    for arg in args:
    for arg in urgs:

        if os.path.exists(arg):
            files =  os.listdir( arg )

            for file in files:
                
                for ext in extension.split(','):
                    if(    file.endswith( ext ) > 0 ):
                        
                        # do we need the GHS filter?
                        if optimisationParser == "GHS":
                            
                            if file.upper() in GHSSrcList:
                                
                                if joinLines:
                                    print '\\'

                                if filePathReplacement == None:
                                    print arg +'\\' + file.split(ext)[0] + newExt + ' ',
                                else:                            
                                    print filePathReplacement +'\\' + file.split(ext)[0] + newExt + ' ',
                                    
                            else:
                                print >> sys.stderr, 'File has been removed from the analysis: ' + file
                        
                        # the GHS filter is not required
                        else:
                            if joinLines:
                                print '\\'

                            if filePathReplacement == None:
                                print arg +'\\' + file.split(ext)[0] + newExt + ' ',
                            else:                            
                                print filePathReplacement +'\\' + file.split(ext)[0] + newExt + ' ',
                                
        else:                            
            print >> sys.stderr, ""
            print >> sys.stderr, 'Error: The path "' + arg + '" doesn\'t seem to be valid, Check PROJECT_DIRS_TEMPLATE.mak'
            print >> sys.stderr, ""
            sys.exit(-1)


if __name__ == "__main__":

    main()





