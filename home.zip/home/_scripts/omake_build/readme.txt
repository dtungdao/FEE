The batch o_make_genBUILD.bat has to be called with following arguments (to be set in the configuration file):
1:      nop     - no option
        clean   - will trigger a rebuild i.e. delete old objects before the build
2: 		release
		debug
3:      temporary output path
4:        script path for omake scripts
5:      directory mak, this includes all directories necessary for the build
6:      options mak, this includes all options for the compiler

The other batch files can be called directly from this folder.

Changes in the file projectConfig_buildGUI.cfg:

# Build file and options for main application
CONFIG BUILD_FILE               PROJECT_DIRS.mak PROJECT_OPTS.mak

# Build file and options for STARTUP
CONFIG BUILD_FILE_STARTUP       ..\ROM_STARTUP\_build_V850FX3\PROJECT_STARTUP_DIRS.mak ..\ROM_STARTUP\_build_V850FX3\PROJECT_STARTUP_OPTS.mak

# Build file and options for EOL
CONFIG BUILD_FILE_EOL           ..\ROM_EOL\_build_V850FX3\PROJECT_EOL_DIRS.mak ..\ROM_EOL\_build_V850FX3\PROJECT_EOL_OPTS.mak

# Build and rebuild options
CONFIG OPTIONS_BUILD            nop ..\_scripts_output_V850FX3\omake_output\MakeSupportFiles\ ..\_scripts\omake_build\
CONFIG OPTIONS_REBUILD          clean ..\_scripts_output_V850FX3\omake_output\MakeSupportFiles\ ..\_scripts\omake_build\

# Greenhills builder paths
CONFIG GREENHILLS_BUILDER_PATH  ..\_scripts\omake_build\
CONFIG GREENHILLS_BUILDER_EXE   o_make_genBUILD.bat

CONFIG BUILD_TEMP_OUTPATH       ..\_scripts_output_V850FX3\omake_output\MakeSupportFiles\
