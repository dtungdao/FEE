# versions.py - Class for checking / reading tool versions
#
# G. Robinson (AE-BE/ENG5)
# 21-02-2008
#
# Revision history:
#
# Version 001.00 - 21.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision. Currently compitable with the following tools:
#   1. Python
# Version 002.00 - 25.02.2008 - G. Robinson (AE-BE/ENG5)
#   Extended capibility to work with linker and compiler.
#   Used internal sys.version_info method for python version.
#   Version check first converts any characters to lower case
#   before any checking is made.
# Version 003.00 - 11.03.2008 - G. Robinson (AE-BE/ENG5)
#   Fixed command variable naming.
# Version 003.01 - 26.09.2008 - S. Weber (AE-BE/EBS4-AU)
#   Added version check for QAC
#   removed ReCheck from _init, so that it is not called unnecessarily
# Version 003.02 - 18.02.2010 - C.Baudry (AE-BE/ENG3)
#   Added version check for WinIDEA
#----------------------------------------------------------------------------------------
# Version 003.03 - 11.03.2010 - C.Baudry (AE-BE/ENG3)
#   The WinIDEA install path used to check the version is read from a file
#----------------------------------------------------------------------------------------
# Version 003.04 - 17.03.2010 - C.Baudry (AE-BE/ENG3)
#   The WinIDEA install path is get from the env variable WINIDEA_LOCAL, not from a file anymore
#----------------------------------------------------------------------------------------
# Version 003.05 - 28.06.2010 - C.Baudry (AE-BE/ENG3)
#   The function GetToolInformation has been added. It returns the content of tool_information.
#   The QAC and WinIDEA version checks are done only if the expected version is given on the 
#       projectConfig_versions.cfg file
#   The function GetToolRequiredAction has been added. It returns a tool required action to be 
#       triggered by the GUI; ex install or update 
#----------------------------------------------------------------------------------------
# Version 003.06 - 01.07.2010 - C.Baudry (AE-BE/ENG3)
#   The Compiler and Linker version checks are done only if the expected version is given on the 
#       projectConfig_versions.cfg file
#----------------------------------------------------------------------------------------
# Version 003.07 - 01.02.2011 - C.Baudry (AE-BE/ENG3)
#   RCM Activity 64755: If the installed WinIDEA version is newer than the requested version,
#                       the user is prevented but its version is not reported as wrong.
#----------------------------------------------------------------------------------------
# Version 003.08 - 15.05.2012 - C.Baudry (AE-BE/ENG3)
#   WinIDEA version: add the possibility to install a new year version (ex: 2011 to 2012)
#----------------------------------------------------------------------------------------
# Version 003.09 - 20.07.2012 - C.Baudry (AE-BE/ENG3)
#   WinIDEA version: correct the behaviour in the case the installed year version is newer 
#                    than the required: only prevent the user, no action
#----------------------------------------------------------------------------------------
# Version 004.00 - 17.05.2013 - C.Baudry (AE-BE/ENG3)
#   WinIDEA version: change the way to get the version because of installer update from iSystem
#                    The version is now read from the winIDEA.exe properties
#                    !! this script version works with WinIDEA from 9.12.101 !!
#----------------------------------------------------------------------------------------
# Version 004.01 - 21.05.2013 - C.Baudry (AE-BE/ENG3)
#   QAC version: change the version command to redirect both stdout and stderr
#   WinIDEA version: correct the version numbers comparisons
#----------------------------------------------------------------------------------------
# Version 004.02 - 17.06.2013 - C.Baudry (AE-BE/ENG3)
#   WinIDEA version: update %path% for the win32api dll
#----------------------------------------------------------------------------------------
# Version 004.03 - 12.09.2014 - D.Dal Piva (AE-BE/ENG3)
#   Add CANoe version check
#----------------------------------------------------------------------------------------

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import the configuration file handler '''
from configFile import ConfigFile

''' required to read exe file properties '''
os.environ["PATH"] = os.environ.get("BCMF_TOOLS_ROOT") + "\\python;" + os.environ.get("PATH")
from win32api import GetFileVersionInfo, LOWORD, HIWORD

''' config file definitions '''
CFG_PYTHON_VERSION_EXPECTED       = "PYTHON_VERSION_EXPECTED"

CFG_COMPILER_VERSION_EXPECTED     = "COMPILER_VERSION_EXPECTED"
CFG_COMPILER_PATH                 = "COMPILER_PATH"
CFG_COMPILER_EXE                  = "COMPILER_EXE"
CFG_COMPILER_VERSION_OPTIONS      = "COMPILER_VERSION_OPTIONS"

CFG_LINKER_VERSION_EXPECTED       = "LINKER_VERSION_EXPECTED"
CFG_LINKER_PATH                   = "LINKER_PATH"
CFG_LINKER_EXE                    = "LINKER_EXE"
CFG_LINKER_VERSION_OPTIONS        = "LINKER_VERSION_OPTIONS"

CFG_RESOURCE_OUTPUT_PATH          = "RESOURCE_OUTPUT_PATH"

CFG_QAC_VERSION_EXPECTED          = "QAC_VERSION_EXPECTED"
CFG_QAC_PATH                      = "QAC_PATH"
CFG_QAC_EXE                       = "QAC_EXE"
CFG_QAC_VERSION_OPTIONS           = "QAC_VERSION_OPTIONS"

CFG_WINIDEA_VERSION_EXPECTED      = "WINIDEA_VERSION_EXPECTED"

CFG_CANOE_VERSION_EXPECTED        = "CANOE_VERSION_EXPECTED"
CFG_CANOE_SP_NUMBER_EXPECTED      = "CANOE_SP_NUMBER_EXPECTED"
CFG_CANOE_SP_NAME_EXPECTED        = "CANOE_SP_NAME_EXPECTED"

''' tempory file names '''
TMP_FILE_COMPILER_VER             = "compilerVersion.txt"
TMP_FILE_LINKER_VER               = "linkerVersion.txt"
TMP_FILE_QAC_VER                  = "qacVersion.txt"
TMP_FILE_WINIDEA                  = "winIDEAVersion.txt"
TMP_FILE_CANOE                    = "CANoeVersion.txt"

''' tool ID '''
ID_PYTHON                         = "Python"
ID_COMPILER                       = "Compiler"
ID_LINKER                         = "Linker"
ID_QAC                            = "QAC"
ID_WINIDEA                        = "WinIDEA"
ID_CANOE                          = "CANoe"


''' class for the tools versions '''
class ToolVersions:

    def __init__(self, configuration_file):
        ''' set up the configuration file '''
        self.configuration = ConfigFile(configuration_file).ConfigDictionary()

        self.result   = {}
        self.versions = {}
        
        ''' the variable tool_information can be used to write on the GUI usefull information about the tools '''
        self.tool_information = {}
        
        ''' the variable tool_required_action can be used to trigger actions in the GUI; ex Install or Update '''
        self.tool_required_action = {}

        self.versions[ID_PYTHON] = self.configuration[CFG_PYTHON_VERSION_EXPECTED]
        if CFG_COMPILER_VERSION_EXPECTED in self.configuration:
            self.versions[ID_COMPILER] = self.configuration[CFG_COMPILER_VERSION_EXPECTED]
        if CFG_LINKER_VERSION_EXPECTED in self.configuration:
            self.versions[ID_LINKER] = self.configuration[CFG_LINKER_VERSION_EXPECTED]
        if CFG_QAC_VERSION_EXPECTED in self.configuration:
            self.versions[ID_QAC] = self.configuration[CFG_QAC_VERSION_EXPECTED]
        if CFG_WINIDEA_VERSION_EXPECTED in self.configuration:
            self.versions[ID_WINIDEA] = self.configuration[CFG_WINIDEA_VERSION_EXPECTED]
        if CFG_CANOE_VERSION_EXPECTED in self.configuration:
            self.versions[ID_CANOE] = self.configuration[CFG_CANOE_VERSION_EXPECTED]
            os.environ['EXPECTED_CANOE_VERSION'] = self.configuration[CFG_CANOE_VERSION_EXPECTED]
            if CFG_CANOE_SP_NUMBER_EXPECTED in self.configuration:
                self.versions[ID_CANOE] = self.configuration[CFG_CANOE_VERSION_EXPECTED] + "." + self.configuration[CFG_CANOE_SP_NUMBER_EXPECTED]
                os.environ['EXPECTED_CANOE_SP_NUMBER'] = self.configuration[CFG_CANOE_SP_NUMBER_EXPECTED]
                if CFG_CANOE_SP_NAME_EXPECTED in self.configuration:
                    self.versions[ID_CANOE] = self.configuration[CFG_CANOE_VERSION_EXPECTED] + "." + self.configuration[CFG_CANOE_SP_NUMBER_EXPECTED] + " (" + self.configuration[CFG_CANOE_SP_NAME_EXPECTED] + ")"
                    os.environ['EXPECTED_CANOE_SP_NAME'] = self.configuration[CFG_CANOE_SP_NAME_EXPECTED]


    def CompareWinIDEAVersions(self, expected_version, installed_version):
        
        ''' return values '''
        CURRENT_MINOR_NEWER   = 0
        CURRENT_MINOR_OLDER   = 1
        CURRENT_VERSION_SAME  = 2
        CURRENT_YEAR_OLDER    = 3
        CURRENT_YEAR_NEWER    = 4
        CURRENT_MAJOR_OLDER   = 5
        CURRENT_MAJOR_NEWER   = 6
        
        
        # EX: WinIDEA version format 9.10.156 newer than 9.9.200
        # EX: WinIDEA version format 9.12.24 newer than 9.11.80 and year change
        split_expected_version = re.split("\.", expected_version)
        split_installed_version = re.split("\.", installed_version)
        
        if int(split_installed_version[0]) < int(split_expected_version[0]):
            return CURRENT_MAJOR_OLDER
        elif int(split_installed_version[0]) > int(split_expected_version[0]):
            return CURRENT_MAJOR_NEWER
            
        if int(split_installed_version[1]) < int(split_expected_version[1]):
            return CURRENT_YEAR_OLDER
        elif int(split_installed_version[1]) > int(split_expected_version[1]):
            return CURRENT_YEAR_NEWER
            
        if int(split_installed_version[2]) < int(split_expected_version[2]):
            return CURRENT_MINOR_OLDER
        elif int(split_installed_version[2]) > int(split_expected_version[2]):
            return CURRENT_MINOR_NEWER
            
        return CURRENT_VERSION_SAME

        
    def ReCheck(self, configuration_file):

        ''' try to initialise as some configuration options may be not present '''
        try:
            
            '''--------------------------------------------------------------------------------------'''
            ''' get the python version '''
            read_version = str(sys.version_info[0]) + "." + str(sys.version_info[1]) + "." + str(sys.version_info[2])

            '''--------------------------------------------------------------------------------------'''
            ''' get the compiler version '''
            if CFG_COMPILER_VERSION_EXPECTED in self.configuration:
                compiler_output_file = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + TMP_FILE_COMPILER_VER
                command_compiler_version = self.configuration[CFG_COMPILER_PATH] + self.configuration[CFG_COMPILER_EXE] + " " \
                + self.configuration[CFG_COMPILER_PATH] + self.configuration[CFG_COMPILER_VERSION_OPTIONS] + " > " + compiler_output_file
                os.system(command_compiler_version)

            '''--------------------------------------------------------------------------------------'''
            ''' get the linker version '''
            if CFG_LINKER_VERSION_EXPECTED in self.configuration:
                linker_output_file = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + TMP_FILE_LINKER_VER
                command_linker_version = self.configuration[CFG_LINKER_PATH] + self.configuration[CFG_LINKER_EXE] + " " \
                + self.configuration[CFG_LINKER_PATH] + self.configuration[CFG_LINKER_VERSION_OPTIONS] + " > " + linker_output_file
                os.system(command_linker_version)

            '''--------------------------------------------------------------------------------------'''
            ''' get the QAC version '''
            if CFG_QAC_VERSION_EXPECTED in self.configuration:
                qac_output_file = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + TMP_FILE_QAC_VER
                command_qac_version = self.configuration[CFG_QAC_PATH] + self.configuration[CFG_QAC_EXE] + " " \
                + self.configuration[CFG_QAC_VERSION_OPTIONS] + " > " + qac_output_file + " 2>&1"
                os.system(command_qac_version)
            
            '''--------------------------------------------------------------------------------------'''
            ''' get the winIDEA version '''
            if CFG_WINIDEA_VERSION_EXPECTED in self.configuration:
                winidea_output_file = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + TMP_FILE_WINIDEA
            
                # read winidea.exe properties to get the version
                # the last part of the version is not used and can be ignored
                try:
                    __info = GetFileVersionInfo (os.environ.get("WINIDEA_LOCAL") + "\\winIDEA.exe", "\\")
                    tmpFile = open(winidea_output_file, "w")
                    tmpFile.write(str(HIWORD(__info['FileVersionMS'])) + "." + str(LOWORD(__info['FileVersionMS'])) + "." + str(HIWORD(__info['FileVersionLS'])))
                    tmpFile.close()
                
                except:
                    tmpFile = open(winidea_output_file, "w")
                    tmpFile.writelines("WinIDEA is not installed on your computer!")
                    tmpFile.close()

            '''--------------------------------------------------------------------------------------'''
            ''' get the CANoe version '''
            if CFG_CANOE_VERSION_EXPECTED in self.configuration:
                canoe_output_file = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + TMP_FILE_CANOE

                # read CANoe.exe properties to get the version
                # the last part of the version is not used and can be ignored
                try:
                    __info = GetFileVersionInfo ("C:\\Program Files (x86)\\Vector CANoe " + self.configuration[CFG_CANOE_VERSION_EXPECTED] + "\\Exec32\\CANoe32.exe", "\\")
                    tmpFile = open(canoe_output_file, "w")
                    tmpFile.write(str(HIWORD(__info['FileVersionMS'])) + "." + str(LOWORD(__info['FileVersionMS'])) + "." + str(HIWORD(__info['FileVersionLS'])))
                    tmpFile.close()

                except:
                    tmpFile = open(canoe_output_file, "w")
                    tmpFile.writelines("CANoe is not installed as expected on your computer!")
                    tmpFile.close()

            '''--------------------------------------------------------------------------------------''' 

            ''' check the versions '''
            ''' True = GOOD '''
            if(self.configuration[CFG_PYTHON_VERSION_EXPECTED] == read_version):
                self.result[ID_PYTHON] = True
            else:
                self.result[ID_PYTHON] = False

            ''' process the compiler version '''
            if CFG_COMPILER_VERSION_EXPECTED in self.configuration:
                data_file = open(compiler_output_file)

                try:
                    compiler_file_data = data_file.read().lower()

                finally:
                    data_file.close()

            ''' process the linker version '''
            if CFG_LINKER_VERSION_EXPECTED in self.configuration:
                data_file = open(linker_output_file)

                try:
                    linker_file_data = data_file.read().lower()

                finally:
                    data_file.close()

            ''' process the qac version '''
            if CFG_QAC_VERSION_EXPECTED in self.configuration:
                data_file = open(qac_output_file)

                try:
                    qac_file_data = data_file.read().lower()

                finally:
                    data_file.close()
                
            ''' process the winIDEA version '''
            if CFG_WINIDEA_VERSION_EXPECTED in self.configuration:
                
                ''' read the temp file which contains the version string '''
                data_file = open(winidea_output_file)
                try:
                    winIDEA_file_data = data_file.read()
                finally:
                    data_file.close()
                
                matched_winIDEA_version = re.search(self.configuration[CFG_WINIDEA_VERSION_EXPECTED], winIDEA_file_data)
                
                
                ''' check the version '''
                
                # no change
                if(matched_winIDEA_version <> None):
                    self.result[ID_WINIDEA] = True
                    self.tool_information[ID_WINIDEA] = ""
                    self.tool_required_action[ID_WINIDEA] = "DoNothing"
                
                # WinIDEA not installed
                elif re.search("WinIDEA is not installed on your computer!", winIDEA_file_data):
                    self.result[ID_WINIDEA] = False
                    self.tool_information[ID_WINIDEA] = "WinIDEA is not installed on your computer!"
                    self.tool_required_action[ID_WINIDEA] = "ToInstall"
                
                # other version
                else:
                    
                    # newer version required with only update
                    if (self.CompareWinIDEAVersions(self.configuration[CFG_WINIDEA_VERSION_EXPECTED], winIDEA_file_data)==1):
                        ''' Update required if the version is older '''
                        self.result[ID_WINIDEA] = False
                        self.tool_information[ID_WINIDEA] = "WinIDEA has to be updated!\n  Current version:    " \
                        + winIDEA_file_data + "\n  Required version:  " + self.configuration[CFG_WINIDEA_VERSION_EXPECTED]
                        self.tool_required_action[ID_WINIDEA] = "ToUpdate"
                    
                    # older version required with only update
                    elif (self.CompareWinIDEAVersions(self.configuration[CFG_WINIDEA_VERSION_EXPECTED], winIDEA_file_data)==0):
                        ''' we only prevent the user if the version is newer than required '''
                        self.result[ID_WINIDEA] = True
                        self.tool_information[ID_WINIDEA] = "WinIDEA version required by the project: " \
                        + self.configuration[CFG_WINIDEA_VERSION_EXPECTED] + "\n  Your WinIDEA version is newer than required!\n" \
                        + "  You have the possibility to install the project\n  required version, please ask the integrator for \n  more information."
                        self.tool_required_action[ID_WINIDEA] = "ToUpdate"
                        ''' in this case the version showed on the GUI in not the expected but the installed '''
                        self.versions[ID_WINIDEA] = winIDEA_file_data
                    
                    # year version has changed (increased): need a complete new install
                    elif (self.CompareWinIDEAVersions(self.configuration[CFG_WINIDEA_VERSION_EXPECTED], winIDEA_file_data)==3):
                        self.result[ID_WINIDEA] = False
                        self.tool_information[ID_WINIDEA] = "WinIDEA has to be updated!\n  Current version:    " \
                        + winIDEA_file_data + "\n  Required version:  " + self.configuration[CFG_WINIDEA_VERSION_EXPECTED]
                        self.tool_required_action[ID_WINIDEA] = "ToInstall"
                        
                    # year version has changed (decreased): do nothing, just prevent the user
                    elif (self.CompareWinIDEAVersions(self.configuration[CFG_WINIDEA_VERSION_EXPECTED], winIDEA_file_data)==4):
                        ''' we only prevent the user if the version is newer than required '''
                        self.result[ID_WINIDEA] = True
                        self.tool_information[ID_WINIDEA] = "WinIDEA version required by the project: " \
                        + self.configuration[CFG_WINIDEA_VERSION_EXPECTED] + "\n  Your WinIDEA version is newer than required!\n"
                        self.tool_required_action[ID_WINIDEA] = "DoNothing"
                        ''' in this case the version showed on the GUI in not the expected but the installed '''
                        self.versions[ID_WINIDEA] = winIDEA_file_data
                      
            ''' process the CANoe version '''
            if CFG_CANOE_VERSION_EXPECTED in self.configuration:
                data_file = open(canoe_output_file)

                try:
                    canoe_file_data = data_file.read().lower()
                    if CFG_CANOE_SP_NUMBER_EXPECTED in self.configuration:
                        os.environ['INSTALLED_CANOE_VERSION_SP'] = canoe_file_data
                    else:
                        split_installed_version = re.split("\.", canoe_file_data)
                        os.environ['INSTALLED_CANOE_VERSION_SP'] = split_installed_version[0] + '.' + split_installed_version[1]

                finally:
                    data_file.close()
                      
            ''' search the files for the appropiate version string '''
            if CFG_COMPILER_VERSION_EXPECTED in self.configuration:
                matched_compiler_version = re.search(self.configuration[CFG_COMPILER_VERSION_EXPECTED].lower(), compiler_file_data)
            if CFG_LINKER_VERSION_EXPECTED in self.configuration:
                matched_linker_version = re.search(self.configuration[CFG_LINKER_VERSION_EXPECTED].lower(), linker_file_data)
            if CFG_QAC_VERSION_EXPECTED in self.configuration:
                matched_qac_version = re.search(self.configuration[CFG_QAC_VERSION_EXPECTED].lower(), qac_file_data)
            if CFG_CANOE_VERSION_EXPECTED in self.configuration:
                matched_canoe_version = re.search(self.configuration[CFG_CANOE_VERSION_EXPECTED].lower(), canoe_file_data)
                if CFG_CANOE_SP_NUMBER_EXPECTED in self.configuration:
                    matched_canoe_version = re.search(self.configuration[CFG_CANOE_VERSION_EXPECTED].lower() + "." + self.configuration[CFG_CANOE_SP_NUMBER_EXPECTED].lower(), canoe_file_data)

            if CFG_COMPILER_VERSION_EXPECTED in self.configuration:
                if(matched_compiler_version <> None):
                    self.result[ID_COMPILER] = True
                else:
                    self.result[ID_COMPILER] = False

            if CFG_LINKER_VERSION_EXPECTED in self.configuration:
                if(matched_linker_version <> None):
                    self.result[ID_LINKER] = True
                else:
                    self.result[ID_LINKER] = False
             
            if CFG_QAC_VERSION_EXPECTED in self.configuration:
                if(matched_qac_version <> None):
                    self.result[ID_QAC] = True
                else:
                    self.result[ID_QAC] = False
                    
            if CFG_CANOE_VERSION_EXPECTED in self.configuration:
                if(matched_canoe_version <> None):
                    self.result[ID_CANOE] = True
                else:
                    self.result[ID_CANOE] = False
                
                    
        except IOError:
            error_message = "Problem processing the temp files"

            print "\n" + "-" * len(error_message)
            print "Error:"
            print error_message
            print "-" * len(error_message) + "\n"

            ''' stop the program as this error is fatal '''
            raise

        except KeyError, detail:
            ''' catch the errors when a configuration option is missing form the file '''

            error_message = "Following configuration needs to be added: " + str(detail)

            print "\n" + "-" * len(error_message)
            print "Error:"
            print error_message
            print "-" * len(error_message) + "\n"

            ''' stop the program as this error is fatal '''
            raise

    
    def VersionReport(self):

        return self.result

    
    def ExpectedVersionReport(self):

        return self.versions
        
    
    def GetToolInformation(self):
    
        return self.tool_information
        
    
    def GetToolRequiredAction(self):
    
        return self.tool_required_action


if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        test_class = ToolVersions(sys.argv[1])

    except IndexError:

        error_message = "Usage: python versions.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise

    print "\nVersion Report:"
    print test_class.VersionReport()

    print "\nExpected Version Report:"
    print test_class.ExpectedVersionReport()
    print ""


