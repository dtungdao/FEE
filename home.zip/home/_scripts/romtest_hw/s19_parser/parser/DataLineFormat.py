
class DataLineFormat():
	def __init__(self, line_addr, line_data, line_cs):
		self.line_addr = line_addr
		self.line_data = line_data
		self.line_cs = line_cs