
class DataBlockFormat():
	def __init__(self, block_start_addr, block_end_addr, block_data):
		self.block_start_addr = block_start_addr
		self.block_end_addr = block_end_addr
		self.block_data = block_data