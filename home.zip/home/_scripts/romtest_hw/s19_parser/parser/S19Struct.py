
class S19Struct():
	header = None
	data_lines = [] # DataLineFormat()
	data_blocks = [] # DataBlockFormat()
	data_rec_cnt = None
	exe_start_addr = None