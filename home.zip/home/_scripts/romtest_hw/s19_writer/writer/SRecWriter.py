import os, sys

sys.path.append(r"D:\0_TungDao\task\romtest_new\s19_parser\parser")
from SRecParser import *


class S19Writer():
	def __init__(self, s19_file_name, parser):
		# write to file
		self.s19_file = open(s19_file_name, "wt")
		self.parser = parser

		# Write S0 record
		self.WriteS0Record(self.parser.getS19Header(), self.s19_file)
		# write S3 records
		for block in self.parser.getS19DataBlocks():	
			self.WriteS3Record(block, self.s19_file)
		# Write S5 record
		self.WriteS5Record(self.parser.getS19LineCount(), self.s19_file)
		# Write S7 record
		self.WriteS7Record(self.parser.getS19ExeStartAddress(), self.s19_file)

		self.s19_file.close()

	def WriteS0Record(self, header, s19_file):
		if(header != None):
			line = "S0"
			line += "%02X0000" % ((len(header.encode("hex")) / 2) + 2 + 1)
			line += "%s" % header.encode("hex")
			line += "%02X" % (0xFF ^ (sum([int(num, 16) for num in re.findall('..', line[2:])]) & 0xFF))
			s19_file.write(line + "\n")
		
	def WriteS3Record(self, block, s19_file):
		addr = block.block_start_addr
		
		for arr in [block.block_data[idx : idx + 28] for idx in range(0, len(block.block_data), 28)]:
			line = "S3"
			line += "%02X" % (len(arr) + 4 + 1)
			line += "%08X" % addr
			for byte in arr: line += "%02X" % byte
			line += "%02X" % (0xFF ^ (sum([int(num, 16) for num in re.findall('..', line[2:])]) & 0xFF))
			s19_file.write(line + "\n")
			addr += len(arr)

	def WriteS5Record(self, cnt, s19_file):
		if(cnt != None):
			line = "S505"
			line += "%08X" % cnt
			line += "%02X" % (0xFF ^ (sum([int(num, 16) for num in re.findall('..', line[2:])]) & 0xFF))
			s19_file.write(line + "\n")
		
	def WriteS7Record(self, addr, s19_file):
		if(addr != None):
			line = "S705"
			line += "%08X" % addr
			line += "%02X" % (0xFF ^ (sum([int(num, 16) for num in re.findall('..', line[2:])]) & 0xFF))
			s19_file.write(line + "\n")