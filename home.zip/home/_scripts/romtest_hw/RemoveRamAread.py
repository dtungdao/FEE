import sys

if __name__ == '__main__':

	#0x40000000 is the start address of system RAM
	RAM_START_ADDR = 0x40000000

	#check command line arguments
	if len(sys.argv) < 2:
		print("Missing argument!\nUsage: RemoveRamArea.py <path_to_s19>")
		sys.exit()
		
	file_text = open(sys.argv[1], "rt+").read()
	for line in file_text.split("\n"):
		if (line[0:2] == "S3") and (int(line[4:12], 16) >= RAM_START_ADDR):
			print("\"%s\" has been removed" % (line))
			file_text = file_text.replace(line + "\n", "")
			
	#create new file with RAM area removed
	with open(sys.argv[1][:-4] + ".s19", "wt") as file:
		file.write(file_text)