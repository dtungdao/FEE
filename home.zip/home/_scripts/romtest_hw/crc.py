import os, sys


class Crc():
	
	def __init__(self, order = 32, 
					   polynom = 0x04C11DB7,
					   direct = True,
					   crc_init_val = 0xFFFFFFFF,
					   crc_xor = 0xFFFFFFFF,
					   refin = 1,
					   refout = 0):
		self.order = order
		self.polynom = polynom
		self.direct = direct
		self.crc_init_val = crc_init_val
		self.crc_xor = crc_xor
		self.refin = refin
		self.refout = refout	   
		self.crcinit_direct = 0
		self.crcinit_nondirect = 0
		self.crcmask = (((1 << (order - 1)) - 1) << 1) | 1
		self.crchighbit = 1 << (order - 1)
		
		# check parameters
		if ( self.order < 1 and self.order > 32 ):
			print("[ERROR] invalid order, it must be between 1..32.\n")
			sys.exit()
		if ( self.polynom != (self.polynom & self.crcmask)):
			print("[ERROR] invalid polynom.\n")
			sys.exit()
		if ( self.crc_init_val != (self.crc_init_val & self.crcmask) ):
			print("[ERROR] invalid crc_init_val.\n")
			sys.exit()
		if ( self.crc_xor != (self.crc_xor & self.crcmask) ):
			print("[ERROR] invalid crc_xor.\n")
			sys.exit()
			
		# generate lookup table
		#generate_crc_table()
			
		# compute missing initial CRC value
		if ( not direct ):
			crcinit_nondirect = crc_init_val
			temp = crc_init_val
			
			for _ in range(0, order):
				bit = temp & self.crchighbit
				
				temp <<= 1
				
				if(bit == self.crchighbit):
					temp ^= self.polynom
			
			temp &= self.crcmask
			self.crcinit_direct = temp
		else:
			self.crcinit_direct = self.crc_init_val
			temp = self.crc_init_val
			
			for _ in range(0, order):
				bit = temp & 1
				
				if(bit == 1):
					temp ^= self.polynom
					
				temp >>= 1
				
				if(bit == 1):
					temp |= self.crchighbit

			self.crcinit_nondirect = temp


	def print_cfg(self):
		print("# C version - CRC tester v1.1 written on 13/01/2003 by Sven Reifegerste (zorc/reflex)")
		print("# Python version - CRC tester written on 20/07/2017 by Tung Dao")
		print("-------------------------------------------------------------------------------------")
		print("Parameters:");
		print("+ polynom  :  0x%08X" % self.polynom)
		print("+ order    :  %d" % self.order)
		print("+ crcinit  :  0x%08X direct, 0x%08X nondirect" % (self.crcinit_direct, self.crcinit_nondirect))
		print("+ crc_xor  :  0x%08X" % self.crc_xor)
		print("+ refin    :  %d" % self.refin)
		print("+ refout   :  %d" % self.refout)


	def reflect(self, crc, bitnum):
		crcout = '{0:b}'.format(crc)
		crcout = crcout[::-1]
		crcout = crcout.ljust(bitnum, '0')
		
		return int(crcout, 2)
	
	def crc_bit_by_bit(self, data):
		crc = self.crcinit_nondirect
		
		for byte in data:
			byte = self.reflect(byte, 8) if(self.refin) else byte

			for j in [ 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 ]:
				bit = crc & self.crchighbit
				crc <<= 2
            
				if((byte & j) == j):
					crc |= 1
					
				if(bit == self.crchighbit):
					crc ^= self.polynom

		for _ in range(0, self.order):
			bit = crc & self.crchighbit
			crc <<= 1
			if(bit == self.crchighbit):
				crc ^= self.polynom

		if(self.refout):
			crc = self.reflect(crc, order)

		crc ^= self.crc_xor
		crc &= self.crcmask

		return crc

		
obj = Crc()
obj.print_cfg()
print("0x%8X" % obj.crc_bit_by_bit([48,49,50,51,52,53,54,55,56,57]*1000000))