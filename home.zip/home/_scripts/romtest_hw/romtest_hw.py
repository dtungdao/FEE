import os, sys
import re

BCMF_BUILD_OUTPUT = os.environ['BCMF_BUILD_OUTPUT']
BCMF_SCRIPTS_ROOT = os.environ['BCMF_SCRIPTS_ROOT'] + r"\romtest_hw"

sys.path.append(r"%s\s19_parser\parser" % (BCMF_SCRIPTS_ROOT))
from SRecParser import *
sys.path.append(r"%s\s19_writer\writer" % (BCMF_SCRIPTS_ROOT))
from SRecWriter import *


parser = S19Parser(s19_file_name=sys.argv[1],
				   isCalCs=False)
print("Number of data block : %d" % len(parser.getS19DataBlocks()))

block0 = parser.getS19DataBlocks()[0]
#block1 = parser.getS19DataBlocks()[1]

# overwrite the last byte for checksum
block0.block_data = block0.block_data[:-4] 

temp_file_name = "%s\%s_temp.bin" % (BCMF_SCRIPTS_ROOT, sys.argv[1].split("\\")[-1][:-11])
with open(temp_file_name, "wb") as temp_bin_file:
	print("len of block0.block_data = %d - 0x%X" % (len(block0.block_data), len(block0.block_data)))
	for data in block0.block_data:
		temp_bin_file.write(chr(data))

# calculate ROMTest checksum		
crc_result_str = os.popen(r"%s\crc.exe %s" % (BCMF_SCRIPTS_ROOT, temp_file_name)).read()
crc_result_str = crc_result_str.strip().split(" = ")[-1]
crc_result = int(crc_result_str[2:], 16)
print("CRC of %s = 0x%08X" % (sys.argv[1].split("\\")[-1][:-11], crc_result))

# append to the end of the last block
for byte in [int(num, 16) for num in re.findall('..', "%08X" % (crc_result))]:
	block0.block_data.append(byte)

S19Writer(r"%s/%s.s19" % (BCMF_BUILD_OUTPUT, sys.argv[1].split("\\")[-1][:-11]), parser)

# remove the dummy file
#os.system("del %s/_temp.bin" % (BCMF_SCRIPTS_ROOT))