# moduleResources.py - Class for checking all module resources
#  from within a project then reporting it.
#
# G. Robinson (AE-BE/ENG5)
# 15-02-2008
#
# Revision history:
#
# Version 001.00 - 15.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
# Version 002.00 - 26.02.2008 - G. Robinson (AE-BE/ENG5)
#   Usage of config file class rather than local config reader.
# Version 003.00 - 18.11.2009 - S.Weber (AE-BE/ENG31)
#   Added handling of libraries
#   Added commas as seperators to the output, this will result
#   in a neater output in Excel
# Version 002.01 - 24.11.2009 - C. Baudry (AE-BE/EKE)
#   The computer name is used to find the CSV separation symbol: "," or ";"
# Version 002.02 - 27.11.2009 - S. Weber (AE-BE/ENG31-AU)
#   - Fix for AU: no dash in computer name
#   - added support for common section in libraries
#   - fix for library list: last item was not considered, had to be added required for copy function '''

''' required for directory listings and executing etc '''
import os

''' required for copy function '''
import shutil

''' required for data and time '''
import time

''' required for system arguments '''
import sys

''' required for resource containers '''
from resourceContainer import ResourceContainer

''' import the configuration file handler '''
from configFile import ConfigFile

''' config file definitions '''
CFG_PROJECT_NAME             = "PROJECT_NAME"
CFG_GREENHILLS_GSIZE_PATH    = "GREENHILLS_GSIZE_PATH"
CFG_GREENHILLS_GSIZE_EXE     = "GREENHILLS_GSIZE_EXE"
CFG_GREENHILLS_GSIZE_OPTIONS = "GREENHILLS_GSIZE_OPTIONS"
CFG_RESOURCE_OUTPUT_PATH     = "RESOURCE_OUTPUT_PATH"

CFG_SEGMENT_ROM              = "ROM"
CFG_SEGMENT_RAM              = "RAM"
CFG_SEGMENT_STACK            = "STACK"
CFG_SEGMENT_IGNORE           = "IGNORE"

CFG_OBJECT_FILE_PATH         = "OBJECT_FILE_PATH"
CFG_SCRIPT_OUTPUT_PATH       = "SCRIPT_OUTPUT_PATH"

CFG_ADDITIONAL_LIBRARIES     = "ADDITIONAL_LIBRARIES"
CFG_MAP_FILE                 = "MAP_FILE"

''' file extention for processed temp files '''
PROCESSED_FILE_EXT = ".size.txt"

''' Class for the complete projects resources '''
class ProjectResources:

    def __init__(self, configuration_file):
        self.element = []
        self.summary_segments = {}

        ''' load the configuration and segment dictionaries '''
        configuration_class = ConfigFile(configuration_file)

        self.configuration   = configuration_class.ConfigDictionary()
        self.segment_details = configuration_class.SegmentDictionary()

    # Add a new module to the project
    def AddModule(self, module_string, module_name):

        ''' work out new array index to store module '''
        item_populated = len(self.element)

        ''' append the new module '''
        self.element.append(ResourceContainer())

        ''' populate the module '''
        self.element[item_populated].Populate(module_string, module_name)

    def ProcessObjectFiles(self):

        ''' get a listing of the output directory '''
        directory_listing = os.listdir(self.configuration[CFG_OBJECT_FILE_PATH])

        ''' get the additional libraries out of the configuration item
            this should be in the format [<path\libname>,<path\libname>],
            so we parse through and add the different paths to a list'''
        add_libs = self.configuration[CFG_ADDITIONAL_LIBRARIES]

        lib_listing = []

        if add_libs != "[]":
            for lib in add_libs:
                if lib == "[":
                    librarypath = ""
                else:
                    if lib == ",":
                        '''finished one item, add it to the list'''
                        directory_listing.append(librarypath)
                        librarypath = ""
                    else:
                        if lib == "]":
                            directory_listing.append(librarypath)
                            '''make sure it ends here'''
                            break
                        else:
                            librarypath = librarypath + lib

        ''' sort it into order '''
        directory_listing.sort()

        ''' print some status '''
        print ""
        print "Extracting Resource Consumption Information..."
        print "To Process: [ " + '. ' * len(directory_listing) + "]"
        print "Processing: [",

        ''' deal with all the useful files *.o and *.a  '''
        for file_name in directory_listing:

            print '.',

            split_file_name = os.path.splitext(file_name)

            ''' file is a straightforward object file '''
            if(split_file_name[1] == ".o"):

                ''' work out file string '''
                file_string = "\"" + self.configuration[CFG_OBJECT_FILE_PATH] + "\\" + file_name + "\""

                ''' work out the command string '''
                command_string = self.configuration[CFG_GREENHILLS_GSIZE_PATH] + "\\" + self.configuration[CFG_GREENHILLS_GSIZE_EXE] + " " + self.configuration[CFG_GREENHILLS_GSIZE_OPTIONS]

                ''' work out the output string '''
                output_string = "> \"" + self.configuration[CFG_SCRIPT_OUTPUT_PATH] + "\\" + split_file_name[0] + PROCESSED_FILE_EXT + "\""

                ''' work out the command line '''
                command = command_string + " " + file_string + " " + output_string

                ''' execute the command '''
                os.system(command)

                ''' work out the datafile '''
                data = self.configuration[CFG_SCRIPT_OUTPUT_PATH] + "\\" + split_file_name[0] + PROCESSED_FILE_EXT

                ''' open the data file for processing and get all the info'''
                data_file = open(data)
                file_data = data_file.read()

                ''' close the data file down '''
                data_file.close()

                ''' add the module to the database '''
                self.AddModule(file_data, split_file_name[0])

            ''' file is a library
                as these are already added with their respective paths, they have to be
                handled differently. Also only parts of the library will be linked as not
                everything is used in there. So we have to extract what parts of the library we are
                using from the map file '''
            if(split_file_name[1] == ".a"):

                '''libray files come with their path so we have to extract that first
                   we can't just use the environment variable for the compiler libraries,
                   because there might more (e.g. OS libraries)'''
                ''' work out file string, this is easy cause the path is already there '''
                file_string = file_name

                '''find the last backslash to fiure out where te filename starts '''
                index = file_name.rfind("\\")

                '''now just delete everything but the filename'''
                file_name = file_name[index+1:]

                '''do the same for the split file name'''
                split_file_name = os.path.splitext(file_name)

                ''' work out the command string '''
                command_string = self.configuration[CFG_GREENHILLS_GSIZE_PATH] + "\\" + self.configuration[CFG_GREENHILLS_GSIZE_EXE] + " " + self.configuration[CFG_GREENHILLS_GSIZE_OPTIONS]

                ''' work out the output string '''
                output_string = "> \"" + self.configuration[CFG_SCRIPT_OUTPUT_PATH] + "\\" + split_file_name[0] + PROCESSED_FILE_EXT + "\""

                ''' work out the command line '''
                command = command_string + " " + file_string + " " + output_string

                ''' execute the command '''
                os.system(command)

                ''' work out the datafile '''
                data = self.configuration[CFG_SCRIPT_OUTPUT_PATH] + "\\" + split_file_name[0] + PROCESSED_FILE_EXT

                ''' open the data file for processing and get all the info'''
                data_file = open(data)
                file_data = ""
                file_lines = data_file.readlines()

                ''' open the mapfile '''
                mapfile_string = self.configuration[CFG_OBJECT_FILE_PATH] + "\\" + self.configuration[CFG_MAP_FILE]
                map_file = open(mapfile_string)
                map_content = map_file.read()

                '''this variable is to flag whether lines should be included into the
                   size file or not
                   Whenever lines refer to an object file that is included in the map file
                   this is set to True, otherwise to False
                   Because there are libraries with only one object this has to be
                   initialised with True!'''
                include_object = True
                section_part = True

                '''For libraries remove everything that has not been included in the map file -
                   otherwise the memory usage is calculated too high'''
                for line in file_lines:
                    if section_part == True:
                        '''this is the end of the the section part, either starting with
                           the section totals for all objects or with Common symbol
                           if there are no more than one objects'''
                        if line[:15] == "Section Totals:":
                            section_part = False
                            include_object = False

                        if line[:13] == "Common symbol":
                            section_part = False
                            include_object = False

                        '''check for pathname of object in this lib
                           go back from the end and find the .o ending'''
                        if line[-5:-3] == ".o":
                            '''find the object in the map file'''
                            ''' extract the file name '''
                            index = line.rfind("(")
                            obj_name = line[index+1:-3]
                            '''now check if the object appears anywhere in the mapfile'''
                            if (map_content.find(obj_name) != -1):
                                '''object name is in map file, so add this line and all the following until the next object path'''
                                include_object = True
                            else:
                                include_object = False

                        if include_object == True:
                            file_data = file_data + line
                    else:
                        '''we've reached the part with the global variables'''
                        '''check for both texts here, because they seem to be compiler dependant'''
                        if (line[:7] == "Symbol:") or (line[:12] == "Data symbol:"):
                            '''save line'''
                            last_line = line
                        else:
                            if line[1:6] == "file:":
                                ''' extract the file name '''
                                index = line.rfind(".o")
                                if index != -1:
                                    '''object file found'''
                                    obj_name = line[7:index+2]
                                    '''now check if the object appears anywhere in the mapfile'''
                                    if (map_content.find(obj_name) != -1):
                                        '''object name is in map file, so add this line and the one before '''
                                        file_data = file_data + last_line + line
                                else:
                                    '''no object file found, so this library is included completely '''
                                    file_data = file_data + last_line + line

                ''' close the data file down '''
                data_file.close()

                ''' add the module to the database '''
                self.AddModule(file_data, split_file_name[0])

        print "]"

        ''' summarise the segments locally in this object '''
        for module in self.element:
            for element in module.Elements():

                if(element in self.summary_segments):
                    self.summary_segments[element] += int(module.Elements()[element])

                else:
                    self.summary_segments[element] = int(module.Elements()[element])

    # Print the modules to the screen
    def ReportString(self):

        report_string = ""

        for module in self.element:
            report_string += module.ReportString()

        return report_string

    # Print all the global data to the screen
    def GlobalData(self):

        global_data = "GLOBAL DATA: \n\n"
        total = 0

        for module in self.element:
            for cmm_data_element in module.CommonData():
                global_data += "(" + module.Name() + ") " + cmm_data_element + self.CSVseparation + str(module.CommonData()[cmm_data_element]) + self.CSVseparation + " bytes" '\n'

                total += module.CommonData()[cmm_data_element]

        global_data = global_data + '\n'

        global_data = global_data + "TOTAL: " + str(total) + " bytes"

        return global_data

    # Print a summary of all the segments
    def SegmentsSummary(self):

        segments_summary = "SEGMENTS SUMMARY: \n\n"

        for segment in self.summary_segments:

            segments_summary += segment + self.CSVseparation + str(self.summary_segments[segment]) + self.CSVseparation + " bytes \n"

        return segments_summary

    # Summarise the resources
    def ResourceSummary(self):

        segment_types = {CFG_SEGMENT_ROM:0,
                         CFG_SEGMENT_RAM:0,
                         CFG_SEGMENT_STACK:0,
                         CFG_SEGMENT_IGNORE:0}

        not_found = 0
        not_found_names = []

        resource_summary = "RESOURCE SUMMARY: \n\n"

        for segment in self.summary_segments:

            ''' first check if the segment exists '''
            if(segment in self.segment_details):

                segment_types[self.segment_details[segment]] += self.summary_segments[segment]

            else:
                not_found += self.summary_segments[segment]
                not_found_names.append(segment)

        for component in segment_types:

            resource_summary += "Total " + component + ": " + self.CSVseparation + str(segment_types[component]) + self.CSVseparation + " bytes\n"

        if(not_found_names):

            resource_summary += "\n"
            resource_summary += "!!! Warning the following items are not allocated. Update .cfg !!!\n"
            resource_summary += "Total UNALLOCATED: " + str(not_found) + " bytes\n"
            resource_summary += "Segment Names: " + "\n"

            for element in not_found_names:
                resource_summary += element + "\n"

        resource_summary += "\n"

        ''' summarise the individual modules '''
        for module in self.element:

            resource_summary += module.Name() + self.CSVseparation

            segment_types = {CFG_SEGMENT_ROM:0,
                             CFG_SEGMENT_RAM:0,
                             CFG_SEGMENT_STACK:0,
                             CFG_SEGMENT_IGNORE:0}

            not_found = 0

            for module_data_element in module.Elements():

                ''' check if the segment is known '''
                if(module_data_element in self.segment_details):

                    segment_types[self.segment_details[module_data_element]] += module.Elements()[module_data_element]

                else:
                    not_found += module.Elements()[module_data_element]

            for summary in segment_types:

                resource_summary += summary + self.CSVseparation + str(segment_types[summary]) + self.CSVseparation + " bytes" + self.CSVseparation

            resource_summary += "|UNKNOWN|" + self.CSVseparation + str(not_found) + self.CSVseparation + " bytes"
            resource_summary += "\n"

        return resource_summary

    def GenerateExportCSVs(self):

        current_time = time.localtime()

        year = str(current_time[0])

        ''' Get the computer locality: will be used to print the CSV results according to the Excel version'''
        computerName = os.getenv('COMPUTERNAME')
        locality = computerName[:2]

        if(locality == "LR"):
            self.CSVseparation = ";"

        else:
            if(locality == "CL"):
                self.CSVseparation = ","

            else:
                if(locality == "BP"):
                    self.CSVseparation = ","
                else:
                    self.CSVseparation = " "

        ''' work the date into a usable format. there is a better way to do this '''
        if(len(str(current_time[1])) == 1):
            month = "0" + str(current_time[1])

        else:
            month = str(current_time[1])

        if (len(str(current_time[2])) == 1):
            day = "0" + str(current_time[2])

        else:
            day = str(current_time[2])

        if(len(str(current_time[3])) == 1):
            hour = "0" + str(current_time[3])

        else:
            hour = str(current_time[3])

        if (len(str(current_time[4])) == 1):
            minute = "0" + str(current_time[4])

        else:
            minute = str(current_time[4])

        if (len(str(current_time[5])) == 1):
            second = "0" + str(current_time[5])

        else:
            second = str(current_time[5])

        time_string = year + "-" + month + "-" + day + " " + hour + "." + minute + "." + second

        file_name = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + time_string + " " + self.configuration[CFG_PROJECT_NAME] + " Resource Summary.csv"
        output_file = open(file_name, 'w')
        print >> output_file, time_string + "\n\n" + self.ResourceSummary()
        output_file.close()

        file_name = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + time_string + " " + self.configuration[CFG_PROJECT_NAME] + " Segment Summary.csv"
        output_file = open(file_name, 'w')
        print >> output_file, time_string + "\n\n" + self.SegmentsSummary()
        output_file.close()

        file_name = self.configuration[CFG_RESOURCE_OUTPUT_PATH] + "\\" + time_string + " " + self.configuration[CFG_PROJECT_NAME] + " Globals Summary.csv"
        output_file = open(file_name, 'w')
        print >> output_file, time_string + "\n\n" + self.GlobalData()
        output_file.close()

if __name__ == '__main__':

    actualProject = ProjectResources(sys.argv[1])

    actualProject.ProcessObjectFiles()

    actualProject.GenerateExportCSVs()
