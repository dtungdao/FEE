# resourceContainer.py - Class containing and searching an individual
#  modules resources.
#
# G. Robinson (AE-BE/ENG5)
# 15-02-2008
#
# Revision history:
#
# Version 001.00 - 15.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
#

''' required for system arguments '''
import sys
import os


''' Definition for common segment label '''
COMMON_SEGMENT = "common"

# Class for module resource consumption
class mapExtract:

    # Constructor
    def __init__(self, temp_dir):

        self.bss_size = 0
        self.data_size = 0
        self.rodata_size = 0
        self.vletext_size = 0

        modules_index = 0
        end_index = 0
        
        self.fileList = os.listdir(temp_dir)
        self.sectionList = [".rb_AnalogueInput", 
                            ".rb_EOLData2",
                            ".rb_DebouncedInput",
                            ".rb_EOLData1",
                            ".rbSchedulerALL",
                            ".data",
                            ".bss",
                            ".heap",
                            ".stack",
                            ".rodata",
                            ".isrvectbl",
                            ".isrvecivr",
                            ".text",
                            ".DFALib_Text",
                            ".apl_vect",
                            ".ROMcheckHdr",
                            ".EEELib_Text",
                            ".DFALib_TextRam",
                            ".ecuInfo",
                            ".last_instr"]

        self.text_size = 0
        self.text_file = 0

        for file in self.fileList:
            filepath = str(temp_dir) + "\\" + str(file)
            index = str(file).find(".size.txt")
            print str(file)[:index]
            try:

                file_name = open(filepath, 'r')
            except:
                print "One or more files could not be opened.\nPlease check paths."

            else:
                file_list = file_name.readlines()
                file_name.close()

                for section in self.sectionList: 
                    self.data_size = 0
                    for line in file_list:
                        if section in line:
                            index = line.find("0x")
                            data = line[index:(index+6)]
                            data_dec = int(data, 16)
                            if section == ".text":
                                self.text_size = self.text_size + data_dec
                                self.text_file = data_dec

            print ".text:" + str(self.text_file) + "\n"

        print str(self.text_size)
    



# -------------------------------------------------------------------------
# MAIN program.
# -------------------------------------------------------------------------

if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        main = mapExtract(sys.argv[1])


    except IndexError:

        error_message = "Usage: python mapExtract.py map_file"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise

