# resourceContainer.py - Class containing and searching an individual
#  modules resources.
#
# G. Robinson (AE-BE/ENG5)
# 15-02-2008
#
# Revision history:
#
# Version 001.00 - 15.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
# Version 002.00 - 18.11.2009 - S.Weber (AE-BE/ENG31)
#   Added another check to differentiate between sections with a
#   "." and relative paths
# Version 002.01 - 27.11.2009 - S.Weber (AE-BE/ENG31)
#   changed the check so it looks for hex values instead of '.'
#   cause there can be sections without them
#

''' re - for regular expressions '''
import re

''' test string for validating class '''
test_string = '''\
        .text          178 0x00b2
    .data            0 000000
    .bss             0 000000
    .debug_info    1760 0x06e0
    .debug_abbrev     350 0x015e
    .debug_line      1869 0x074d
    .debug_macinfo    8335 0x208f
    .debug_frame       408 0x0198
    .rela.text         156 0x009c
    .rela.debug_info    1236 0x04d4
    .rela.debug_line     180 0x00b4
    .rela.debug_frame     948 0x03b4
    .symtab               528 0x0210
    .strtab              1223 0x04c7
    .ghsinfo               72 0x0048
    Total:              17243 0x435b

Common symbol information:
Data symbol: _testSignal, size: 1 bytes, BSS space
    file: RbNetcomCan.o, size: 1, common
Data symbol: _testNmState, size: 1 bytes, BSS space
    file: RbNetcomCan.o, size: 1, common
Data symbol: _testSignalreallybig, size: 51 bytes, BSS space
    file: RbNetcomCan.o, size: 1, common
'''

''' Definition for common segment label '''
COMMON_SEGMENT = "common"

# Class for module resource consumption
class ResourceContainer:

    # Constructor
    def __init__(self):
        self.name = None
        self.element = {}
        self.cmmdata = {}

    # Return report structure
    def ReportString(self):
        report_string = '-'*79 + '\n'
        report_string += "Module Name: " + self.name + '\n'
        report_string += "Segments:    " + str(len(self.element)) + '\n'
        report_string += '\n'
        report_string += "Common Data (global):" + '\n'

        data_counter = 1
        max_string_length = 0

        ''' find the biggest string for visual formatting '''
        for item in self.cmmdata:
            if((len(item) + len(str(data_counter))) > max_string_length):
                max_string_length = len(item)+ len(str(data_counter))

            data_counter += 1

        data_counter = 1

        for item in self.cmmdata:

            buffer_spaces = max_string_length - (len(item) + len(str(data_counter)))

            report_string += str(data_counter) + ". " + item + (' ' * buffer_spaces) + " - " + str(self.cmmdata[item]) + " bytes" '\n'

            data_counter += 1

        report_string += '\n'
        report_string += "Memory Segments" + '\n'

        data_counter = 1
        max_string_length = 0

        ''' find the biggest string for visual formatting '''
        for item in self.element:
            if((len(item) + len(str(data_counter))) > max_string_length):
                max_string_length = len(item)+ len(str(data_counter))

            data_counter += 1

        data_counter = 1

        for item in self.element:

            buffer_spaces = max_string_length - (len(item) + len(str(data_counter)))

            report_string += str(data_counter) + ". " + item + (' ' * buffer_spaces) + " - " + str(self.element[item]) + " bytes" '\n'

            data_counter += 1

        report_string += '\n' + '-'*79 + '\n'*2

        return report_string

    # Return elements
    def Elements(self):
        return self.element

    # Return common data
    def CommonData(self):
        return self.cmmdata

    # Return name
    def Name(self):
        return self.name

    # Populate the modules resource consumption
    def Populate(self, record, name):

        self.name = name

        elements_finished = False

        ''' split the record into usefull data segments '''
        record = record.split()

        ''' add the segments to the local dictionary '''
        for item in range(len(record)):

            strlen = len(record[item])
            ''' check for hex values '''
            if(strlen > 3):
                '''all other letters have to be numbers other than the x'''
                if ((record[item][1] == 'x') and (re.search("[0-9x]", record[item])) and (elements_finished != True)):
                    '''check that its not the total sum of sections'''
                    if record[item-2] != "Total:":
                        ''' check that the segment doesn't alread exist '''
                        if(record[item-2] in self.element):
                            self.element[record[item-2]] += int(record[item-1])
                        else:
                            self.element[record[item-2]] = int(record[item-1])

            ''' check for global data segments '''
            if(record[item].lower() == 'symbol:'):

                elements_finished = True

                ''' check that the common segment doesn't alread exist '''
                if(COMMON_SEGMENT in self.element):
                    self.element[COMMON_SEGMENT] += int(record[item+3])
                    self.cmmdata[record[item+1][:-1]] = int(record[item+3])

                else:
                    self.element[COMMON_SEGMENT] = int(record[item+3])
                    self.cmmdata[record[item+1][:-1]] = int(record[item+3])

if __name__ == '__main__':

    resourceContainerTest = ResourceContainer()

    resourceContainerTest.Populate(test_string, "Test Module A")

    #print resourceContainerTest.Name()
    #print resourceContainerTest.CommonData()
    #print resourceContainerTest.Elements()

    print '\n'
    print resourceContainerTest.ReportString()



# Earlier search method using regular expressions

#''' get the name between the . and the space '''
#matched_name = re.search('[\.][0-9a-zA-Z_]+[ ]', record)

#''' check if a segment was found '''
#if matched_name <> None:

#''' match found '''
#''' get the size between the first and last space that is a int '''
#matched_size = re.search('[ ][0-9]+[ ]', record)

#''' check to see the size was found '''
#if matched_size <> None:

#''' match found '''
#''' add to the dictionary '''
#self.element[str(matched_name.group())] = int(str(matched_size.group()))

#elements_found = elements_found + 1
