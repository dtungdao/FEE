# resourceContainer.py - Class containing and searching an individual
#  modules resources.
#
# G. Robinson (AE-BE/ENG5)
# 15-02-2008
#
# Revision history:
#
# Version 001.00 - 15.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
#

''' required for system arguments '''
import sys


''' Definition for common segment label '''
COMMON_SEGMENT = "common"

# Class for module resource consumption
class mapExtract:

    # Constructor
    def __init__(self, map_file):

        self.bss_size = 0
        self.data_size = 0
        self.rodata_size = 0
        self.vletext_size = 0

        modules_index = 0
        end_index = 0
        
        self.sectionList = [".rb_AnalogueInput", 
                            ".rb_EOLData2",
                            ".rb_DebouncedInput",
                            ".rb_EOLData1",
                            ".rbSchedulerALL",
                            ".data",
                            ".bss",
                            ".heap",
                            ".stack",
                            ".rodata",
                            ".isrvectbl",
                            ".isrvecivr",
                            ".text",
                            ".DFALib_Text",
                            ".apl_vect",
                            ".ROMcheckHdr",
                            ".EEELib_Text",
                            ".DFALib_TextRam",
                            ".ecuInfo",
                            ".last_instr"]

        try:

            map_name = open(map_file, 'r')
        except:
            print "One or more files could not be opened.\nPlease check paths."

        else:
            map_list = map_name.readlines()
            map_name.close()

            for line in map_list:
                if 'Module Summary' in line:
                    modules_index = map_list.index(line) + 1
                    #print line + str(modules_index)
                if 'Global Symbols' in line:
                    end_index = map_list.index(line) - 1
                    #print line + str(end_index)

            for section in self.sectionList: 
                self.data_size = 0
                for line in map_list[modules_index:end_index]:
                    if section in line:
                        data = line[9:15]
                        data_dec = int(data, 16)
                        self.data_size = self.data_size + data_dec
                        if section == ".text":
                            index = line.find(".o")
                            print line[34:index]
                            print ".text:" + str(data_dec) + "\n"

                print section + ":    " + str(self.data_size)
    



# -------------------------------------------------------------------------
# MAIN program.
# -------------------------------------------------------------------------

if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        main = mapExtract(sys.argv[1])


    except IndexError:

        error_message = "Usage: python mapExtract.py map_file"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise

