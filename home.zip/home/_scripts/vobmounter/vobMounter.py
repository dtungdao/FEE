# vobMounter.py - Class for making sure all the right VOB's are mounter.
#
# G. Robinson (AE-BE/ENG5)
# 27-02-2008
#
# Revision history:
#
# Version 001.00 - 27.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision.
#

''' required for system arguments '''
import sys

''' required for executing commands '''
import subprocess

''' import the configuration file handler '''
from configFile import ConfigFile

''' definition for configuration option '''
VOB_DEFINITION = "VOB"


# Class for mounting VOBs
class VobMounter:

    # Initialise a configuration dictionary
    def __init__(self, configuration_file):

        ''' prepair dictionaries '''
        self.segment_details = ConfigFile(configuration_file).SegmentDictionary()

        ''' extract vob's '''
        for VOB in self.segment_details:

            command_string = "cleartool mount \\" + VOB
            print "Executing: " + command_string
            subprocess.call(command_string)
                   
    # Return the segment dictionary
    def SegmentDictionary(self):
        
        return self.segment_details

if __name__ == '__main__':

    ''' set up a command line instance of the class for test pruposes
        and print out its dictionaries. '''
    try:
        test_configuration = VobMounter(sys.argv[1])

        #print "\nSegment Dictionary:"
        #print test_configuration.SegmentDictionary()

    except IndexError:

        error_message = "Usage: python vobMounter.py configuration_file.cfg"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
