#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>


#define RB_CFG_ROMTEST_BOOTSTARTADDR	0x00F8C000
#define RB_CFG_ROMTEST_BOOTENDADDR	0x00FA7FFF
#define RB_CFG_ROMTEST_APPLSTARTADDR	0x00FD8000
#define RB_CFG_ROMTEST_APPLENDADDR	0x0127FFFF
#define CRC_POLYNOMIAL_32_REFLECT   	(0xEDB88320uL)
#define CRC_FINAL_XOR_CRC32         	(0xFFFFFFFFuL)


typedef struct {
	uint8_t *pHeader;
	uint8_t *pLen;
	uint8_t *pAddr;
	uint8_t *pData;
	uint8_t *pCk;
} S19Record;


uint32_t AUTOSAR_Crc32(uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint32_t Crc_StartValue);
uint32_t CalculateCRC(uint8_t *Crc_DataPtr, uint32_t Crc_Length);
uint8_t *getSubStr(uint8_t *string, uint32_t position, uint32_t length);
void freeS3RecordContent(S19Record *record);


int main(int argc, char* argv[]) {
	/*variables*/
	FILE *mFile;
	uint32_t ROMTEST_START_ADDR = 0;
	uint32_t ROMTEST_END_ADDR = 0;
	uint8_t *intBuf;
	S19Record S3Record;
	
	S3Record.pHeader = NULL;
	S3Record.pLen = NULL;
	S3Record.pAddr = NULL;
	S3Record.pData = NULL;
	S3Record.pCk = NULL;
	
	/*validation input parameter*/
	if(argc < 3) {
        printf("Missing argument!\nUsage: Crc32_Adding.exe <path_to_s19> <action>\n");
        return -1;
    }
	
	if(strcmp(argv[2], "0") == 0) { // flash boot loader
		ROMTEST_START_ADDR = RB_CFG_ROMTEST_BOOTSTARTADDR;
		ROMTEST_END_ADDR = RB_CFG_ROMTEST_BOOTENDADDR;
		printf("Boot loader file\n");
	} else { // application
		ROMTEST_START_ADDR = RB_CFG_ROMTEST_APPLSTARTADDR;
		ROMTEST_END_ADDR = RB_CFG_ROMTEST_APPLENDADDR;
		printf("Application file\n");
	}
	
	intBuf = (uint8_t *) malloc(ROMTEST_END_ADDR - ROMTEST_START_ADDR);
	if(intBuf == NULL) { printf("malloc error\n"); return; }

	/*read file as text*/
	mFile = fopen(argv[1], "rt+");
	if(mFile == NULL) {
		printf("fopen error\n");
        return -1;
	}
	
	/*read the data section*/
	uint8_t strIdx = 0;
	uint32_t intIdx = 0;
	uint32_t debug = 0;
	while(!feof(mFile)) {
		uint8_t line[71];
		fscanf(mFile, "%s", line);
		
		S3Record.pHeader = getSubStr(line, 0, 2); // get record header
		if(strcmp(S3Record.pHeader, "S3") == 0) { // S3 record type
			S3Record.pLen = getSubStr(line, 2, 2); // get record (addr+data+ck) len
			S3Record.pAddr = getSubStr(line, 4, 8); // get address
			if(ROMTEST_START_ADDR <= strtoul(S3Record.pAddr, NULL, 16) &&  
				ROMTEST_END_ADDR >= strtoul(S3Record.pAddr, NULL, 16) ) {
				uint8_t dataLen = (strtoul(S3Record.pLen, NULL, 16) - 1 - 4) * 2;
				S3Record.pData = getSubStr(line, 12, dataLen);
				
				for(strIdx = 0; strIdx < dataLen;) {
					uint8_t tmp[3] = {'\0'};
					tmp[0] = S3Record.pData[strIdx];
					tmp[1] = S3Record.pData[strIdx + 1];
					intBuf[intIdx] = strtoul(tmp, NULL, 16);
					strIdx += 2; intIdx++;
				}
				
				if((ROMTEST_END_ADDR - strtoul(S3Record.pAddr, NULL, 16)) <= 0x1C) {
				
					/*calculate the crc checksum*/
					uint32_t crc = 0; // store the crc checksum
					crc = CalculateCRC(intBuf, ROMTEST_END_ADDR - ROMTEST_START_ADDR - 4);
					printf("CRC32 = 0x%X\n", crc);
					printf("intIdx = %d\n", intIdx);
					
					/*calculate checksum of line*/
					uint8_t ck = 0; // store the checksum of line
					for(uint8_t i = 2; i <= (strtoul(S3Record.pLen, NULL, 16) - 4) * 2; i+=2) {
						uint8_t tmp[3] = {'\0'};
						tmp[0] = line[i];
						tmp[1] = line[i + 1];
						ck += strtoul(tmp, NULL, 16);
					}
					ck += (uint8_t) (crc >> 0); ck += (uint8_t) (crc >> 8);
					ck += (uint8_t) (crc >> 16); ck += (uint8_t) (crc >> 24);
					ck = ~ck;
					
					/*write new values*/
					fseek(mFile, -10, SEEK_CUR);
					fprintf(mFile, "%08X", crc);
					fprintf(mFile, "%02X", ck);
					
					// release resource
					freeS3RecordContent(&S3Record);
					break;
				}
			}
		}
		// release resource
		freeS3RecordContent(&S3Record);
	}
	
	/*release resource*/
	fclose(mFile);
	free(intBuf);
	
	/*exit the program without error*/
	return 1;
}


uint32_t AUTOSAR_Crc32( uint8_t *Crc_DataPtr, uint32_t Crc_Length, uint32_t Crc_StartValue) {
	//uint32_t CrcValue_u32 = 0xFFFFFFFF;
	uint32_t CrcValue_u32 = Crc_StartValue;

	while(Crc_Length--) {
		uint16_t i16; /* loop counter 1..8 */

		CrcValue_u32 ^= 0xFFuL & (uint32_t) (*Crc_DataPtr++);

		for (i16 = 0; i16 < 8; i16 ++) {
			if(CrcValue_u32 & 1) {
				CrcValue_u32 = (CrcValue_u32 >> 1) ^ CRC_POLYNOMIAL_32_REFLECT;
			} else {
				CrcValue_u32 = (CrcValue_u32 >> 1);
			}
		}
	}

	return CRC_FINAL_XOR_CRC32 ^ CrcValue_u32;
}

uint32_t CalculateCRC(uint8_t *Crc_DataPtr, uint32_t Crc_Length) {
	const uint32_t FLASH_DATA_LEN = 100;
	uint32_t ck = 0;
	uint32_t blockLen = FLASH_DATA_LEN;
	uint32_t offset = 0;
	
	do {
		ck = AUTOSAR_Crc32(Crc_DataPtr + offset, blockLen, ck);
		offset += blockLen * 4;
		blockLen = ((Crc_Length - offset) <= FLASH_DATA_LEN) ? ((Crc_Length - offset)) : (FLASH_DATA_LEN);
	} while(offset < Crc_Length);
	
	return ck;
}


uint8_t *getSubStr(uint8_t *string, uint32_t position, uint32_t length) {
	uint8_t *pointer;
	uint32_t c;

	pointer = malloc(length + 1);
		if (pointer == NULL) {
		return NULL;
	}

	for (c = 0 ; c < length ; c++) {
		*(pointer + c) = *(string + position);      
		string++;   
	}
	*(pointer + c) = '\0';

	return pointer;
}


void freeS3RecordContent(S19Record *record) {
	if(record->pHeader != NULL) { free(record->pHeader); 	record->pHeader = NULL; }
	if(record->pLen != NULL) 	{ free(record->pLen); 		record->pLen = NULL; }
	if(record->pAddr != NULL) 	{ free(record->pAddr); 		record->pAddr = NULL; }
	if(record->pData != NULL) 	{ free(record->pData); 		record->pData = NULL; }
	if(record->pCk != NULL) 	{ free(record->pCk); 		record->pCk = NULL; }
}