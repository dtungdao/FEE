import sys


str_in = sys.argv[2]

flag = False	
with open(sys.argv[1], "rt+") as file:
	lines = file.readlines()
	index = 0;
	for line in lines:
		if (line[0:2] == "S3") and ((0x0127FFE0 - int(line[4:12], 16)) <= 28):
			lines[index] = line[:20] + str_in + line[len(str_in) + 20:]
			flag = True
			break
		index += 1
print(flag)		
#create new file with RAM area removed
with open(sys.argv[1][:-4] + ".s19", "wt") as file:
	file.writelines(["%s" % line for line in lines])