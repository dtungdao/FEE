# buildGUI.py - Class and fucntionality for BCMF build GUI
#
# G. Robinson (AE-BE/ENG5)
# 18-02-2008
#
# Revision history:
#
# Version 001.00 - 18.02.2008 - G. Robinson (AE-BE/ENG5)
#   Initial revision. Includes config and segment reading aswell as exception
#   handling.
# Version 002.00 - 21.02.2008 - G. Robinson (AE-BE/ENG5)
#   Use library for config file reading.
#   Exception handling for not found configuration options.
#   Refreshing of status live.
#   Starting of multi.
#   Starting of eclipse.
# Version 003.00 - 25.02.2008 - G. Robinson (AE-BE/ENG5)
#   Moved inclusion of library paths to batch file via usage of PYTHONPATH. e.g.
#   set PYTHONPATH=%PYTHONPATH%;..\_scripts\buildgui
#   instead of locally setting the file with
#   sys.path.append(..\_scripts\buildgui) as it doesn't handle relative paths.
#   Added in tool version checking.
# Version 004.00 - 26.02.2008 - G. Robinson (AE-BE/ENG5)
#   Changed correct version labels from green to blue. Green didn't clearly
#   show that the version was ok (i.e. not obvious enough).
#   Stopped version box turning black when selected.
# Version 005.00 - 03.03.2008 - G. Robinson (AE-BE/ENG5)
#   Added functionality of automatically updating the version file before
#   compile.
#   Added common post and pre build functions.
# Version 006.00 - 10.03.2008 - G. Robinson (AE-BE/ENG5)
#   Added linkage to doxygen documentation.
# Version 007.00 - 12.03.2008 - G. Robinson (AE-BE/ENG5)
#   Added help support.
# Version 008.00 - 17.03.2008 - G. Robinson (AE-BE/ENG5)
#   Added windows help output for doxygen.
# Version 009.00 - 18.04.2008 - G. Robinson (AE-BE/ENG5)
#   Functionality added for compiling STARTUP and EOL ROM.
#   Added generation of HEX files.
# Version 010.00 - 25.04.2008 - G. Robinson (AE-BE/ENG5)
#   Added threads to prevent GUI locking up during compiling.
#   General tidy up of console data.
# Version 011.00 - 29.04.2008 - G. Robinson (AE-BE/ENG5)
#   Added software to register dll's for htmlhelp.
# Version 012.00 - 29.05.2008 - S. Weber (AE-BE/EBS4-AU)
#   Added qac analysis and eclipse project execution.
# Version 012.01 - 29.05.2008 - G. Robinson (AE-BE/ENG5)
#   Fixed QAC button objects to have unique names and handle
#   multithreading.
# Version 012.02 - 04.06.2008 - S. Weber (AE-BE/EBS4-AU)
#   Changed path for the configuration mak file
#   added output path as parameter to call of omake for QAC
# Version 013.00 - 15.07.2008 - G. Robinson (AE-BE/ENG3)
#   Addition of NVM generation tool link.
# Version 014.00 - 22.09.2008 - G. Robinson (AE-BE/ENG3)
#   Added view name support.
# Version 015.00 - 24.09.2008 - G. Robinson (AE-BE/ENG3)
#   Added support to select if resource analysis is performed.
#   Added support to select if the auto version update is completed.
# Version 016.00 - 29.09.2008 - G. Robinson (AE-BE/ENG3)
#   Variant handling.
# Version 016.01 - 06.10.2008 - G. Robinson (AE-BE/ENG3)
#   Optomisation for variant handling.
# Version 017.00 - 05.12.2008 - G. Robinson (AE-BE/ENG3)
#   Updated handling of variant selection. Now polls to get changes.
#   Fixed problem with variant box deselection.
#   Made the GUI smaller to fit common laptop screens.
#   Fixed handling when GUI is closed (i.e. thread handling / closing).
#   Clear screen control.
# Version 018.00 - 19.01.2009 - S. Weber (AE-BE/ENG3)
#   Integrated QAC analysis
# Version 018.01 - 20.01.2009 - G. Robinson (AE-BE/ENG3)
#   Small update to the buttons to make them all look uniform.
#   No functional changes.
# Version 018.02 - 22.01.2009 - S. Weber (AE-BE/EBS4-AU)
#   * create more detailed list for module analysis: show next level
#   of directories as well
#   * save the list file for the viewer for every analysed module,
#   that way, the results can be shown in the viewer without
#   having to do the analysis.
#   * added view module results button
# Version 018.03 - 10.02.2009 - S. Weber (AE-BE/EBS4-AU)
#   * moved generated files to temporary output folder
#   * added doxygen help compiler
#   * on startup read sw version from version file
#   * changed MO for getting the viewname
#   * moved populating the module menu to aseparate function and call it
#	 after the GUI has been started
# Version 018.04 - 25.02.2009 - S. Weber (AE-BE/EBS4-AU)
#   * removed doxygen view html button and related configuration
#   * fixed ecu version update and added variant handling for this.
# Version 018.05- 01.04.2009 - G. Robinson (AE-BE/ENG3)
#   Moved GetToplevelDirs to a thread to improve startup time.
# Version 018.06- 10.06.2009 - S. Weber (AE-BE/ENG3)
#   * added RTA-OS Button
#   * changed handling of QAC files to activate dependency checking
#	 in omake
#   * re-activated post analysis for report generation after QAC
#	 analysis
# Version 018.07- 02.07.2009 - S. Weber (AE-BE/ENG3)
#   New version of toolchain on generic branch:
#   * fix another dependency bug for QAC: compare fails if file ANALYSIS_DIRS.mak
#	 does not exist
# Version 018.08- 24.07.2009 - S. Weber (AE-BE/ENG3)
#   qac post analysis configuration for activation/deactivation via radiobutton
# Version 018.09- 12.08.2009 - S. Weber (AE-BE/ENG3)
#   deactivate all checkbuttons with the normal buttons
#   swapped order of report generation and qac viewer start
#   changed default for report generator checkbutton (deactivated)
# Version 018.10- 16.09.2009 - S. Weber (AE-BE/ENG3)
#   moved copying of PROJECT_DIRS.mak to omake build, where it belongs
# Version 018.11- 21.10.2009 - C. Baudry (AE-BE/EKE)
#   The variant list has been replaced with radio buttons
#   The GUI design has been modified and is now smaller
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.12 - 19.01.2010 - C. Baudry (AE-BE/EKE)
# - The checkbox "Version Update" default value can be changed in the file projectConfig_buildGUI.cfg
# - The GUI creation has been organized per module (before: per kind of object)
# - The SW-version inversion has been corrected (major, minor, revision were toggled between output file and GUI)
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.13 - 25.01.2010 - C. Baudry (AE-BE/EKE)
# - A popup appears at the end of the build/rebuild process. This can be activated/deactivated with a checkbox.
#   The checkbox default value can be modify in the BuildGUI configuration file
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.14 - 29.01.2010 - S. Weber (AE-BE/ENG31-AU)
# - added checkboxes for calling the NEC checker tool for list and hex files
# - new format for call of CreateMakFile
# - Added function for generating the m files
# - renamen UpdateProjectVersion to UpdateProjectVariant and added activation/deactivation of
#   QAC buttons
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.15 - 18.02.2010 - C. Baudry (AE-BE/ENG3)
# - Added WinIDEA version check with install and update possibilities
# - Some buttons are not deactivated anymore during the build process
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.16 - 01.03.2010 - C. Baudry (AE-BE/ENG3)
# - The GUI uses the files list generated by the script generateGHSDirList.py ONLY FOR QAC, Eclipse uses the directory parser!!!
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.17 - 11.03.2010 - C. Baudry (AE-BE/ENG3)
# - WinIDEA auto-install system has been improved: at the end of the install the emulator button is available and the tool versions are updated
# - The user can select with the GUI the path where he wants to install WinIDEA
# - Correction of the version 18.15: all buttons are deactivated during the build and QAC processes.
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.18 - 17.03.2010 - C. Baudry (AE-BE/ENG3)
# - The user can NOT select anymore with the GUI the path where he wants to install WinIDEA
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.19 - 31.03.2010 - C. Baudry (AE-BE/ENG3)
#   Add 3rd party QAC analyze support
#   Modification of the QAC project file: a copy is created based on a template (changed because of the 3rd Party SW analysis)
#   The QAC viewer can not be launched if the analysis has not been done
#   QAC report generation: a message appears to prevent the user to close Excel before launching the QAC analyze
#   Buttons and fields management: the versions fields are not available when the user does not want to update the version
#   Buttons and fields management: the QAC buttons are not activated after building when there were disabled before
#   WinIDEA auto-install: the status bar is red during the install and update
#   QAC 3rd Party analysis: it is not possible to generate a QAC report with the QAC 3rd party analysis
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.20 - 01.04.2010 - S. Weber (AE-BE/ENG31-AU)
#   Add extra configuration item for third party QAC analyze support
#   added support for extra output directory for third party analysis
#   added workaround for gbuild limitation: If no object files exist, the include dir list is empty and will
#	 be populated by parsing the SW directories
#	 This is done once in the dedicated thread and the result will be used during the lifetime of the GUI
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.21 - 07.04.2010 - C. Baudry (AE-BE/ENG3)
#   Add function UpdateGUI to update the widgets according to the GUI state, user selected options...
#   RCM 65052:  The Eclipse and QAC buttons are not available if the include list is not ready
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 018.22 - 05.05.2010 - C. Baudry (AE-BE/ENG3)
#   RCM 65127: The GUI is updated according to the selected variant and its configuration
#   RCM 65195: If the GUI control is not available, we do not do anything in the UpdateGUI function (We let all buttons deactivated)
#   RTA-OS configuration is dependent of the variant and can not be launched if not configured
#   Add the value "Not_Required" in the GUI config file. Adaptions of the file buildGUI.py
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 019.00 - 21.05.2010 - C. Baudry (AE-BE/ENG3)
#   RCM 65310: the GUI components are dynamically loaded according to the GUI configuration file
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 019.01 - 25.05.2010 - C. Baudry (AE-BE/ENG3)
#   RCM 123519: The QAC summary file is now named QAC_Summary.txt instead of QAC_Results.txt
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 020.00 - 02.06.2010 - C. Baudry (AE-BE/ENG3)
#   Tools can be dynamically added to the GUI via the GUI config file
#   RCM 65195 bugfix: the GUI update after enabling the control has been fixed
#   The NVM tool has been deleted from the standard GUI, it can be added in the project specific tools if required
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 020.01 - 15.06.2010 - C. Baudry (AE-BE/ENG3)
#   RCM Activity 65125: The QAC analysis is done only if the include list is based on the project specific dir list
#   Batch _clearcaseEclipseProject.bat: The Eclipse path contained in this batch is not dependent of the mapped drive. It uses the env 
#									   variable set from the GUI.
#   Batch _undocheckoutEclipseProject.bat: The Eclipse path used in this batch is nether dependent of the mapped drive nor of the GUI. 
#										  It can be used alone.
#   GUI: the environment variable BCMF_SELECTED_VARIANT contained the current selected version and can be used by the project.
#   Mapped drive: the chosen letter can be given in the file __ProjectStartBuild.bat with the variable PROJECT_MAPPED_DRIVE. The batches 
#				 _mapDrive and unMapDrive take this variable as parameter.
#   OS-Config: use relativ paths instead of mapped drive
#   RCM Activity 123086: QAC CMA added in the QAC post-analysis 
#   RCM Activity 123798: The version control is not done if the component is not listed in the file projectConfig_versions.cfg
#--------------------------------------------------------------------------------------------------------------------------------------
# Modification - 19.07.2010 - D. Dal Piva (AE-BE/ENG3)
#   use configuration SCAN_SOURCE_DIR to scan the source directories
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 020.02 - 14.09.2010 - C. Baudry (AE-BE/ENG3)
#   News function: Function to popup a news message while opening the GUI. The news can be edited in the file ToolChainNewsMessage.txt
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 021.00 - 29.09.2010 - C. Baudry (AE-BE/ENG3)
#   RCM Activity 69371: Ask the user if he really wants to rebuild
#   GUI: the Tkinter possibilities have been extended with the Tix librairy: more widgets available
#   Mapped drive: it is not required anymore to map the project on the chosen drive: 
#					   it is now an option in the file __ProjectStartBuild.bat
#   RCM Activity 73104: File PROJECT_DIRS_TEMPLATE.mak: issue when no directory in 3rd Party Tools 
#					   and "THIRD_PARTY=\" is the last line of the file. Changes in file 
#					   generateQACDirrList.py
#   QAC: A GPJ filter has been added for the QAC files generation: only the compiled files are 
#		analysed. The option can be disabled while calling the scripts BUILD_LIST_WITH_DIRS.py and
#		QAC_LIST_WITH_DIRS.py from the file makeQacCfg.mak.
#   GUI: The functions EnableControls and DisableControls have been merged.
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 021.01 - 27.01.2011 - C. Baudry (AE-BE/ENG3)
#   RTA-OS: The RTA-OS generator can now also be launch from a snapshot view
#		   This feature works with the label BCMF_COTS SRC_20110127_RTAOS_V4_0_HWA01_BCM_CORE_BCMF_COTS
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 021.02 - 01.02.2011 - C. Baudry (AE-BE/ENG3)
#   RCM Activity 64755: The GUI does not report an error if the WinIDEA user version is newer than required by the project.
#   QAC Module analysis: the user has the possibility to filter the dependencies which are not directly contained in its module.
#   QAC Module analysis: correct analysis file update at startup: if the module and the analysis files are identical,
#						the analysis file is not overwritten at startup: the analysis results are kept.
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 022.00 - 17.03.2011 - C. Baudry (AE-BE/ENG3)
#   GUI: The ECU version update function can be enabled or disabled in the GUI configuration
#   QAC: The GreenHills parser optimisation function can be enabled or disabled in the GUI configuration
#   QAC: The automatically generation of the directory list can be enabled or disabled in the GUI configuration
#   Eclipse: The include path list generation can be enabled or disabled in the GUI configuration
#   GUI: The "What's new?" button enables the user to popup the GUI news
#   Map Drive: It is also possible to map a drive while using a snapshot view
#   GUI: Bugfix: The buttons install/update WinIDEA have been added in the enable/disable control function.
#   GUI: RCM 124766 & 69378: it is possible to delete unused parts of the GUI config file
#   GUI: RCM 124765: "MPC generic" has been removed
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 023.00 - 28.03.2011 - C. Baudry (AE-BE/ENG3)
#   GUI: merge functions EnableDisableControls and UpdateGUI together: the ideas both functions was the same
#   GUI & WinIDEA: if the WinIDEA install failed, the user get a message in the console and can still use the GUI
#				  In the previous version, the user could not use the GUI anymore.
#   GUI Prebuild: The elf file configured for the selected variant is deleted before building the project
#				 This is usefull to check if the project has successfully compiled
#   GUI Postbuild: A popup informs the user about the compilation result: failed or successed
#   Stack Checker: add stack checker support in the GUI
#				  This function uses the script stackchecker.py. This script can be extended with the used compiler
#				  The only current available compiler is GHS
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 023.01 - 11.04.2011 - C. Baudry (AE-BE/ENG3)
#   GUI: Merge function UpdateSwVersion in UpdateGUI
#   ECU Version: Add the possibility to select which ECU version fields are required (major, minor, revision)
#   ECU Version: Remove the version string configuration (CFG_PREFIX_MAJORVER, CFG_PREFIX_MINORVER, CFG_PREFIX_REVVER)
#				They were use only if the project do not use the ECU Version update function: not required!
#   QAC Module analysis: Correct the way to compare the make files: the whole project was analysed after analysing a module, then
#						the project and then the same module.
#   GUI: RCM85672: Delete line which says that the elf file has been deleted
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 024.00 - 20.04.2011 - C. Baudry (AE-BE/ENG3)
#   GUI: RCM85643: The toolchain configuration folder path can be configured in the file __ProjectStartBuild.bat
#   GUI: RCM85195: The QAC templates have been moved in the toolchain configuration directory: project specific
#   Parser: RCM85194: The exclude list is read from the GUI configuration file, file generateDirList.py not project specific
#   QAC: Correct bug while using QAC without the parser: a copy of the PROJECT_DIRS.mak file creates a read-only file: the module file 
#		can not be created and the whole project is analysed.  
#   GUI Cfg: Fix: The QAC post analysis option should not be checked.  
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 024.01 - 25.07.2011 - C. Baudry (AE-BE/ENG3)
#   QAC: Add support for CMA analysis
#   QAC: If the CMA analysis is selected, the toolchain will create a QAC project file
#   QAC: Add the possibility to ONLY analyse the 3rd party SW or to
#							   INCLUDE the 3rd party SW in the project analysis
#   Resource Analyse: RCM107573: Open the results directly from the GUI
#   Resource Analyse: RCM107565: An overview of the results is shown in the console
#   GUI: Some checkboxes have been moved to their belonging module
#   Eclipse: RCM107587: make start of eclipse from GUI quicker and simpler
#			The Eclipse button is available directly after startup. Eclipse is started only when the include list is ready.
#   QAC: RCM85202: Before running a QAC project analysis, the user is asked if he wants to generate an Excel report directly after the
#		the anylysis (only in the case he didn't select the post-analysis checkbox).
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 025.00 - 23.11.2011 - M. Hamann (AE-BE/ENG3)
#   GUI: Back to Tkinter to be able to use LabelFrames
#   GUI: Title contains project name and version
#   GUI/WinIDEA: Including Profiler(+Help), Code Coverage and BCMF Logger
#   GUI: Status bar moved to the bottom of the gui
#   GUI: Toolbar moved to status bar
#   GUI: Automatic line wrap of the view string in header
#   GUI: Dynamic columns configuration according to required tools
#		   1st column: variant,build control,sw version,version info
#		   2nd column: on-chip debugging,project specific,documentation
#		   3rd column: qac project analysis, qac module analysis
#   Stack Results: It's possible to open the stack results from the gui
#   GUI: "Generator" Frame has been deleted and it's content has been moved to the project specific LabelFrame
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 025.01 - 16.05.2012 - C. Baudry (AE-BE/ENG3)
#   Tools versions management: WinIDEA version: add the possibility to install a new year version (ex: 2011 to 2012) (versions.py)
#   GUI & WinIDEA: EBRCM00477676: The silent install has been adapted for Windows 7
#   Licence management: EBRCM00426342: Store license server information on compilers VOB (label TOOLCHAIN_CURRENT_LICENCES)
#   GUI: EBRCM00054333: Cancel button for the build and rebuild functions: the process to be canceled can be configured per variant.
#   GUI: EBRCM00065000: Build start time and duration appear in the console, in the popup and in the GUI status
#   GUI: Remove some status task update which were not important (OS configurator, debugger, help...)
#   Eclipse: EBRCM00461954: Correct the "path is too long" problem while generating the indexer environment variables
#   GUI: EBRCM00432549: Error correction: The resource analysis results can be open for all variants
#   GUI: EBRCM00439308: Save user settings during and between GUI use
#   Stack checker: EBRCM00148119: The stack section name can be configured (stackchecker.py)
#   GUI: The "open stack result" button has been removed: not very usefull
#   GUI: The profiler and code coverage buttons are active only if the variant is configured
#   addon in version 25.01 - 16.05.2012 - C. Baudry (AE-BE/ENG3)
#	Emulator: Modify error text "please contact the BCMF support team"
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 026.00 - 21.05.2013 - C. Baudry (AE-BE/ENG3)
#   GUI: add checkbox "Delete elf before build": if selected, the elf file will be removed before building (default)
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 026.01 - 21.05.2013 - C. Baudry (AE-BE/ENG3)
#   Emulator: Change the way to install WinIDEA:
#			 - No special WinIDEA toolchain directory. Use the default WinIDEA path.
#			 - Get the WinIDEA version checking the install path in the registry
#			 - Possible to install WinIDEA without updating it 
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 027.00 - 06.06.2014 - C. Baudry (AE-BE/ENG3)
#   Add the metrics analysis after the QAC module analysis
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 027.01 - 24.06.2014 - C. Baudry (AE-BE/ENG3)
#   Adapt the WinIDEA installation threads with the use case: the user cancel the installation because of missing admin rights
#--------------------------------------------------------------------------------------------------------------------------------------
# Version 027.02 - 12.09.2014 - C. Baudry (AE-BE/ENG3)
#   Add version check of the tool CANoe (only change in the script versions.py, optional)
#--------------------------------------------------------------------------------------------------------------------------------------

''' tool version '''
tool_version = 27.02

''' import windows library '''
from Tkinter import *
import tkMessageBox

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import time functions for sleep '''
import time

''' import re for regular expressions '''
import re

''' import subprocess for executing commands '''
import shutil

''' import file compare lib '''
import filecmp

''' import dircache '''
import dircache

''' import subprocess for executing commands '''
import subprocess

''' import threading '''
import threading

''' import thread '''
import thread

import datetime

''' import the directory generator '''
from generateDirList import GenerateDirList
from generateGHSDirList import GenerateGHSDirList

''' import the configuration file handler '''
from configFile import ConfigFile

''' import the versions handler '''
from versions import ToolVersions

''' import the rom version updater '''
from ecuversion import EcuVersions

''' import the mak file creater '''
from makConfigFile import CreateMakFile

'''import the m file generator'''
from mFileGen import MFileGen

'''import the qac update functions'''
from generateQACDirList import GenerateQACDirList
from generateQACDirModuleList import GenerateQACDirModuleList
from generateQACproject import GenerateQACproject

'''import the include directory function for eclipse'''
from includeDirectories import IncludeDirectories

''' import stack checker classes '''
from stackchecker import *

''' use to read a registry key (for the WinIDEA local path) '''
from _winreg import *

''' tool chain components '''
CFG_BUILD_MODULE		   = "BUILD_MODULE"
CFG_OBUILD_MODULE		  = "OBUILD_MODULE"
CFG_EMULATOR_MODULE		= "EMULATOR_MODULE"
CFG_PROFILER_MODULE		= "PROFILER_MODULE"
CFG_CODECOVERAGE_MODULE	= "CODECOVERAGE_MODULE"
CFG_LOGGER_MODULE		  = "LOGGER_MODULE"
CFG_ECLIPSE_MODULE		 = "ECLIPSE_MODULE"

CFG_QAC_MODULE			 = "QAC_MODULE"
CFG_OS_GENERATOR_MODULE	= "OS_GENERATOR_MODULE"
CFG_M_FILE_GENERATOR_MODULE = "M_FILE_GENERATOR_MODULE"
CFG_DOCU_GENERATOR_MODULE  = "DOCU_GENERATOR_MODULE"
CFG_ECUVERSION_MODULE	  = "ECUVERSION_MODULE"

''' resource analysis configurations '''
CFG_RESOURCE_ANALYSIS_DEF = "RESOURCE_ANALYSIS_DEF"

''' version update checkbox configuration '''
CFG_VERSION_UPDATE_DEF = "VERSION_UPDATE_DEF"

''' BUILD Pop-up checkbox configuration '''
CFG_POPUP_END_OF_BUILD = "POPUP_END_OF_BUILD"

''' News function configuration '''
CFG_NEWS_POPUP = "NEWS_POPUP"

''' Ask the user before rebuild configuration '''
CFG_ASK_BEFORE_REBUILD = "ASK_BEFORE_REBUILD"

''' stack checker configuration '''
CFG_STACK_CHECKER_DEF = "STACK_CHECKER_DEF"

''' Parser options '''
CFG_ECLIPSE_DIRECTORY_PARSER = "ECLIPSE_DIRECTORY_PARSER"
CFG_DIRECTORY_PARSER_OPTIMISATION = "DIRECTORY_PARSER_OPTIMISATION"
CFG_QAC_DIRECTORY_PARSER = "QAC_DIRECTORY_PARSER"

''' variant tags '''
CFG_TAG_VARIANT			= "VARIANT"
CFG_TAG_DEFAULTVARIANT	 = "VARIANT_DEFAULT"

''' non variant specific configurations '''
CFG_PROJECT_NAME		   = "PROJECT_NAME"
CFG_PROJECT_MICRO		  = "PROJECT_MICRO"
CFG_ECLIPSE				= "ECLIPSE"
CFG_HELP_LINK			  = "HELP_LINK"
CFG_TEMP_OUT			   = "TEMP_OUT"
CFG_QAC_OUTPATH			= "QAC_OUTPATH"
CFG_QAC_TEMP_OUTPATH	   = "QAC_TEMP_OUTPATH"
CFG_BUILD_TEMP_OUTPATH	 = "BUILD_TEMP_OUTPATH"
CFG_POST_ANALYSIS		  = "POST_ANALYSIS"
CFG_CROSS_ANALYSIS		 = "CROSS_ANALYSIS"
CFG_RTA_OS				 = "RTA_OS"

''' specific tools '''
MAX_SPECIFIC_TOOLS = 15
CFG_NUMBER_SPECIFIC_TOOLS = "NUMBER_SPECIFIC_TOOLS"
CFG_PREFIX_SPEC_TOOL_NAME = "SPECIFIC_TOOL_BUTTON_NAME_"
CFG_PREFIX_SPEC_TOOL_BATCH= "SPECIFIC_TOOL_BATCH_"

''' variant specific prefixes '''
CFG_PREFIX_ELF		   = "ELF_"
CFG_PREFIX_LD_FILE	   = "LD_"
CFG_PREFIX_BUILD		 = "BUILD_"
CFG_PREFIX_REBUILD	   = "REBUILD_"
CFG_PREFIX_GET_SRC	   = "GET_SRC_"
CFG_PREFIX_GET_INC	   = "GET_INC_"
CFG_PREFIX_OBUILD		= "OBUILD_"
CFG_PREFIX_OREBUILD	  = "OREBUILD_"
CFG_PREFIX_HEX		   = "HEX_"
CFG_PREFIX_RESOURCE	  = "RESOURCE_"
CFG_PREFIX_STACK		 = "STACK_"
CFG_PREFIX_PREBUILD	  = "PREBUILD_"
CFG_PREFIX_POSTBUILD	 = "POSTBUILD_"
CFG_PREFIX_USEMAJOR	  = "USEMAJOR_"
CFG_PREFIX_USEMINOR	  = "USEMINOR_"
CFG_PREFIX_USEREV		= "USEREV_"
CFG_PREFIX_EMULATOR	  = "EMULATOR_"
CFG_PREFIX_PROFILER	  = "PROFILER_"
CFG_PREFIX_CODECOVER	 = "CODECOVER_"
CFG_PREFIX_DOCHELP	   = "DOCHELP_"
CFG_PREFIX_DOXYGEN	   = "DOXYGEN_"
CFG_PREFIX_ECUVERCFG	 = "ECUVERCFG_"
CFG_PREFIX_QACALL		= "QACALL_"
CFG_PREFIX_QACVIEW	   = "QACVIEW_"
CFG_PREFIX_QACMOD		= "QACMOD_"
CFG_PREFIX_QACMVIEW	  = "QACMVIEW_"
CFG_PREFIX_OSCFG		 = "OSCFG_"
CFG_PREFIX_QAC3RD		= "QAC3RD_"
CFG_PREFIX_QAC3VIEW	  = "QAC3VIEW_"
CFG_PREFIX_STACKCFG	  = "STACKCFG_"
CFG_PREFIX_BUILDTASK	 = "BUILDTASK_"

''' enabled / disabled '''
CFG_ENABLED				= "ENABLED"
CFG_DISABLED			   = "DISABLED"
CFG_NOT_IMPLEMENTED		= "Not_Yet_Implemented"
CFG_NOT_REQUIRED		   = "Not_Required"
CFG_REQUIRED			   = "Required"
DISABLE_CONTROL			= False
ENABLE_CONTROL			 = True

''' define version colours '''
VERSION_OK				  = "blue"
VERSION_NOT_OK			  = "red"

''' os thread active status '''
os_thread_active = False


''' Thread to execute OS commands without locking the GUI '''
class ThreadedExecuteOSCommand(threading.Thread):

	def __init__ (self, command):
		global os_thread_active

		os_thread_active = True
		self.command = command
		threading.Thread.__init__ ( self )

	def run(self):
		global os_thread_active

		print "Executing Thread: " + self.command
		os.system(self.command)
		os_thread_active = False


''' thread to parse all directories for directories containing source and header files '''
''' used for qac module list, qac project list and eclipse '''
class ThreadedGetSourceDirectoryListing(threading.Thread):

	def __init__ (self, sourceDirectory, commandArray, configuration_file, component_QAC_active, component_QAC_PARSER_OPT_active):
		self.sourceDir = sourceDirectory
		self.CommandArray = commandArray
		self.configuration_file = configuration_file
		self.component_QAC_active = component_QAC_active
		self.component_QAC_PARSER_OPT_active = component_QAC_PARSER_OPT_active
		
		''' prepare configuration dictionary '''
		self.configuration = ConfigFile(self.configuration_file).ConfigDictionary()
		
		self.threadRunning = False
		self.parserIncDirList = False
		threading.Thread.__init__ ( self )

	def run(self):

		self.threadRunning = True
		
		''' Scanning directories according to used parser optimisation '''
		''' Possible optimisation: False, "GHS" '''
			
		''' Parser optimisation used with GHS compiler '''
		if self.component_QAC_PARSER_OPT_active == "GHS":
			
			__VariantRadioGroup = self.configuration["SCAN_SOURCE_DIR"]
			print ""
			print "Scanning directories in background using the GHS parser optimisation..."
			print "All controls will be available only after scan is complete."
			
			''' prepare commands to get the lists '''
			if (self.CommandArray[CFG_PREFIX_GET_SRC][__VariantRadioGroup] == "Not_Yet_Implemented") | \
			(self.CommandArray[CFG_PREFIX_GET_SRC][__VariantRadioGroup] == "Not_Required") | \
			(self.CommandArray[CFG_PREFIX_GET_INC][__VariantRadioGroup] == "Not_Yet_Implemented") | \
			(self.CommandArray[CFG_PREFIX_GET_INC][__VariantRadioGroup] == "Not_Required"):
				''' error with the configuration '''
				print "\nError: please check the configuration of the following variant commands:"
				print "- " + CFG_PREFIX_GET_SRC + __VariantRadioGroup
				print "- " + CFG_PREFIX_GET_INC + __VariantRadioGroup
				print "\n\n"
			else:
				self.commandSource = self.CommandArray[CFG_PREFIX_GET_SRC][__VariantRadioGroup]
				self.commandInclude = self.CommandArray[CFG_PREFIX_GET_INC][__VariantRadioGroup]
			
			self.GHSdirListGen = GenerateGHSDirList(self.commandSource, self.commandInclude)
			self.srcDirList = self.GHSdirListGen.GetSourceDirList()
			self.incDirList = self.GHSdirListGen.GetIncludeDirList()
		
			''' in the case the project has never been built, the include dir list is get with the function GenerateDirList '''
			if len(self.incDirList) == 0:
				self.incDirList = GenerateDirList(self.sourceDir, self.configuration_file).GetIncludeDirList()
				self.parserIncDirList = True
		
		
		else:
			''' No parser optimisation '''
			print ""
			print "Scanning directories in background..."
			print "All controls will be available only after scan is complete."
			self.srcDirList = GenerateDirList(self.sourceDir, self.configuration_file).GetSourceDirList()
			self.incDirList = GenerateDirList(self.sourceDir, self.configuration_file).GetIncludeDirList()
		
		
		''' Create the module list for QAC; only done if QAC is required '''
		if self.component_QAC_active == True:
			modListAll = []

			''' shorten the entries in this list to a max of two subdirectories under
				the toplevel directory to get a module list'''
			for subdir in self.srcDirList:
				'''The format of the list is something like this:
				   sourceDir\layerName\moduleName\moduleSubfolders
				   We are looking at layerName\moduleName'''

				'''sourceDir is known and at the start of the path so we
				  can reomove length(sourceDir) from the path'''
				subdir = subdir[len(self.sourceDir)+1:]
				''' now remove everything after the second backslash (including),
					if there is no second backslash, remove the first'''
				bsCount = subdir.count('\\')
				if bsCount > 1:
					splitSubdir = subdir.split('\\')
					subdir = splitSubdir[0] + '\\' + splitSubdir[1]
				if subdir not in modListAll:
					modListAll.append(subdir)
					
			bcmf_builder_main.UpdateQACModules(modListAll)
		
		
		print ""
		print "Directory lists loaded..."		
		
		''' mark end of thread '''
		self.threadRunning = False
		
		''' Eclipse can now be started if required '''
		if bcmf_builder_main.EclipseStartSuspended == True:
			bcmf_builder_main.EclipseStartSuspended = False
			bcmf_builder_main.EclipseExecute()
				
		''' manage the project options and GUI widgets '''
		bcmf_builder_main.UpdateGUI()
		

	def stop(self):
		self.threadRunning = False

	def GetSourceDirs(self):
		return self.srcDirList

	def GetIncludeDirs(self):
		return self.incDirList
		
	def IsIncDirListParserWithoutOptimisationUsed(self):
		return self.parserIncDirList



''' Thread to install winIDEA '''
class ThreadedInstallWinIdea(threading.Thread):

	def __init__ (self):
		self.threadRunning = False
		self.tempOutpath = os.environ.get("BCMF_TEMP_OUT")
		threading.Thread.__init__ ( self )

	def run(self):

		self.threadRunning = True

		print ""
		print "Installing WinIDEA in background..."

		__command = "tasklist >" + self.tempOutpath + "\\temp_tasklist.txt"
		__timeoutReached = False
		__timeout = 40 # timeout 40 seconds
		__cancelInstall = False
		__installIsPending = True
		__installIsRunning = False
		__stringFound = False

		''' check if the install has began '''
		''' -- it can happen that the install never begin because of missing admin rights '''
		''' -- a timeout is used to end the install thread in this case '''
		while 1:
			
			if not __installIsPending: break
			if __timeoutReached: break
			
			os.system(__command)
			
			''' the content of the temporary file is read '''
			f = open(self.tempOutpath + "\\temp_tasklist.txt", "r")
			content_listed_f = f.readlines()
			f.close()
			
			for line in content_listed_f:
				if re.findall("winidea", line.lower()):
					__installIsPending = False
					__installIsRunning = True
					
			# timeout management
			time.sleep(1)
			__timeout -= 1
			if __timeout == 0:
				__timeoutReached = True
				__cancelInstall = True
			
			
		''' check every 2 seconds if the installation is finished '''
		''' it is done in a loop '''
		if __cancelInstall == False:
			while __installIsRunning:
	
				time.sleep(2)
	
				__stringFound = False
	
				os.system(__command)
	
				''' the content of the temporary file is read '''
				f = open(self.tempOutpath + "\\temp_tasklist.txt", "r")
				content_listed_f = f.readlines()
				f.close()
	
				for line in content_listed_f:
					if re.findall("winidea", line.lower()):
						__stringFound = True
	
				if __stringFound == False:
					__installIsRunning = False

			print "WinIDEA has been installed!"

			''' get the install path to check the installed version '''
			bcmf_builder_main.GetWinideaLocalPath()
			
			''' update and verify version tools to check if an update is required'''
			bcmf_builder_main.TestVersion()
			if bcmf_builder_main.versions.GetToolRequiredAction()["WinIDEA"] == "ToUpdate":
				bcmf_builder_main.UpdateWinIdea()
			elif bcmf_builder_main.versions.GetToolRequiredAction()["WinIDEA"] != "DoNothing":
				print "\nError with the WinIDEA installed version, please contact the BCMF support team.\n"
			else:
				''' the GUI controls are enabled '''
				bcmf_builder_main.controls_enabled = True
				bcmf_builder_main.UpdateGUI()
				''' Update the status bar '''
				bcmf_builder_main.actual_status.set("Complete...")
				bcmf_builder_main.status_label.config(background='white')

		else:
			print "\n--WinIDEA install timeout!--\n"
			''' the GUI controls are enabled '''
			bcmf_builder_main.controls_enabled = True
			bcmf_builder_main.UpdateGUI()
			''' Update the status bar '''
			bcmf_builder_main.actual_status.set("Complete...")
			bcmf_builder_main.status_label.config(background='white')
				
		''' mark end of thread '''
		self.threadRunning = False

	def stop(self):
		self.threadRunning = False


''' Thread to update winIDEA '''
class ThreadedUpdateWinIdea(threading.Thread):

	def __init__ (self):
		self.threadRunning = False
		self.tempOutpath = os.environ.get("BCMF_TEMP_OUT")
		threading.Thread.__init__ ( self )

	def run(self):

		self.threadRunning = True

		print ""
		print "Updating WinIDEA in background..."

		__command = "tasklist >" + self.tempOutpath + "\\temp_tasklist.txt"
		__timeoutReached = False
		__timeout = 40 # timeout 40 seconds
		__cancelInstall = False
		__installIsPending = True
		__installIsRunning = False
		__stringFound = False

		''' check if the install has began '''
		''' -- it can happen that the install never begin because of missing admin rights '''
		''' -- a timeout is used to end the install thread in this case '''
		while 1:
			
			if not __installIsPending: break
			if __timeoutReached: break
			
			os.system(__command)
			
			''' the content of the temporary file is read '''
			f = open(self.tempOutpath + "\\temp_tasklist.txt", "r")
			content_listed_f = f.readlines()
			f.close()
			
			for line in content_listed_f:
				if re.findall("winidea", line.lower()):
					__installIsPending = False
					__installIsRunning = True
					
			# timeout management
			time.sleep(1)
			__timeout -= 1
			if __timeout == 0:
				__timeoutReached = True
				__cancelInstall = True
			
			
		''' check every 2 seconds if the installation is finished '''
		''' it is done in a loop '''
		if not __cancelInstall:
			while __installIsRunning:
	
				time.sleep(2)
	
				__stringFound = False
	
				os.system(__command)
	
				''' the content of the temporary file is read '''
				f = open(self.tempOutpath + "\\temp_tasklist.txt", "r")
				content_listed_f = f.readlines()
				f.close()
	
				for line in content_listed_f:
					if re.findall("winidea", line.lower()):
						__stringFound = True
	
				if __stringFound == False:
					__installIsRunning = False
	
			print "WinIDEA has been updated!"

			''' get the install path to check the installed version '''
			bcmf_builder_main.GetWinideaLocalPath()
			
			''' update version tools '''
			bcmf_builder_main.TestVersion()
	
			''' if the version is not ok, the user is prevented '''
			if bcmf_builder_main.versions.GetToolRequiredAction()["WinIDEA"] != "DoNothing":
				print "\nError with the WinIDEA installed version, please contact the BCMF support team.\n"
				
		else:
			print "\n--WinIDEA install timeout!--\n"
			
		''' the GUI controls are enabled '''
		bcmf_builder_main.controls_enabled = True
		bcmf_builder_main.UpdateGUI()

		''' Update the status bar '''
		bcmf_builder_main.actual_status.set("Complete...")
		bcmf_builder_main.status_label.config(background='white')
		
		''' mark end of thread '''
		self.threadRunning = False

	def stop(self):
		self.threadRunning = False


''' Thread to manage the build / rebuild cancel function '''
class ThreadedCancelBuild(threading.Thread):

	def __init__ (self):
		self.threadRunning = False
		self.tempOutpath = os.environ.get("BCMF_TEMP_OUT")
		self.taskCommand = "tasklist >" + self.tempOutpath + "\\temp_tasklist.txt"
		self.debounceCounter = 0
		self.buildRunning = False
		threading.Thread.__init__ ( self )
	
	def run(self):	   
		self.threadRunning = True
		
		while(self.threadRunning == True):
		
			''' a timer is required to not slow down the build process '''
			time.sleep(2)
			
			self.stringFound = False

			''' get the windows task list, save it in a tmp file '''
			os.system(self.taskCommand)
			''' the content of the temporary file is read '''
			__f = open(self.tempOutpath + "\\temp_tasklist.txt", "r")
			__content_listed_f = __f.readlines()
			__f.close()
			
			''' check if the compilation is not running (cleaning or finished) '''
			''' in this case it is not possible to cancel the build process '''
			if (self.buildRunning == False):
	
				bcmf_builder_main.build_cancel_button_application.config(state=DISABLED)
				
				''' look for the build process in the task list '''
				''' it is working according to the project configured process name '''
				for __line in __content_listed_f:
					if re.findall(bcmf_builder_main.commandArray[CFG_PREFIX_BUILDTASK][bcmf_builder_main.variantRadioGroup.get()], __line):
						self.buildRunning = True

			''' check if the compilation is running '''
			''' in this case it is possible to cancel the build process '''
			if (self.buildRunning == True):
			
				bcmf_builder_main.build_cancel_button_application.config(state=NORMAL, foreground="red")
				
				''' look for the build process in the task list '''
				''' it is working according to the project configured process name '''
				self.stringFound = False
				for __line in __content_listed_f:
					if re.findall(bcmf_builder_main.commandArray[CFG_PREFIX_BUILDTASK][bcmf_builder_main.variantRadioGroup.get()], __line):
						self.buildRunning = True
						self.stringFound = True
						self.debounceCounter = 0
					
				''' check here if the build process is finished (with debounce - 3 times) '''
				if self.stringFound == False:
					self.debounceCounter = self.debounceCounter + 1
					if self.debounceCounter == 3:
						self.buildRunning = False
						bcmf_builder_main.build_cancel_button_application.config(state=DISABLED)
		
		bcmf_builder_main.build_cancel_button_application.config(state=DISABLED)
	   
	   
	def stop(self):
		self.threadRunning = False

	
	   
''' class for the BCMF builder '''
class BCMFBuilder:

	def __init__(self, configuration_file, version_configuration, ecuversion_configuration, qac_configuration, mfile_configuration, metrics_configuration):

		''' __init__ parameters '''
		self.configuration_file			= configuration_file
		self.version_configuration_file	= version_configuration
		self.qac_configuration_file		= qac_configuration
		self.ecuversion_configuration_file = ecuversion_configuration
		self.mfile_configuration_file	  = mfile_configuration
		self.metrics_configuration_file	= metrics_configuration

		''' get environnment variables '''
		self.sourceDir		   = os.environ.get("BCMF_SOFTWARE_BASE")
		self.tempOutpath		 = os.environ.get("BCMF_TEMP_OUT")
		self.scriptOutPath	   = os.environ.get("BCMF_SCRIPT_OUTPUT")
		self.stackCheckerOutPath = self.scriptOutPath + "\\stackChecker_output"
		self.scriptsPath		 = os.environ.get('BCMF_SCRIPTS_ROOT')
		self.pythonExe		   = os.environ.get('PYTHON_EXE')
		
		''' files globally used '''
		self.tempResourceAnalyseResultPath = self.tempOutpath + "\\tempResourceAnalyseResultPath.txt"
		self.tempStackAnalyseFile		  = self.scriptOutPath + "\\stackChecker_output\\StackCheckerResults.txt"
		self.metricsAnalysisResultFile	 = self.tempOutpath + "\\MetricsAnalysisConfiguredReport.html"

		''' setup the command array for the different variants '''
		self.commandArray = {CFG_PREFIX_ELF:		 {},
							 CFG_PREFIX_LD_FILE:	 {},
							 CFG_PREFIX_BUILD:	   {},
							 CFG_PREFIX_REBUILD:	 {},
							 CFG_PREFIX_GET_SRC:	 {},
							 CFG_PREFIX_GET_INC:	 {},
							 CFG_PREFIX_OBUILD:	  {},
							 CFG_PREFIX_OREBUILD:	{},
							 CFG_PREFIX_HEX:		 {},
							 CFG_PREFIX_RESOURCE:	{},
							 CFG_PREFIX_STACK:	   {},
							 CFG_PREFIX_PREBUILD:	{},
							 CFG_PREFIX_POSTBUILD:   {},
							 CFG_PREFIX_USEMAJOR:	{},
							 CFG_PREFIX_USEMINOR:	{},
							 CFG_PREFIX_USEREV:	  {},
							 CFG_PREFIX_EMULATOR:	{},
							 CFG_PREFIX_PROFILER:	{},
							 CFG_PREFIX_CODECOVER:   {},
							 CFG_PREFIX_DOCHELP:	 {},
							 CFG_PREFIX_DOXYGEN:	 {},
							 CFG_PREFIX_ECUVERCFG:   {},
							 CFG_PREFIX_QACALL:	  {},
							 CFG_PREFIX_QACVIEW:	 {},
							 CFG_PREFIX_QACMOD:	  {},
							 CFG_PREFIX_QACMVIEW:	{},
							 CFG_PREFIX_OSCFG:	   {},
							 CFG_PREFIX_QAC3RD:	  {},
							 CFG_PREFIX_QAC3VIEW:	{},
							 CFG_PREFIX_STACKCFG:	{},
							 CFG_PREFIX_BUILDTASK:   {}}

		self.gui = Tk()
		self.gui.grid()
		
		''' state of the controls '''
		self.controls_enabled = True

		''' resource analysis check '''
		self.performResourceAnalysis = IntVar()
		
		''' Enable/Disable Debug mode '''
		self.enableDebugFlag = IntVar()

		''' automatically check out version file and update during build '''
		self.autoVersionUpdate = IntVar()

		''' perform post analysis script after project analysis '''
		self.performPostAnalysis = IntVar()
		
		''' perform cross analysis script after project analysis '''
		self.performCrossAnalysis = IntVar()

		''' perform only 3rd party code QAC analysis '''
		self.onlyThirdPartyAnalysis = IntVar()
		
		''' perform QAC analysis for 3rd party code together with project code '''
		self.includeThirdPartyAnalysis = IntVar()
		
		''' perform stack check '''
		self.performStackCheck = IntVar()
		
		''' filter dependencies for QAC module analysis '''
		self.filterDependencies = IntVar()
		self.filter_dependencies_button_state = False
		self.filter_dependencies_button_state_old = False

		''' advert the user that the build is finished with a popup '''
		self.popupBuild = IntVar()
		
		''' delete elf file before build variable checkbox '''
		self.deleteElf = IntVar()

		''' variants radiobuttons'''
		self.variantRadioGroup = StringVar()
		
		''' number of variants contained in the project '''
		self.numberOfVariants = IntVar()

		''' WinIDEA thread control '''
		self.threadUpdateWinIdeaExist = IntVar()
		self.threadInstallWinIdeaExist = IntVar()
		self.threadUpdateWinIdeaExist = False
		self.threadInstallWinIdeaExist = False
		
		''' Eclipse start control '''
		self.EclipseStartSuspended = False
		
		''' startup flag '''
		self.firstRunUpdateGUI = True


		''' try to initialise as some configuration options may be not present '''
		try:

			''' ------------------------------------------------------------------------- '''
			''' setup dictionaries from config file									   '''

			''' set up the configuration files and the mak files '''
			'''read configuration file for the Build GUI'''
			self.configuration = ConfigFile(self.configuration_file).ConfigDictionary()
			CreateMakFile(self.configuration_file, self.configuration_file)
			'''read configuration file for QAC'''
			qac_config = ConfigFile(self.qac_configuration_file).ConfigDictionary()
			CreateMakFile(self.configuration_file, qac_configuration)
			'''set internal variables for later use'''
			self.qacOutpath = qac_config[CFG_QAC_OUTPATH]
			self.qacTempOut = qac_config[CFG_QAC_TEMP_OUTPATH]
			self.buildTempOut = self.configuration[CFG_BUILD_TEMP_OUTPATH]
			self.tempOut = self.configuration[CFG_TEMP_OUT]

			''' prepair variant dictionaries '''
			variants = ConfigFile(self.configuration_file).SegmentDictionary()

			''' Init QAC module name '''
			self.modulenameOld = ""

			''' ------------------------------------------------------------------------- '''
			''' get the view name '''
			viewName = os.environ['BCMF_VIEWROOT']
			self.viewName = os.path.abspath(viewName)
			view_string = "View: " + self.viewName[3:]

			''' if WinIDEA used in the project: get WinIDEA local path '''
			self.GetWinideaLocalPath()
			
			''' read in all the commands from the configuration file					  '''

			''' store all the controls - variant independant '''
			if CFG_ECLIPSE in self.configuration:
				self.command_eclipse		   = "start " + self.configuration[CFG_ECLIPSE]
			
			if CFG_HELP_LINK in self.configuration:
				self.command_help_viewer	   = "start " + self.configuration[CFG_HELP_LINK]
			
			if CFG_RTA_OS in self.configuration:
				self.command_rtaos			 = "start " + self.configuration[CFG_RTA_OS] + " " + self.viewName
			
			self.command_post_analysis = qac_config[CFG_POST_ANALYSIS]
			self.command_cross_analysis = qac_config[CFG_CROSS_ANALYSIS]

				
			''' store all the controls - variant dependant '''

			''' loop through all the configuration options '''
			for control in self.configuration:

				''' loop through all the command prefixes '''
				for command in self.commandArray:

					''' if the current configuration has a matching prefix then store the options and
						process the next configuration '''
					if(control[0:len(command)] == command):
						self.commandArray[command][control[len(command):]] = self.configuration[control]

						break

			
			''' Instantiate the ecuversion functions '''
			''' Software version update function required? '''
			if CFG_ECUVERSION_MODULE in self.configuration:
				if self.configuration[CFG_ECUVERSION_MODULE] == CFG_REQUIRED:
					self.versionFcts = EcuVersions()
			
				
			''' ------------------------------------------------------------------------- '''
			''' setup the top level gui												   '''
			
			''' gui configuration parameters'''
			frame_borderwidth = 2
			frameHighlightThickness = 0
			frame_text_width = 20
			frame_text_width_right = 13
			frame_text_width_left = 15
			frame_column_width = 33
			button_width = 20
			build_button_width = 15
			button_height = 1
			padxFrame = 3
			padyFrame = 3
			padxLabelFrame = 5
			padyLabelFrame = 5
			
			
			''' setup the title of the window '''
			version_string = str(tool_version)
			project_string = self.configuration[CFG_PROJECT_NAME]
			__title = project_string + " - Toolchain " + version_string
			self.gui.title(__title)

			''' setup the main frames '''
			self.master_frame = Frame(self.gui)
			self.master_frame.grid(row=0, column=0)

			self.frame_left = Frame(self.master_frame)
			self.frame_left.grid(row=1, column=0, sticky=N)
			
			self.frame_middle = Frame(self.master_frame)
			self.frame_middle.grid(row=1, column=1, sticky=N)

			self.frame_right = Frame(self.master_frame)
			self.frame_right.grid(row=1, column=2, sticky=N)
			

			''' set up handling for closing the window '''
			self.gui.protocol("WM_DELETE_WINDOW", self.ShutGUIDown)


			''' ------------------------------------------------------------------------- '''
			''' Project frame '''
			self.project_frame = Frame(self.master_frame, borderwidth=frame_borderwidth, highlightthickness=frameHighlightThickness)
			self.project_frame.grid(row=0, column=0, columnspan=3, padx=padxFrame, pady=padyFrame)

			project_string = "Project: " + self.configuration[CFG_PROJECT_NAME]
			self.project_label = Label(self.project_frame, text=project_string, font=("Helvetica", 14))
			self.project_label.grid(row=0, column=0)

			self.view_label = Label(self.project_frame, text=self.viewName, wraplength=400, justify=CENTER)
			self.view_label.grid(row=1, column=0)

			microcontroller_string = "Target Microcontroller: " + self.configuration[CFG_PROJECT_MICRO]
			self.microcontroller_label = Label(self.project_frame, text=microcontroller_string)
			self.microcontroller_label.grid(row=2, column=0)

			

			''' ------------------------------------------------------------------------- '''
			''' Variant LabelFrame '''
			self.sw_variant_frame = LabelFrame(self.frame_left, text="Variant", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.sw_variant_frame.grid(row=0, column=0, padx=padxFrame, pady=padyFrame)

			''' variable that specified if a default varient was read from the configuration '''
			foundDefaultVariant = False

			''' variables used to configure the radio buttons '''
			self.variant_radiobutton = {}
			counter_row = 1
			counter_column = 0
			counter3 = 1

			''' create radio buttons with variant data from the configuration '''
			for variantName in variants:
				if(variants[variantName] == CFG_TAG_VARIANT):
					self.variant_radiobutton[counter3] = Radiobutton(self.sw_variant_frame, \
					text=variantName, variable=self.variantRadioGroup, value=variantName, anchor=W, \
					width=frame_text_width_left, command=self.UpdateGUI)
					self.variant_radiobutton[counter3].grid(row=counter_row, column=counter_column, sticky=W)
					

				elif(variants[variantName] == CFG_TAG_DEFAULTVARIANT):
					self.variant_radiobutton[counter3] = Radiobutton(self.sw_variant_frame, \
					text=variantName, variable=self.variantRadioGroup, value=variantName, anchor=W, \
					width=frame_text_width_left, command=self.UpdateGUI)
					self.variant_radiobutton[counter3].grid(row=counter_row, column=counter_column, sticky=W)
					self.variant_radiobutton[counter3].select() # widget init state
					self.previousVariant = variantName

					''' flag that default variant was found and update variable containing the last active variant '''
					foundDefaultVariant = True

				''' to print the variants on the 2 columns '''
				if ((counter3 % 2) == 0):
					counter_row = counter_row + 1
					counter_column = counter_column - 1
				else:
					counter_column = counter_column + 1
				counter3 = counter3 + 1

			''' check of no default variant was found '''
			if(foundDefaultVariant == False):

				''' when no default variant is found then set the last variant as the default '''
				self.variant_radiobutton[counter3-1].select()

			self.numberOfVariants = counter3
			
			
			''' ------------------------------------------------------------------------- '''
			''' Build Control LabelFrame '''
			self.build_frame = LabelFrame(self.frame_left, text="Build Control", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.build_frame.grid(row=1, column=0, padx=padxFrame, pady=padyFrame)
			self.build_frame.grid_remove()
			
			self.build_button_application = Button(self.build_frame, text="Build", width=build_button_width, height=button_height, command=self.BuildProjectApplication)
			self.build_button_application.config(state=NORMAL) # widget init value

			self.rebuild_button_application = Button(self.build_frame, text="Rebuild", width=build_button_width, height=button_height, command=self.RebuildProjectApplication)
			self.rebuild_button_application.config(state=NORMAL) # widget init value

			self.build_cancel_button_application = Button(self.build_frame, text="Cancel build", width=build_button_width, height=button_height, command=self.CancelBuildProjectApplication)
			self.build_cancel_button_application.config(state=DISABLED) # widget init value
			
			self.obuild_button_application = Button(self.build_frame, text="Omake Build", width=build_button_width, height=button_height, command=self.OmakeBuildProjectApplication)
			self.obuild_button_application.config(state=NORMAL) # widget init value
			
			self.orebuild_button_application = Button(self.build_frame, text="Omake Rebuild", width=build_button_width, height=button_height, command=self.OmakeRebuildProjectApplication)
			self.orebuild_button_application.config(state=NORMAL) # widget init value
			
			self.popup_build_button = Checkbutton(self.build_frame, text="Popup end of build", \
			variable=self.popupBuild, width=frame_text_width_left+padxFrame, anchor="w")
			self.popup_build_button.grid(row=0, column=0, sticky=W)
			if(self.configuration[CFG_POPUP_END_OF_BUILD] == CFG_ENABLED):
				self.popup_build_button.select()
			  
			self.delete_elf_button = Checkbutton(self.build_frame, text="Delete elf before build", \
			variable=self.deleteElf, width=frame_text_width_left+padxFrame, anchor="w")
			self.delete_elf_button.grid(row=1, column=0, sticky=W)
			self.delete_elf_button.select()
				
			self.check_stack_button = Checkbutton(self.build_frame, text="Stack Analysis", \
			variable=self.performStackCheck, width=frame_text_width_left+padxFrame, anchor="w")
			self.check_stack_button.grid(row=2, column=0, sticky=W)
			if(self.configuration[CFG_STACK_CHECKER_DEF] == CFG_ENABLED):
				self.check_stack_button.select()
				
			self.resource_checking_button = Checkbutton(self.build_frame, text="Resource Analysis", \
			variable=self.performResourceAnalysis, width=frame_text_width_left+padxFrame, anchor="w")
			self.resource_checking_button.grid(row=3, column=0, sticky=W)
			if(self.configuration[CFG_RESOURCE_ANALYSIS_DEF] == CFG_ENABLED):
				self.resource_checking_button.select()
				
			self.check_debug_flag = Checkbutton(self.build_frame, text="XMC Debug Mode", \
			variable=self.enableDebugFlag, width=frame_text_width_left+padxFrame, anchor="w")
			self.check_debug_flag.grid(row=4, column=0, sticky=W)
			self.check_debug_flag.deselect()
				
			self.open_resource_button = Button(self.build_frame, text="Resource results", width=build_button_width, height=button_height, command=self.OpenResourceAnalyseResults)
			self.open_resource_button.grid(row=3, column=1)
			self.open_resource_button.config(state=DISABLED) # widget init value
			
			self.merge_s19_file = Button(self.build_frame, text="Merge s19 files", width=build_button_width, height=button_height, command=self.MergingOutputFiles)
			self.merge_s19_file.grid(row=4, column=1)
			self.merge_s19_file.config(state=NORMAL)


			''' ------------------------------------------------------------------------- '''
			''' ECU SW Version Update LabelFrame '''
			self.sw_version_frame = LabelFrame(self.frame_left, borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, highlightcolor=Frame()['highlightbackground'], relief=RIDGE)
			self.sw_version_frame.grid(row=2, column=0, padx=padxFrame, pady=padyFrame)
			self.sw_version_frame.grid_remove() # widget init value
			
			self.version_updating_button = Checkbutton(self.sw_version_frame, text="ECU Software Version Update", \
			variable=self.autoVersionUpdate, width=2*frame_text_width_left+padxLabelFrame+1, anchor="w", command=self.UpdateGUI)
			self.version_updating_button.grid(row=0, column=0, sticky=W, columnspan=2)
			if CFG_VERSION_UPDATE_DEF in self.configuration:
				if(self.configuration[CFG_VERSION_UPDATE_DEF] == CFG_ENABLED):
					self.version_updating_button.select()
			self.version_updating_button.grid_remove() # widget init value
			
			self.sw_version_group_label = Label(self.sw_version_frame, text="  Major	 Minor   Revision", anchor=NW)
			self.sw_version_group_label.grid(row=1, column=0, sticky=W)

			
			'''Frame for Entries'''
			self.entry_frame = Frame(self.sw_version_frame, borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE)
			self.entry_frame.grid(row=2, column=0, padx=padxFrame, pady=padyFrame, sticky=W)
			
			''' add the major version field '''
			self.major_version_entry = Entry(self.entry_frame, width=button_width/3)
			self.major_version_entry.grid(row=0, column=0, sticky=W)
			self.major_version_entry.config(state=NORMAL) # widget init value

			''' add the minor version fields '''
			self.minor_version_entry = Entry(self.entry_frame, width=button_width/3)
			self.minor_version_entry.grid(row=0, column=1, sticky=W)
			self.minor_version_entry.config(state=NORMAL) # widget init value

			''' add the revision version fields '''
			self.revision_version_entry = Entry(self.entry_frame, width=button_width/3)
			self.revision_version_entry.grid(row=0, column=2, sticky=W)
			self.revision_version_entry.config(state=NORMAL) # widget init value
			

			''' ------------------------------------------------------------------------- '''
			''' Tools Version frame '''
			self.toolver_frame = Frame(self.frame_left, borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE)
			self.toolver_frame.grid(row=3, column=0, padx=padxFrame, pady=padyFrame)

			''' create place holders for tool versions '''
			self.versions = ToolVersions(self.version_configuration_file)

			self.toolversion_label = {}
			counter_row = 1
			counter_column = 0
			counter3 = 1

			''' add all the version strings to the gui '''
			for element in self.versions.ExpectedVersionReport():

				element_text = element

				'''visual adaptation'''
				if ((counter3 % 2) == 0):
					self.toolversion_label[element] = Label(self.toolver_frame, text=element, \
					fg=VERSION_OK, width=frame_text_width, anchor=W)
				else:
					self.toolversion_label[element] = Label(self.toolver_frame, text=element, \
					fg=VERSION_OK, width=frame_text_width-1, anchor=W)
				self.toolversion_label[element].grid(row=counter_row, column=counter_column)

				''' to print the versions on the 2 columns'''
				if ((counter3 % 2) == 0):
					counter_row = counter_row + 1
					counter_column = counter_column - 1
				else:
					counter_column = counter_column + 1
				counter3 = counter3 + 1

			''' field which can contain information about tool status (ex "to update", "not installed"...)'''
			''' the data are received from the versions.py scripts '''
			self.tools_information = StringVar()
			self.tools_information_label = Label(self.toolver_frame, textvariable=self.tools_information, \
			width=2*frame_text_width, background='white', justify=LEFT, anchor=W)
			self.tools_information_label.grid(row=counter_row+1, column=0, columnspan=2)
			self.tools_information_label.grid_remove() # widget init state
			
			''' initial test for all the tool versions '''
			self.TestVersion()
			
			
			''' ------------------------------------------------------------------------- '''
			''' On-Chip Debugging LabelFrame '''
			self.editor_frame = LabelFrame(self.frame_middle, text="On-Chip Debugging", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.editor_frame.grid(row=0, column=0, padx=padxFrame, pady=padyFrame)
			self.editor_frame.grid_remove()

			self.debugger_button = Button(self.editor_frame, text="Debugger", width=button_width, height=button_height, command=self.DebuggerExecute)
			self.debugger_button.grid(row=1, column=1, columnspan=2)
			self.debugger_button.config(state=DISABLED) # widget init value
			
			self.logger_button = Button(self.editor_frame, text="BCMF Logger", width=button_width, height=button_height, command=self.LoggerExecute)
			self.logger_button.grid(row=2, column=1, columnspan=2)
			self.logger_button.config(state=DISABLED) # widget init value
			
			self.profiler_button = Button(self.editor_frame, text="Profiler", width=button_width-5, height=button_height, command=self.ProfilerExecute)
			self.profiler_button.grid(row=3, column=1, columnspan=2, sticky=W)
			self.profiler_button.config(state=DISABLED) # widget init value
			self.profiler_button.grid_remove()
			
			self.profiler_help_button = Button(self.editor_frame, text="?", width=3, height=button_height, foreground="MediumBlue", command=self.ProfilerHowToExecute)
			self.profiler_help_button.grid(row=3, column=2, sticky=E)
			self.profiler_help_button.config(state=DISABLED) # widget init value
			self.profiler_help_button.grid_remove()
			
			self.codecoverage_button = Button(self.editor_frame, text="Code Coverage", width=button_width, height=button_height, command=self.CodeCoverageExecute)
			self.codecoverage_button.grid(row=4, column=1, columnspan=2)
			self.codecoverage_button.config(state=DISABLED) # widget init value
			self.codecoverage_button.grid_remove()

			
			''' ------------------------------------------------------------------------- '''
			''' Project specific tools LabelFrame '''
			self.project_specific_tools_frame = LabelFrame(self.frame_middle, text="Project specific", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.project_specific_tools_frame.grid(row=1, column=0, padx=padxFrame, pady=padyFrame)
			self.project_specific_tools_frame.grid_remove()

			
			self.eclipse_button = Button(self.project_specific_tools_frame, text="Eclipse", width=button_width, \
			height=button_height, command=self.EclipseExecute)
			self.eclipse_button.config(state=DISABLED) # widget init value
			
			self.os_generator_button = Button(self.project_specific_tools_frame, text="OS generator", width=button_width, height=button_height, command=self.RtaOsBuilder)
			self.os_generator_button.config(state=NORMAL) # widget init value

			'''M File Generator Button'''
			self.mfile_gen_button = Button(self.project_specific_tools_frame, text="M files generator", width=button_width, height=button_height, command=self.GenerateMFiles)
			self.mfile_gen_button.config(state=NORMAL) # widget init value
					 
			''' create the buttons '''
			
			''' the buttons are dynamically created according to the project configuration '''
			self.specific_tools_button = {}
			
			''' number of tools to be added to the GUI '''
			self.number_of_specific_tools = int(self.configuration[CFG_NUMBER_SPECIFIC_TOOLS])
			if self.number_of_specific_tools > MAX_SPECIFIC_TOOLS:
				self.number_of_specific_tools = MAX_SPECIFIC_TOOLS
			
			for tool_index in range(1,self.number_of_specific_tools+1):
				specific_tool_name = self.configuration[CFG_PREFIX_SPEC_TOOL_NAME + str(tool_index)]
				if specific_tool_name != CFG_NOT_REQUIRED:
					self.specific_tools_button[tool_index] = Button(self.project_specific_tools_frame, text=specific_tool_name, width=button_width, height=button_height, command=lambda i=tool_index: self.SpecificToolExecution(i))
					self.specific_tools_button[tool_index].grid(row=tool_index+2, column=1)
					self.specific_tools_button[tool_index].config(state=NORMAL) # widget init value
					
			
			''' ------------------------------------------------------------------------- '''
			''' Documentation LabelFrame '''
			self.doc_frame = LabelFrame(self.frame_middle, text="Documentation", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.doc_frame.grid(row=3, column=0, padx=padxFrame, pady=padyFrame)
			self.doc_frame.grid_remove()

			self.generate_doc_button = Button(self.doc_frame, text="Generate", width=button_width, height=button_height, command=self.GenerateDocumentation)
			self.generate_doc_button.grid(row=0, column=1)
			self.generate_doc_button.config(state=NORMAL) # widget init value

			self.view_helpdoc_button = Button(self.doc_frame, text="View HELP", width=button_width, height=button_height, command=self.ViewHELPDocumentation)
			self.view_helpdoc_button.grid(row=1, column=1)
			self.view_helpdoc_button.config(state=NORMAL) # widget init value
			
			
			''' ------------------------------------------------------------------------- '''
			''' Analysis LabelFrame '''
			'''QAC project analysis'''
			self.qac_project_analysis_frame = LabelFrame(self.frame_right, text="QAC Project analysis", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.qac_project_analysis_frame.grid(row=0, column=0, padx=padxFrame, pady=padyFrame)
			self.qac_project_analysis_frame.grid_remove()

			self.qacanalysis_all_button = Button(self.qac_project_analysis_frame, text="Analysis Project", width=button_width, height=button_height, command=self.QACAnalysisAll)
			self.qacanalysis_all_button.grid(row=0, column=1)
			self.qacanalysis_all_button.config(state=DISABLED) # widget init value

			self.qacview_all_button = Button(self.qac_project_analysis_frame, text="View Project", width=button_width, height=button_height, command=self.QACViewAll)
			self.qacview_all_button.grid(row=1, column=1)
			self.qacview_all_button.config(state=DISABLED) # widget init value
			
			self.only_third_party_analysis_button = Checkbutton(self.qac_project_analysis_frame, text="Only 3rd party SW", variable=self.onlyThirdPartyAnalysis, command=self.UpdateGUI)
			self.only_third_party_analysis_button.grid(row=2, column=1, sticky=W)
			self.only_third_party_analysis_button.config(state=DISABLED) # widget init value
			
			self.include_third_party_analysis_button = Checkbutton(self.qac_project_analysis_frame, text="Include 3rd party SW", variable=self.includeThirdPartyAnalysis, command=self.UpdateGUI)
			self.include_third_party_analysis_button.grid(row=3, column=1, sticky=W)
			self.include_third_party_analysis_button.config(state=DISABLED) # widget init value
			
			self.post_analysis_button = Checkbutton(self.qac_project_analysis_frame, text="Generate report", variable=self.performPostAnalysis)
			self.post_analysis_button.grid(row=4, column=1, sticky=W)
			self.post_analysis_button.config(state=DISABLED) # widget init value
			
			self.cross_analysis_button = Checkbutton(self.qac_project_analysis_frame, text="CMA analysis", variable=self.performCrossAnalysis)
			self.cross_analysis_button.grid(row=5, column=1, sticky=W)
			self.cross_analysis_button.select()
			self.cross_analysis_button.config(state=DISABLED) # widget init value
			
			
			'''QAC module analysis'''
			self.qac_module_analysis_frame = LabelFrame(self.frame_right, text="QAC Module analysis", borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
			self.qac_module_analysis_frame.grid(row=1, column=0, padx=padxFrame, pady=padyFrame)
			self.qac_module_analysis_frame.grid_remove()

			self.qacanalysis_mod_button = Button(self.qac_module_analysis_frame, text="Analysis Module", width=button_width, height=button_height, command=self.QACAnalysisMod)
			self.qacanalysis_mod_button.grid(row=6, column=1)
			self.qacanalysis_mod_button.config(state=DISABLED) # widget init value

			self.qacviewer_mod_button = Button(self.qac_module_analysis_frame, text="View Module", width=button_width, height=button_height, command=self.QACViewerMod)
			self.qacviewer_mod_button.grid(row=7, column=1)
			self.qacviewer_mod_button.config(state=DISABLED) # widget init value
			
			self.qacmetrics_mod_button = Button(self.qac_module_analysis_frame, text="View Metrics", width=button_width, height=button_height, command=self.QACMetricsMod)
			self.qacmetrics_mod_button.grid(row=8, column=1)
			self.qacmetrics_mod_button.config(state=DISABLED) # widget init value

			''' setup the list for modules in the selection menu '''
			self.moduleList = ""
			self.moduleName = StringVar()
			self.moduleName.set("Select Module")
			self.mb_toplevel = Menubutton(self.qac_module_analysis_frame, textvariable=self.moduleName, width=button_width-1, height=button_height-2, relief=RAISED)
			self.mb_toplevel.menu = Menu ( self.mb_toplevel, tearoff=0 )
			self.mb_toplevel["menu"] = self.mb_toplevel.menu
			self.mb_toplevel.grid(row=9, column=1)
			self.mb_toplevel.config(state=DISABLED) # widget init value
			
			self.filter_dependencies_button = Checkbutton(self.qac_module_analysis_frame, text="Only consider module\ndependencies", justify=LEFT, variable=self.filterDependencies, command=self.UpdateGUI)
			self.filter_dependencies_button.grid(row=10, column=1, rowspan=2)
			self.filter_dependencies_button.select() # widget init state
			self.filter_dependencies_button.config(state=DISABLED) # widget init value
			
			
			''' ------------------------------------------------------------------------- '''
			''' Update Tools LabelFrame '''
			if self.configuration[CFG_QAC_MODULE] == CFG_REQUIRED:
				self.update_tools_frame = LabelFrame(self.frame_right, text="Update", borderwidth=frame_borderwidth, \
				highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
				self.update_tools_frame.grid(row=2, column=0, padx=padxFrame, pady=padyFrame)
			else:
				self.update_tools_frame = LabelFrame(self.frame_middle, text="Update", borderwidth=frame_borderwidth, \
				highlightthickness=frameHighlightThickness, relief=RIDGE, padx=padxLabelFrame, pady=padyLabelFrame)
				self.update_tools_frame.grid(row=6, column=0, padx=padxFrame, pady=padyFrame) 
			
			self.WinIdea_install_button = Button(self.update_tools_frame, text="Install WinIDEA", width=button_width, height=button_height, \
			foreground="red", command=self.InstallWinIdea)
			self.WinIdea_install_button.grid(row=counter_row+1, column=0)
			self.WinIdea_install_button.grid_remove() # widget init value

			self.WinIdea_update_button = Button(self.update_tools_frame, text="Update WinIDEA", width=button_width, height=button_height, \
			foreground="red", command=self.UpdateWinIdea)
			self.WinIdea_update_button.grid(row=counter_row+1, column=0)
			self.WinIdea_update_button.grid_remove() # widget init value


			''' ------------------------------------------------------------------------- '''
			''' Status frame and toolbar'''
			self.status_frame = Frame(self.master_frame, borderwidth=frame_borderwidth, \
			highlightthickness=frameHighlightThickness, relief=RIDGE)
			self.status_frame.grid(row=2, column=0, padx=padxFrame, pady=padyFrame, columnspan=3, sticky=W)

			'''configure width of status bar (3 or 2 columns)'''
			if self.configuration[CFG_QAC_MODULE] == CFG_REQUIRED:
				status_bar_coeff = 2
			else:
				status_bar_coeff = 1
			
			''' define variable to store text for status bar '''
			self.actual_status = StringVar()
			self.actual_status.set("Builder Idle...")
			self.status_label = Label(self.status_frame, textvariable=self.actual_status, \
			width=2*frame_text_width + status_bar_coeff*(button_width+padxLabelFrame) + 1, anchor=NW, background='white')
			self.status_label.grid(row=0, column=0)

			self.toolbar = Frame(self.status_frame, padx=0, pady=0)
			self.toolbar.grid(row=0, column=0, sticky=E)
			
			self.clear_screen_button = Button(self.toolbar, text="Clear Console", width=11, \
			height=button_height, command=self.ClearStatusScreen)
			self.clear_screen_button.grid(row=0, column=4)

			self.help_button = Button(self.toolbar, text="Help", width=6, \
			height=button_height, command=self.Help)
			self.help_button.grid(row=0, column=3)

			self.news_button = Button(self.toolbar, text='What\'s new?', width=11, \
			height=button_height, command=self.WhatsNew)
			self.news_button.grid(row=0, column=2)
		   
			
			''' configure the tool chain components according to the configuration '''
			self.ActivateToolChainComponents()
			
			
			
			''' --------------------------------------------------------------------------- '''
			''' Scan the source and include directories if:								 '''
			''' - the parser is required for Eclipse										'''
			''' OR																		  '''
			''' - QAC is used in the project: used to create the module list				'''
			self.newSourceDirectory = ThreadedGetSourceDirectoryListing(self.sourceDir, self.commandArray, self.configuration_file, \
			self.component_QAC_active, self.component_QAC_PARSER_OPT_active)
			if (self.component_QAC_active == True) | (self.component_ECLIPSE_PARSER_active == True):
				self.newSourceDirectory.threadRunning = True
				self.newSourceDirectory.setName("ThreadedGetSourceDirectoryListing")
				self.newSourceDirectory.setDaemon(True)
				self.newSourceDirectory.start()
			''' --------------------------------------------------------------------------- '''
			
			
			self.gui.resizable(False,False)


		except KeyError, detail:
			''' catch the errors when a configuration option is missing form the file '''

			error_message = "Following configuration needs to be added: " + str(detail)

			print "\n" + "-" * len(error_message)
			print "Error:"
			print error_message
			print "-" * len(error_message) + "\n"

			''' stop the program as this error is fatal '''
			raise
			
	 
	 
	# ------------------------------------------------------------------------------
	# Function used to activate the GUI components which are per default deactivated
	#	 The components are activated according to the GUI configuration
	# ------------------------------------------------------------------------------
	def ActivateToolChainComponents(self):

		''' Per default all components are not activated '''
		self.component_BUILD_active = False
		self.component_OBUILD_active = False
		self.component_QAC_active = False
		self.component_QAC_PARSER_active = False
		self.component_QAC_PARSER_OPT_active = False
		self.component_EMULATOR_active = False
		self.component_PROFILER_active = False
		self.component_CODECOVERAGE_active = False
		self.component_ECLIPSE_active = False
		self.component_ECLIPSE_PARSER_active = False
		self.component_OSGEN_active = False
		self.component_MFILEGEN_active = False
		self.component_DOCUGEN_active = False
		self.component_ECUVERSION_active = False
		self.component_NEWS_active = False
		
	
		''' build frame ----------------------------------------------------------'''
		__numberOfBuilders = 0
		
		''' BUILD '''
		if CFG_BUILD_MODULE in self.configuration:
			if (self.configuration[CFG_BUILD_MODULE] == CFG_REQUIRED):
				self.component_BUILD_active = True
				self.build_frame.grid()
				self.build_button_application.grid(row=__numberOfBuilders, column=1)
				__numberOfBuilders += 1
				self.rebuild_button_application.grid(row=__numberOfBuilders, column=1)
				__numberOfBuilders += 1
				self.build_cancel_button_application.grid(row=__numberOfBuilders, column=1)
				__numberOfBuilders += 1
		
		''' OBUILD '''
		if CFG_OBUILD_MODULE in self.configuration:
			if (self.configuration[CFG_OBUILD_MODULE] == CFG_REQUIRED):
				self.component_OBUILD_active = True
				self.build_frame.grid()
				self.obuild_button_application.grid(row=__numberOfBuilders, column=1)
				__numberOfBuilders += 1
				self.orebuild_button_application.grid(row=__numberOfBuilders, column=1)
				__numberOfBuilders += 1
		
		''' editor frame ---------------------------------------------------------'''
		__numberOfEditors = 0

		
		''' EMULATOR + Logger'''
		''' Only if emulator is enabled the functionality of profiler, code coverage and bcmf logger is also enabled '''
		if (self.configuration[CFG_EMULATOR_MODULE] == CFG_REQUIRED):
			if CFG_EMULATOR_MODULE in self.configuration:
				if (self.configuration[CFG_EMULATOR_MODULE] == CFG_REQUIRED):
					self.component_EMULATOR_active = True
					self.editor_frame.grid()
					self.debugger_button.grid()
					self.logger_button.grid()
				
		''' Profiler '''
		if (self.configuration[CFG_EMULATOR_MODULE] == CFG_REQUIRED):
			if CFG_PROFILER_MODULE in self.configuration:
				if (self.configuration[CFG_PROFILER_MODULE] == CFG_REQUIRED):
					self.component_PROFILER_active = True
					self.profiler_button.grid()
					self.profiler_help_button.grid()
				
		''' Code Coverage '''
		if (self.configuration[CFG_EMULATOR_MODULE] == CFG_REQUIRED):
			if CFG_CODECOVERAGE_MODULE in self.configuration:
				if (self.configuration[CFG_CODECOVERAGE_MODULE] == CFG_REQUIRED):
					self.component_CODECOVERAGE_active = True
					self.codecoverage_button.grid()

		
		''' QAC ------------------------------------------------------------------'''
		if CFG_QAC_MODULE in self.configuration:
			if self.configuration[CFG_QAC_MODULE] == CFG_REQUIRED:
				self.component_QAC_active = True
				self.qac_project_analysis_frame.grid()
				self.qac_module_analysis_frame.grid()
			''' QAC parser ''' 
			if CFG_QAC_DIRECTORY_PARSER in self.configuration:
				if self.configuration[CFG_QAC_DIRECTORY_PARSER] == CFG_ENABLED:
					self.component_QAC_PARSER_active = True
			''' GHS parser optimisation '''
			if CFG_DIRECTORY_PARSER_OPTIMISATION in self.configuration:
				if self.configuration[CFG_DIRECTORY_PARSER_OPTIMISATION] == "GHS":
					self.component_QAC_PARSER_OPT_active = "GHS"
				# add cases here if new parser optimizer are available
				elif self.configuration[CFG_DIRECTORY_PARSER_OPTIMISATION] == "NONE":
					self.component_QAC_PARSER_OPT_active = False

		''' documentation frame---------------------------------------------------'''
		if CFG_DOCU_GENERATOR_MODULE in self.configuration:
			if (self.configuration[CFG_DOCU_GENERATOR_MODULE] == CFG_REQUIRED):
				self.component_DOCUGEN_active = True
				self.doc_frame.grid()
			
		''' project specific tools------------------------------------------------'''
		
		__numberOfGenerators = 0
				
		''' Eclipse '''
		if CFG_ECLIPSE_MODULE in self.configuration:
			if (self.configuration[CFG_ECLIPSE_MODULE] == CFG_REQUIRED):
				self.component_ECLIPSE_active = True
				self.eclipse_button.grid(row=__numberOfGenerators, column=1)
				__numberOfGenerators += 1
			''' Eclipse parser '''
			if CFG_ECLIPSE_DIRECTORY_PARSER in self.configuration:
				if (self.configuration[CFG_ECLIPSE_DIRECTORY_PARSER] == CFG_ENABLED):
					self.component_ECLIPSE_PARSER_active = True
			
		''' OS Generator '''
		if CFG_OS_GENERATOR_MODULE in self.configuration:
			if (self.configuration[CFG_OS_GENERATOR_MODULE] == CFG_REQUIRED):
				self.component_OSGEN_active = True
				self.project_specific_tools_frame.grid()
				self.os_generator_button.grid(row=__numberOfGenerators, column=1)
				__numberOfGenerators += 1
			
		''' M File Generator '''
		if CFG_M_FILE_GENERATOR_MODULE in self.configuration:
			if (self.configuration[CFG_M_FILE_GENERATOR_MODULE] == CFG_REQUIRED):
				self.component_MFILEGEN_active = True
				self.project_specific_tools_frame.grid()
				self.mfile_gen_button.grid(row=__numberOfGenerators, column=1)
				__numberOfGenerators += 1
				
		specific_tool_present = False
		for tool_index in range(1,self.number_of_specific_tools+1):
			specific_tool_name = self.configuration[CFG_PREFIX_SPEC_TOOL_NAME + str(tool_index)]
			if specific_tool_name != CFG_NOT_REQUIRED:
				''' there is at least on specific tool, we can activate the frame '''
				specific_tool_present = True
		if specific_tool_present == True:
			self.project_specific_tools_frame.grid()
			
		''' ECU version update----------------------------------------------------'''
		if CFG_ECUVERSION_MODULE in self.configuration:
			if (self.configuration[CFG_ECUVERSION_MODULE] == CFG_REQUIRED):
				self.component_ECUVERSION_active = True
				self.sw_version_frame.grid()
				self.version_updating_button.grid()
			
		''' GUI version frame-----------------------------------------------------'''
		if CFG_NEWS_POPUP in self.configuration:
			if (self.configuration[CFG_NEWS_POPUP] == CFG_ENABLED):
				self.component_NEWS_active = True
				self.news_button.grid()
			
			
	# -------------------------------------------------------------------------
	# Function which is called when clicking on a project specific tool button
	# -------------------------------------------------------------------------
	def SpecificToolExecution(self, tool_index):
	
		specific_tool_command = self.configuration[CFG_PREFIX_SPEC_TOOL_BATCH + str(tool_index)]
		specific_tool_name = self.configuration[CFG_PREFIX_SPEC_TOOL_NAME + str(tool_index)]
		
		self.PrintVariantDOSLabel("Execute " + specific_tool_name, False)
		self.actual_status.set("Starting " + specific_tool_name + "...")
		self.ExecuteSingleOSThread("start " + specific_tool_command)
		
		
		
	# -------------------------------------------------------------------------
	# Function to be called to set the list of QAC modules up.
	# -------------------------------------------------------------------------
	def UpdateQACModules(self, modules):

		''' extract all of the modules from the list and put them into the gui select box '''
		for element in modules:
			self.mb_toplevel.menu.add_radiobutton ( label=element, variable=self.moduleName, value=element)

		''' automatically set the module to the first module '''
		self.moduleName.set(modules[0])
		
		

	# -------------------------------------------------------------------------
	# Function to execute a single os command in a thread and make sure the
	# gui is refreshed while it is executing.
	# -------------------------------------------------------------------------

	def ExecuteSingleOSThread(self, command):

		''' setup the os command thread '''
		self.newThreadedOSCommand = ThreadedExecuteOSCommand(command)
		self.newThreadedOSCommand.setName("ExecuteSingleOSThread")
		self.newThreadedOSCommand.setDaemon(True)
		self.newThreadedOSCommand.start()

		''' wait for the os thread to finish. prevents 2 threads to run at once. '''
		while(os_thread_active):
			time.sleep(0.25)

			try:
				''' update_idletasks is suggested but does not redraw window properly.
					therefore controls are disabled when buttons are pushed and update used. '''
				self.gui.update()

			except BaseException, detail:
				''' for all exceptions assume gui is closing and ignore.
					the os commands are not killed here and are allowed to finish. '''



	# -------------------------------------------------------------------------
	# Function executes test of all applicable tool versions. If the version is
	# correct the version is displayed in one colour and if it is incorrect a
	# WRONG! message is displayed in another colour.
	# -------------------------------------------------------------------------

	def TestVersion(self):
		self.versions.ReCheck(self.version_configuration_file)

		''' check all applicable tool versions '''
		for element in self.versions.VersionReport():

			if self.versions.VersionReport()[element] == True:
				version_string = element + ": " + self.versions.ExpectedVersionReport()[element]
				self.toolversion_label[element]['fg'] = VERSION_OK

			else:
				version_string = element + ": " + "WRONG!"
				self.toolversion_label[element]['fg'] = VERSION_NOT_OK

			self.toolversion_label[element]['text'] = version_string
			
		''' check if there is tool information to print '''
		str_tmp = ""
		for element in self.versions.GetToolInformation():
			if self.versions.GetToolInformation()[element] != "":
				self.tools_information_label.grid()
				str_tmp = str_tmp + self.versions.GetToolInformation()[element] + "\n"
		
		self.tools_information.set(str_tmp[:-1])
	   

			
	# -------------------------------------------------------------------------
	# Function to generically check that a software version entry is in the
	# correct form. I.e. number 0-9, letter a-z or A-Z, 4 characters.
	# -------------------------------------------------------------------------

	def CheckIndividualVersionFormat(self, versionString, versionName):

		''' make sure the format of the software version is ok '''
		if (len(versionString) <> 4) or (re.search("[^0-9a-zA-Z]", versionString)):
			return_value = False

			print "Incorrect " + versionName + " Version Format..."
			tkMessageBox.showerror("ECU " + versionName + " Software Version Error", versionName + " Format Incorrect. Version Must:\n\n1. Contain Only Characters A-Z and 0-9.\n2. Have A Length Of 4 Characters.")

		else:
			return_value = True

		return return_value



	# -------------------------------------------------------------------------
	# Function to check all software version components (major, minor,
	# revision)
	# -------------------------------------------------------------------------

	def CheckECUSoftwareVersion(self):

		''' one negative test is enought to return and declare the version as not valid '''
	
		''' Mojor field check '''
		if (self.commandArray[CFG_PREFIX_USEMAJOR][self.variantRadioGroup.get()] == CFG_ENABLED):
			if (False == self.CheckIndividualVersionFormat(self.major_version_entry.get(), "Major")):
				return False
				
		''' Minor field check '''
		if (self.commandArray[CFG_PREFIX_USEMINOR][self.variantRadioGroup.get()] == CFG_ENABLED):
			if (False == self.CheckIndividualVersionFormat(self.minor_version_entry.get(), "Minor")):
				return False
				
		''' Revision field check '''
		if (self.commandArray[CFG_PREFIX_USEREV][self.variantRadioGroup.get()] == CFG_ENABLED):
			if (False == self.CheckIndividualVersionFormat(self.revision_version_entry.get(), "Revision")):
				return False

		return True


	# -------------------------------------------------------------------------
	# Function to print a DOS status window message either with or without
	# displaying the variant.
	# -------------------------------------------------------------------------

	def PrintVariantDOSLabel(self, text, variantDisplay):
		if(variantDisplay == True):
			labelTextLine1 = text + " - " + self.variantRadioGroup.get() + "..."
		else:
			labelTextLine1 = text + "..."

		labelTextLine2 = self.viewName

		textLength = len(labelTextLine1)

		if(len(labelTextLine2) > len(labelTextLine1)):
			textLength = len(labelTextLine2)

		print " "
		print "-" * textLength
		print labelTextLine1
		print labelTextLine2
		print "-" * textLength
	
	
	
	# -------------------------------------------------------------------------
	# Function to update the GUI (GUI change, variant change) 
	# Can also disable the whole GUI while building for example
	# -------------------------------------------------------------------------

	def UpdateGUI(self):

		if self.controls_enabled == True:
			
			''' the settings should not be saved at GUI startup (first run in this function) '''
			if self.firstRunUpdateGUI == False:
				self.SaveUserGUISettings(self.previousVariant)
			
			''' first run done '''
			self.firstRunUpdateGUI = False
			
			''' ------------------------------------------------------------------------- '''
			''' Variant radio buttons  '''
			for i in range(1,self.numberOfVariants):
				self.variant_radiobutton[i].config(state=NORMAL)
		
		
			''' ------------------------------------------------------------------------- '''
			''' ECU version management '''
			if self.component_ECUVERSION_active == True:
				''' the user has the possibiliy to check the version even if he does not want to update it  '''
				''' the fields which are not required are not totally removed from the GUI:
					they can be required for another variant '''
					
				''' check if any field of the selected variant is enabled: if not, disable the checkbox '''
				if(self.commandArray[CFG_PREFIX_USEMAJOR][self.variantRadioGroup.get()] == CFG_DISABLED) &\
				(self.commandArray[CFG_PREFIX_USEMINOR][self.variantRadioGroup.get()] == CFG_DISABLED) &\
				(self.commandArray[CFG_PREFIX_USEREV][self.variantRadioGroup.get()] == CFG_DISABLED):
					self.version_updating_button.deselect()
					self.version_updating_button.config(state=DISABLED)
				else:
					self.version_updating_button.config(state=NORMAL)
					''' load user setting for the checkbox '''					
					self.LoadUserSettings(3)
					self.versionFcts.UpdateVersionFromFile(self.commandArray[CFG_PREFIX_ECUVERCFG][self.variantRadioGroup.get()])				 
				
				''' the methods delete and insert can be used only if the entry state is "NORMAL" !!!! '''
				
				''' major field state: - normal or disable according to the variant configuration '''
				'''					- readonly if the update is not required '''
				''' reset the field '''
				self.major_version_entry.config(state=NORMAL)
				self.major_version_entry.delete(0, END)
				if(self.commandArray[CFG_PREFIX_USEMAJOR][self.variantRadioGroup.get()] == CFG_ENABLED):
					self.major_version_entry.delete(0, END)
					self.major_version_entry.insert(0, self.versionFcts.GetSwVersionMajor())
					if self.autoVersionUpdate.get() == 0:
						self.major_version_entry.config(state="readonly")
				else:
					self.major_version_entry.config(state=DISABLED)

				
				''' minor field state: - normal or disable according to the variant configuration '''
				'''					- readonly if the update is not required '''
				''' reset the field '''
				self.minor_version_entry.config(state=NORMAL)
				self.minor_version_entry.delete(0, END)
				if(self.commandArray[CFG_PREFIX_USEMINOR][self.variantRadioGroup.get()] == CFG_ENABLED):
					self.minor_version_entry.delete(0, END)
					self.minor_version_entry.insert(0, self.versionFcts.GetSwVersionMinor())
					if self.autoVersionUpdate.get() == 0:
						self.minor_version_entry.config(state="readonly")
				else:
					self.minor_version_entry.config(state=DISABLED)

					
				''' revision field state: - normal or disable according to the variant configuration '''
				'''					   - readonly if the update is not required '''
				''' reset the field '''
				self.revision_version_entry.config(state=NORMAL)
				self.revision_version_entry.delete(0, END)
				if(self.commandArray[CFG_PREFIX_USEREV][self.variantRadioGroup.get()] == CFG_ENABLED):
					self.revision_version_entry.delete(0, END)
					self.revision_version_entry.insert(0, self.versionFcts.GetSwVersionRev())
					if self.autoVersionUpdate.get() == 0:
						self.revision_version_entry.config(state="readonly")
				else:
					self.revision_version_entry.config(state=DISABLED)
				
				
			''' ------------------------------------------------------------------------- '''
			''' QAC panel management '''
			if self.component_QAC_active == True:
				''' enable QAC buttons if QAC analysis is configured '''
				''' enable QAC buttons only if the include list is ready '''
				
				if self.newSourceDirectory.threadRunning == True:
					''' the list is not ready '''
					self.qacanalysis_all_button.config(state=DISABLED)
					self.post_analysis_button.config(state=DISABLED)
					self.cross_analysis_button.config(state=DISABLED)
					self.only_third_party_analysis_button.config(state=DISABLED)
					self.include_third_party_analysis_button.config(state=DISABLED)
					self.qacview_all_button.config(state=DISABLED)
					self.qacanalysis_mod_button.config(state=DISABLED)
					self.qacviewer_mod_button.config(state=DISABLED)
					self.qacmetrics_mod_button.config(state=DISABLED)
					self.mb_toplevel.config(state=DISABLED)
					self.filter_dependencies_button.config(state=DISABLED)
				
				else:
					''' the list is ready '''
					''' project analysis '''
					if (self.commandArray[CFG_PREFIX_QACALL][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_QACALL][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
						self.qacanalysis_all_button.config(state=DISABLED)
						self.post_analysis_button.config(state=DISABLED)
						self.cross_analysis_button.config(state=DISABLED)
						self.only_third_party_analysis_button.config(state=DISABLED)
						self.include_third_party_analysis_button.config(state=DISABLED)
					else:
						''' the post and cross analysis buttons are activated according to the third party analysis button '''
						''' the "include third party" button is not available if third party is selected '''
						if self.onlyThirdPartyAnalysis.get() == 1:
							self.include_third_party_analysis_button.deselect()
							self.include_third_party_analysis_button.config(state=DISABLED)
							self.post_analysis_button.deselect()
							self.post_analysis_button.config(state=DISABLED)
							self.cross_analysis_button.deselect()
							self.cross_analysis_button.config(state=DISABLED)
						else:
							self.include_third_party_analysis_button.config(state=NORMAL)
							self.post_analysis_button.config(state=NORMAL)
							self.cross_analysis_button.config(state=NORMAL)
						self.qacanalysis_all_button.config(state=NORMAL)
						self.only_third_party_analysis_button.config(state=NORMAL)

					''' project viewer '''
					if (self.commandArray[CFG_PREFIX_QACVIEW][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_QACVIEW][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
						self.qacview_all_button.config(state=DISABLED)
					else:
						self.qacview_all_button.config(state=NORMAL)

					''' module analysis '''
					if (self.commandArray[CFG_PREFIX_QACMOD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_QACMOD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
						self.qacanalysis_mod_button.config(state=DISABLED)
						self.mb_toplevel.config(state=DISABLED)
						self.filter_dependencies_button.config(state=DISABLED)
					else:
						self.qacanalysis_mod_button.config(state=NORMAL)
						self.mb_toplevel.config(state=NORMAL)
						self.filter_dependencies_button.config(state=NORMAL)

					''' module viewer '''
					if (self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
						self.qacviewer_mod_button.config(state=DISABLED)
					else:
						self.qacviewer_mod_button.config(state=NORMAL)
						
					''' metrics results '''
					if (self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
						self.qacmetrics_mod_button.config(state=DISABLED)
					else:
						if os.path.exists(self.metricsAnalysisResultFile) == True:
							self.qacmetrics_mod_button.config(state=NORMAL)
						else:
							self.qacmetrics_mod_button.config(state=DISABLED)
					
				''' filter dependencies checkbox state: if the state changes, the QAC temp files can be updated '''
				self.filter_dependencies_button_state_old = self.filter_dependencies_button_state
				self.filter_dependencies_button_state = self.filterDependencies.get()
				
			''' ------------------------------------------------------------------------- '''
			''' Eclipse button management '''
			''' enable Eclipse button if Eclipse enabled '''
			''' enable Eclipse button if		'''
			if self.component_ECLIPSE_active == True:
				if self.EclipseStartSuspended == True:
					self.eclipse_button.config(state=DISABLED)
				else:
					self.eclipse_button.config(state=NORMAL)
				
			''' ------------------------------------------------------------------------- '''
			''' emulator install buttons management '''
			''' check if a tool action is required; ex install or update '''
			''' the info is get from the module versions.py '''
			if "WinIDEA" in self.versions.GetToolRequiredAction():
				#if self.versions.GetToolRequiredAction()["WinIDEA"] == "DoNothing":
				# it could be interresting to remove the button after the install... but it does not work, the GUI crashes...
				#self.WinIdea_install_button.grid_remove()
				#self.WinIdea_update_button.grid_remove()
				if self.versions.GetToolRequiredAction()["WinIDEA"] == "ToInstall":
					self.WinIdea_install_button.grid(row=0, column=1)
					self.WinIdea_install_button.config(state=NORMAL)
				elif self.versions.GetToolRequiredAction()["WinIDEA"] == "ToUpdate":
					self.WinIdea_update_button.grid(row=0, column=1)
					self.WinIdea_update_button.config(state=NORMAL)
				
			''' ------------------------------------------------------------------------- '''
			''' emulator buttons management '''
			if self.component_EMULATOR_active == True:
				''' all buttons are disabled per default '''
				self.debugger_button.config(state=DISABLED)
				self.profiler_button.config(state=DISABLED)
				self.profiler_help_button.config(state=DISABLED)
				self.codecoverage_button.config(state=DISABLED)
				self.logger_button.config(state=DISABLED)
				if (self.commandArray[CFG_PREFIX_EMULATOR][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
					self.commandArray[CFG_PREFIX_EMULATOR][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
					if "WinIDEA" in self.versions.GetToolRequiredAction():
						if self.versions.GetToolRequiredAction()["WinIDEA"] != "ToInstall":
							''' enable emulator button if the SW install is not required '''
							self.debugger_button.config(state=NORMAL)
							''' Profiler configuration '''
							if (self.commandArray[CFG_PREFIX_PROFILER][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
								self.commandArray[CFG_PREFIX_PROFILER][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
								self.profiler_button.config(state=NORMAL)
								self.profiler_help_button.config(state=NORMAL)
							''' Code coverage configuration '''
							if (self.commandArray[CFG_PREFIX_CODECOVER][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
								self.commandArray[CFG_PREFIX_CODECOVER][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
								self.codecoverage_button.config(state=NORMAL)
							''' BCMF logger '''
							self.logger_button.config(state=NORMAL)
				
			''' ------------------------------------------------------------------------- '''
			''' resource analysis management '''
			if (self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
				self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
				self.resource_checking_button.deselect()
				self.resource_checking_button.config(state=DISABLED)
				self.open_resource_button.config(state=DISABLED)
			else:
				self.resource_checking_button.config(state=NORMAL)
				self.LoadUserSettings(0)
				
				''' the button used to open the results is activated only if a report is available for the selected variant '''
				__tempResourceAnalyseFileVariant = self.tempOutpath + "\\tempResourceAnalyseFile" + self.variantRadioGroup.get() + ".txt"
				if os.path.exists(__tempResourceAnalyseFileVariant) == True:
					''' the button command is dynamically modified '''
					__tempFileHandler = open(__tempResourceAnalyseFileVariant, 'r')
					__contentTempFile = __tempFileHandler.readlines()
					__tempFileHandler.close()
					self.command_open_analysis_results = "start " + __contentTempFile[4][:-1]
					self.open_resource_button.config(state=NORMAL)
				else:
					self.open_resource_button.config(state=DISABLED)
					
					
			''' ------------------------------------------------------------------------- '''
			''' stack analysis management '''
			if (self.commandArray[CFG_PREFIX_STACKCFG][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
				self.commandArray[CFG_PREFIX_STACKCFG][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
				self.check_stack_button.deselect()
				self.check_stack_button.config(state=DISABLED)
			else:
				self.check_stack_button.config(state=NORMAL)
				self.LoadUserSettings(2)
				
				
			''' ------------------------------------------------------------------------- '''
			''' build control buttons management '''
			if self.component_BUILD_active == True:
				
				''' cancel button '''
				self.build_cancel_button_application.config(state=DISABLED)
				
				if (self.commandArray[CFG_PREFIX_BUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_BUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.build_button_application.config(state=DISABLED)
				else:
					self.build_button_application.config(state=NORMAL)
				
				if (self.commandArray[CFG_PREFIX_REBUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_REBUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.rebuild_button_application.config(state=DISABLED)
				else:
					self.rebuild_button_application.config(state=NORMAL)
			
			''' ------------------------------------------------------------------------- '''
			''' obuild control buttons management '''
			if self.component_OBUILD_active == True:
				
				if (self.commandArray[CFG_PREFIX_OBUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_OBUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.obuild_button_application.config(state=DISABLED)
				else:
					self.obuild_button_application.config(state=NORMAL)
					
				if (self.commandArray[CFG_PREFIX_OREBUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_OREBUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.orebuild_button_application.config(state=DISABLED)
				else:
					self.orebuild_button_application.config(state=NORMAL)
			
			''' ------------------------------------------------------------------------- '''
			''' documentation buttons management '''
			if self.component_DOCUGEN_active == True:
				if (self.commandArray[CFG_PREFIX_DOCHELP][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_DOCHELP][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.view_helpdoc_button.config(state=DISABLED)
				else:
					self.view_helpdoc_button.config(state=NORMAL)
				
				if (self.commandArray[CFG_PREFIX_DOXYGEN][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_DOXYGEN][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.generate_doc_button.config(state=DISABLED)
				else:
					self.generate_doc_button.config(state=NORMAL)
		 
			''' ------------------------------------------------------------------------- '''
			''' rta-os button management '''
			if self.component_OSGEN_active == True:
				if (self.commandArray[CFG_PREFIX_OSCFG][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
					self.commandArray[CFG_PREFIX_OSCFG][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
					self.os_generator_button.config(state=DISABLED)
				else:
					self.os_generator_button.config(state=NORMAL)
		
			''' ------------------------------------------------------------------------- '''
			''' project specific tools buttons management '''
			for tool_index in range(1,self.number_of_specific_tools+1):
				specific_tool_name = self.configuration[CFG_PREFIX_SPEC_TOOL_NAME + str(tool_index)]
				specific_tool_command = self.configuration[CFG_PREFIX_SPEC_TOOL_BATCH + str(tool_index)]
				if specific_tool_name != CFG_NOT_REQUIRED:
					if specific_tool_command == CFG_NOT_REQUIRED:
						self.specific_tools_button[tool_index].config(state=DISABLED)
					else:
						self.specific_tools_button[tool_index].config(state=NORMAL)
		
			''' ------------------------------------------------------------------------- '''
			''' news button management '''
			if self.component_NEWS_active == True:
				self.news_button.config(state=NORMAL)
			
			
			''' ------------------------------------------------------------------------- '''
			''' mfile button management '''
			if self.component_MFILEGEN_active == True:
				self.mfile_gen_button.config(state=NORMAL)
				
			''' ------------------------------------------------------------------------- '''
			''' other tools '''
			self.clear_screen_button.config(state=NORMAL)
			self.help_button.config(state=NORMAL)
			
			self.popup_build_button.config(state=NORMAL)
			self.LoadUserSettings(1)

			self.delete_elf_button.config(state=NORMAL)
			self.LoadUserSettings(4)		  
					
		
		else:
			''' disable all controls '''
			self.major_version_entry.config(state="readonly")
			self.minor_version_entry.config(state="readonly")
			self.revision_version_entry.config(state="readonly")
			
			for i in range(1,self.numberOfVariants):
				self.variant_radiobutton[i].config(state=DISABLED)
			
			self.build_button_application.config(state=DISABLED)
			self.rebuild_button_application.config(state=DISABLED)
			self.delete_elf_button.config(state=DISABLED)
			self.obuild_button_application.config(state=DISABLED)
			self.orebuild_button_application.config(state=DISABLED)
			self.os_generator_button.config(state=DISABLED)
			self.debugger_button.config(state=DISABLED)
			self.profiler_button.config(state=DISABLED)
			self.profiler_help_button.config(state=DISABLED)
			self.codecoverage_button.config(state=DISABLED)
			self.logger_button.config(state=DISABLED)
			self.eclipse_button.config(state=DISABLED)
			self.generate_doc_button.config(state=DISABLED)
			self.view_helpdoc_button.config(state=DISABLED)
			self.post_analysis_button.config(state=DISABLED)
			self.cross_analysis_button.config(state=DISABLED)
			self.only_third_party_analysis_button.config(state=DISABLED)
			self.include_third_party_analysis_button.config(state=DISABLED)
			self.filter_dependencies_button.config(state=DISABLED)
			self.resource_checking_button.config(state=DISABLED)
			self.check_stack_button.config(state=DISABLED)
			self.open_resource_button.config(state=DISABLED)
			self.popup_build_button.config(state=DISABLED)
			self.version_updating_button.config(state=DISABLED)
			self.qacanalysis_all_button.config(state=DISABLED)
			self.qacview_all_button.config(state=DISABLED)
			self.qacanalysis_mod_button.config(state=DISABLED)
			self.qacviewer_mod_button.config(state=DISABLED)
			self.qacmetrics_mod_button.config(state=DISABLED)
			self.mb_toplevel.config(state=DISABLED)
			self.mfile_gen_button.config(state=DISABLED)
			self.clear_screen_button.config(state=DISABLED)
			self.help_button.config(state=DISABLED)
			self.news_button.config(state=DISABLED)
		
			for tool_index in range(1,self.number_of_specific_tools+1):
				specific_tool_name = self.configuration[CFG_PREFIX_SPEC_TOOL_NAME + str(tool_index)]
				if specific_tool_name != CFG_NOT_REQUIRED:
					self.specific_tools_button[tool_index].config(state=DISABLED)

			self.WinIdea_update_button.config(state=DISABLED)
			self.WinIdea_install_button.config(state=DISABLED)
		
			
		''' environment variable with selected variant '''
		os.environ['BCMF_SELECTED_VARIANT'] = self.variantRadioGroup.get()
		
		self.previousVariant = self.variantRadioGroup.get()
		
		
		
	# -------------------------------------------------------------------------
	# SaveUserGUISettings
	# This function is called after selecting another variant and before 
	# updating the GUI. It enables to save the current user settings in a 
	# temporary file.
	# Parameter: variant: variant name for the settings to save
	#
	# User settings file format:
	# - line 0: resource_checking_button (selected/deselected)
	# - line 1: popup_build_button	   (selected/deselected)
	# - line 2: check_stack_button	   (selected/deselected)
	# - line 3: version_updating_button  (selected/deselected)
	# - line 4: delete_elf_button		(selected/deselected)
	# -------------------------------------------------------------------------
	
	def SaveUserGUISettings(self, variant):
			
		__tempUserSettingsVariant = self.tempOutpath + "\\tempUserSettings" + variant + ".txt"
		__tempUserSettingsVariantStr = ""
		
		if os.path.exists(__tempUserSettingsVariant) == True:
			__accessMode = 'r+'
		else:
			__accessMode = 'w'
		__tempFileHandler = open(__tempUserSettingsVariant, __accessMode)
		
		''' resource analysis checkbox user setting '''
		if (self.commandArray[CFG_PREFIX_RESOURCE][variant] != CFG_NOT_IMPLEMENTED and 
			self.commandArray[CFG_PREFIX_RESOURCE][variant] != CFG_NOT_REQUIRED):	
			if(self.performResourceAnalysis.get() == 1):
				__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "selected\n"
			else:
				__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
		else:
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
			
		''' popup end of build checkbox user setting '''
		if(self.popupBuild.get() == 1):
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "selected\n"
		else:
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
		
		''' stack analysis checkbox user setting '''
		if (self.commandArray[CFG_PREFIX_STACKCFG][variant] != CFG_NOT_IMPLEMENTED and 
			self.commandArray[CFG_PREFIX_STACKCFG][variant] != CFG_NOT_REQUIRED):	
			if(self.performStackCheck.get() == 1):
				__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "selected\n"
			else:
				__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
		else:
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
			
		''' ECU version management checkbox user setting '''
		if(self.autoVersionUpdate.get() == 1):
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "selected\n"
		else:
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
		
		''' delete elf checkbox user setting '''
		if(self.deleteElf.get() == 1):
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "selected\n"
		else:
			__tempUserSettingsVariantStr = __tempUserSettingsVariantStr + "deselected\n"
		
		print >> __tempFileHandler, __tempUserSettingsVariantStr
		__tempFileHandler.close()
		
		
	
	# -------------------------------------------------------------------------
	# LoadUserSettings
	# This function is called after updating the GUI. It reads the user 
	# settings for the selected variant and configure the GUI with them. 
	# Parameter: settingID: corresponds to the line number
	# 
	# User settings file format:
	# - line 0: resource_checking_button (selected/deselected)
	# - line 1: popup_build_button	   (selected/deselected)
	# - line 2: check_stack_button	   (selected/deselected)
	# - line 3: version_updating_button  (selected/deselected)
	# - line 4: delete_elf_button		(selected/deselected)
	# -------------------------------------------------------------------------
	
	def LoadUserSettings(self, settingID):
		
		''' if available, we load the settings for the selected variant '''
		__tempUserSettingsVariant = self.tempOutpath + "\\tempUserSettings" + self.variantRadioGroup.get() + ".txt"
		if os.path.exists(__tempUserSettingsVariant) == True:
			
			__tempFileHandler = open(__tempUserSettingsVariant, 'r')
			__contentTempFile = __tempFileHandler.readlines()
			__tempFileHandler.close()
			
			if(settingID == 0):
				''' resource analysis checkbox user setting '''
				if (self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
					self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
					if(__contentTempFile[0] == "selected\n"):
						self.resource_checking_button.select()
					else:
						self.resource_checking_button.deselect()
		
			elif(settingID == 1):
				''' popup end of build checkbox user setting '''
				if(__contentTempFile[1] == "selected\n"):
					self.popup_build_button.select()
				else:
					self.popup_build_button.deselect()
		
			elif(settingID == 2):
				''' stack analysis checkbox user setting '''
				if (self.commandArray[CFG_PREFIX_STACKCFG][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
					self.commandArray[CFG_PREFIX_STACKCFG][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
					if(__contentTempFile[2] == "selected\n"):
						self.check_stack_button.select()
					else:
						self.check_stack_button.deselect()
	   
			elif(settingID == 3):
				''' ECU version management checkbox user setting '''
				if(__contentTempFile[3] == "selected\n"):
					self.version_updating_button.select()
				else:
					self.version_updating_button.deselect()	  
	   
			elif(settingID == 4):
				''' Delete elf checkbox user setting '''
				if(__contentTempFile[4] == "selected\n"):
					self.delete_elf_button.select()
				else:
					self.delete_elf_button.deselect()   
					
					
	   
	# -------------------------------------------------------------------------
	# Function common to building and rebuilding to be executed before the
	# building or rebuilding. (variant dependant)
	# -------------------------------------------------------------------------

	def CommonPreBuild(self):
		
		''' build start time '''
		self.startTime = datetime.datetime.now()
		print "Start time: " + str(self.startTime)[:-7]
	
		''' tools versions check '''
		print "Checking versions of tools..."
		self.actual_status.set("Checking Tool Versions...")
		self.gui.update()
		#self.TestVersion()

		''' Software version update function required? '''
		if self.component_ECUVERSION_active == True:
			''' only update software version if auto update is selected '''
			if(self.autoVersionUpdate.get() == 1):
				print "Updating version files in Clearcase..."
				self.actual_status.set("Updating ECU Version...")
				self.gui.update()
				''' try and access the version data in clearcase '''
				try:
					self.versionFcts.UpdateVersion(self.commandArray[CFG_PREFIX_ECUVERCFG][self.variantRadioGroup.get()], self.major_version_entry.get(), self.minor_version_entry.get(), self.revision_version_entry.get())
					print ""
				except:
					print ""

		if (self.commandArray[CFG_PREFIX_PREBUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
		self.commandArray[CFG_PREFIX_PREBUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
			print "\nPre Build NOT CONFIGURED\n"
		else:
			self.actual_status.set("Pre Build\Rebuild...")
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_PREBUILD][self.variantRadioGroup.get()])

		if(self.deleteElf.get() == 1):
			''' Executable project file is deleted before building the project '''
			if (self.commandArray[CFG_PREFIX_ELF][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
			self.commandArray[CFG_PREFIX_ELF][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
				print "\nERROR: The generated ELF File name should be configured in GUI configuration file \n"
			else:
				__command = "del /Q " + self.commandArray[CFG_PREFIX_ELF][self.variantRadioGroup.get()]
				self.ExecuteSingleOSThread(__command)
		
		

	# -------------------------------------------------------------------------
	# Function common to building and rebuilding to be executed after the
	# building or rebuilding. (variant dependant)
	# -------------------------------------------------------------------------

	def CommonPostBuild(self):
	
		''' the postbuild is done only if the compilation succeeded '''
		__elfFile = self.commandArray[CFG_PREFIX_ELF][self.variantRadioGroup.get()]
		if os.path.exists(__elfFile) == True:
		
			self.buildSuccess = True
		
			if (self.commandArray[CFG_PREFIX_HEX][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
			self.commandArray[CFG_PREFIX_HEX][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
				print "\nPost Build HEX generation NOT CONFIGURED\n"
			else:
				self.actual_status.set("Generating HEX...")
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_HEX][self.variantRadioGroup.get()])

			if (self.commandArray[CFG_PREFIX_POSTBUILD][self.variantRadioGroup.get()] == CFG_NOT_IMPLEMENTED or 
			self.commandArray[CFG_PREFIX_POSTBUILD][self.variantRadioGroup.get()] == CFG_NOT_REQUIRED):
				print "\nPost Build NOT CONFIGURED\n"
			else:
				self.actual_status.set("Post Build...")
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_POSTBUILD][self.variantRadioGroup.get()])

				
			''' ------------------------------------------------------------------------- '''
			''' Resource Analysis '''
			if (self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
			self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
				
				if(self.performResourceAnalysis.get() == 1):
					self.actual_status.set("Resource Analysis...")
					self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_RESOURCE][self.variantRadioGroup.get()])
					
					''' get result file path '''
					try:
						__tempFileHandler = open(self.tempResourceAnalyseResultPath, 'r')
						__contentTempFile = __tempFileHandler.readlines()
						__tempFileHandler.close()
						__resultResourceAnalysisPath = __contentTempFile[0][:-1]
						
						''' check result in temp file '''
						try:
							__tempResourceAnalyseFile = __resultResourceAnalysisPath + "\\tempResourceAnalysis.txt"
							__tempFileHandler = open(__tempResourceAnalyseFile, 'r')
							__contentTempFile = __tempFileHandler.readlines()
							__tempFileHandler.close()
							if __contentTempFile[0] == "Success\n":
								__resourceAnalysisRAM = __contentTempFile[1][:-1]
								__resourceAnalysisROM = __contentTempFile[2][:-1]
								__resourceAnalysisSTACK = __contentTempFile[3][:-1]
							
								__resourceAnalysisStr =															\
								"\n-----------------------------------------------------------------------------" +\
								"\nResource Analysis results:\n"												  +\
								"	RAM   =	" + str(__resourceAnalysisRAM)	+ " kB\n"					   +\
								"	ROM   =	" + str(__resourceAnalysisROM)	+ " kB\n"					   +\
								"	STACK =	" + str(__resourceAnalysisSTACK)  + " kB\n"					   +\
								"-----------------------------------------------------------------------------\n"
							
								print __resourceAnalysisStr
								
								''' the result is copied in another temporary file used especially for this variant '''
								''' thanks to that, it is then possible to dynamically configure the "Resource results" button '''
								''' this file is then analysed in the updateGUI function '''
								try:   
									''' variant temp file: the file name contains the variant name '''
									__tempResourceAnalyseFileVariant = self.tempOutpath + "\\tempResourceAnalyseFile" + self.variantRadioGroup.get() + ".txt"
									__tempFileHandler = open(__tempResourceAnalyseFileVariant, 'w')
									for line in __contentTempFile:
										print >> __tempFileHandler, line[:-1]
									__tempFileHandler.close()
								except:
									print "Error while trying to write the temporary resource analysis file for a specific variant.\n"
									
						except:
							print "Error while trying to read the temporary resource analysis file.\n"
						
					except:
						print "Error while trying to read the temporary resource analysis path file\n."
						
			
			''' ------------------------------------------------------------------------- '''
			''' Stack checker '''
			''' This call should not be compiler dependent '''
			''' The compiler choice is done in the script stackchecker.py '''
			if(self.performStackCheck.get() == 1):
				self.actual_status.set("Stack check...")
		
				''' create the stack checker object '''
				__elfFile = self.commandArray[CFG_PREFIX_ELF][self.variantRadioGroup.get()]
				__ldFile  = self.commandArray[CFG_PREFIX_LD_FILE][self.variantRadioGroup.get()]
				__stackCheckerCFG = self.commandArray[CFG_PREFIX_STACKCFG][self.variantRadioGroup.get()]
				__selectedVariant = self.variantRadioGroup.get()
				__stackchecker = StackChecker(__selectedVariant, __elfFile, __ldFile, __stackCheckerCFG, self.tempOutpath, self.stackCheckerOutPath)
				
				''' continue only if the stack checker succeeded '''
				if (__stackchecker.GetResult() == True):
				
					'''if build succeeded enable "Stack results" button and set the path of stack file'''
					self.stackAnalysisResult = 1
					self.command_open_stack_results = "start " + self.tempStackAnalyseFile
					
					''' get the calculated stack '''
					__calculatedStack = __stackchecker.GetCalculatedStack()
					''' get the reserved stack '''
					__reservedStack   = __stackchecker.GetReservedStack()
					''' get the remaining stack '''
					__remainingStack  = __reservedStack - __calculatedStack
					
					if __reservedStack <= __calculatedStack:
						__warning = "\n!!! The reserved stack is not sufficient !!!					  \n"
					else:
						__warning = ""
				
					''' prepare string '''
					__stackCheckerResults =															  \
					"-----------------------------------------------------------------------------"	 +\
					"\nStack checker results:"														  +\
					"\n	Reserved stack	 " + str(__reservedStack)								  +\
					"\n	Calculated stack   " + str(__calculatedStack)								+\
					"\n	----------------   "														 +\
					"\n	Remaining stack	" + str(__remainingStack) + "\n"						  +\
					__warning + "\n"																	+\
					__stackchecker.GetCompilerSpecificWarning()										 +\
					"-----------------------------------------------------------------------------\n"
					
					print __stackCheckerResults
					  
				else:
					self.stackAnalysisResult = 0
					
			''' end build time '''
			self.endTime = datetime.datetime.now()
			print "Build end time: " + str(self.endTime)[:-7]
			self.buildDuration = self.endTime - self.startTime
			print "Build duration: " + str(self.buildDuration)[:-7]
		
			''' ------------------------------------------------------------------------- '''
			''' popup which appears at the end of the compilation '''
			''' the popup changes according to the compilation result '''
			''' if the elf file does not exist, an error is reported '''
			if(self.popupBuild.get() == 1):
				__infoString = "Build succeeded!		  \nDuration: " + str(self.buildDuration)[:-7]
				#
				# Do we print the stack information in the popup??
				#
				#if(self.performStackCheck.get() == 1):
				#	__infoString = __infoString + __stackCheckerResults
				#	__infoString = __infoString + "															  "
				tkMessageBox.showinfo("Build process", __infoString)
			else:
				''' the user doesn't want to see the popup '''
		
		else:
			''' the build failed '''
			self.buildSuccess = False
			
			''' end build time '''
			self.endTime = datetime.datetime.now()
			print "Build end time: " + str(self.endTime)[:-7]
			self.buildDuration = self.endTime - self.startTime
			print "Build duration: " + str(self.buildDuration)[:-7]
			
			if(self.popupBuild.get() == 1):
				__infoString = "Build failed!			 \nBuild duration: " + str(self.buildDuration)[:-7]
				tkMessageBox.showerror("Build process", __infoString)
			else:
				''' the user doesn't want to see the popup '''

	# -------------------------------------------------------------------------
	# Function to execute a project build. (variant dependant)
	# -------------------------------------------------------------------------

	def BuildProjectApplication(self):

		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
		
		''' the SW version is tested only if the user want to update it '''
		resultCheckVersion = 0
		if(self.autoVersionUpdate.get() == 1):
			resultCheckVersion = self.CheckECUSoftwareVersion()
		
		if(self.autoVersionUpdate.get() ^ resultCheckVersion) == 0:
			self.PrintVariantDOSLabel("Build", True)

			''' prebuild '''
			self.CommonPreBuild()

			''' parallel thread for the cancel function '''
			''' the cancel function is available only if configured for the variant '''
			if (self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
			self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
				print ""
				print "This variant enables the build cancel function."
				print ""
				self.threadCancelBuildExist = 1
				self.threadCancelBuild = ThreadedCancelBuild()
				self.threadCancelBuild.setName("Cancel_Build")
				self.threadCancelBuild.setDaemon(True)
				self.threadCancelBuild.start()
					
			''' build '''
			__statusText = "Building... [Start time: " + str(self.startTime)[:-7] + "]"
			self.actual_status.set(__statusText)
			cmd = self.commandArray[CFG_PREFIX_BUILD][self.variantRadioGroup.get()]
			gpj_file_name = cmd.split(" ")[-1]
			if(self.enableDebugFlag.get()):
				open(gpj_file_name.replace(".gpj", "_Debug.gpj"), "wt").write(open(gpj_file_name, "rt").read().replace("-stderr=\"error.txt\"", "-stderr=\"error.txt\"\r\t-DXMC_ENABLE_DEBUG"))
				self.ExecuteSingleOSThread(cmd.replace(gpj_file_name, gpj_file_name.replace(".gpj", "_Debug.gpj")))
				#self.ExecuteSingleOSThread(r"C:\toolbase\greenhills_jdp\comp_201354_testversion2\gbuild.exe -preprocess -top " + gpj_file_name.replace(".gpj", "_Debug.gpj"))
				self.ExecuteSingleOSThread("del /F /Q " + gpj_file_name.replace(".gpj", "_Debug.gpj"))
			else:
				self.ExecuteSingleOSThread(cmd)
				#self.ExecuteSingleOSThread(r"C:\toolbase\greenhills_jdp\comp_201354_testversion2\gbuild.exe -preprocess -top " + gpj_file_name)

			''' stop parallel thread for the cancel function '''
			if (self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
			self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
				self.threadCancelBuild.stop()
				''' the cancel button is disabled again (just to be sure) '''
				bcmf_builder_main.build_cancel_button_application.config(state=DISABLED)
					
			''' postbuild '''
			self.CommonPostBuild()
			
			''' status '''
			if self.buildSuccess == True:
				__statusText = "Build complete [Last build: " + str(self.endTime)[:-7] + "]"  
			else:
				__statusText = "!! Build errors !! [Last build: " + str(self.endTime)[:-7] + "]"
			self.actual_status.set(__statusText)
			print "Complete..."					
					
		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()



	# -------------------------------------------------------------------------
	# Function to execute a project rebuild. (variant dependant)
	# -------------------------------------------------------------------------

	def RebuildProjectApplication(self):
		
		rebuildRequired = 1
		if self.configuration[CFG_ASK_BEFORE_REBUILD] == CFG_ENABLED:
			''' ask the user before rebuild the project '''
			rebuildRequired = tkMessageBox.askokcancel(title="Project rebuild", message="Do you really want to rebuild the selected application?")
			
		if rebuildRequired == 1:
			''' update GUI disabling all controls '''
			self.controls_enabled = False
			self.UpdateGUI()
			
			''' the SW version is tested only if the user want to update it '''
			resultCheckVersion = 0
			if(self.autoVersionUpdate.get() == 1):
				resultCheckVersion = self.CheckECUSoftwareVersion()
				
			if(self.autoVersionUpdate.get() ^ resultCheckVersion) == 0:
				self.PrintVariantDOSLabel("ReBuild", True)

				''' prebuild '''
				self.CommonPreBuild()

				''' parallel thread for the cancel function '''
				''' the cancel function is available only if configured for the variant '''
				if (self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
				self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
					print ""
					print "This variant enables the build cancel function."
					print ""
					self.threadCancelBuildExist = 1
					self.threadCancelBuild = ThreadedCancelBuild()
					self.threadCancelBuild.setName("Cancel_Build")
					self.threadCancelBuild.setDaemon(True)
					self.threadCancelBuild.start()
				
				''' rebuild '''
				__statusText = "Rebuilding... [Start time: " + str(self.startTime)[:-7] + "]"
				self.actual_status.set(__statusText)
				cmd = self.commandArray[CFG_PREFIX_REBUILD][self.variantRadioGroup.get()]
				gpj_file_name = cmd.split(" ")[-1]
				if(self.enableDebugFlag.get()):
					open(gpj_file_name.replace(".gpj", "_Debug.gpj"), "wt").write(open(gpj_file_name, "rt").read().replace("-stderr=\"error.txt\"", "-stderr=\"error.txt\"\r\t-DXMC_ENABLE_DEBUG"))
					self.ExecuteSingleOSThread(cmd.replace(gpj_file_name, gpj_file_name.replace(".gpj", "_Debug.gpj")))
					#self.ExecuteSingleOSThread(r"C:\toolbase\greenhills_jdp\comp_201354_testversion2\gbuild.exe -preprocess -top " + gpj_file_name.replace(".gpj", "_Debug.gpj"))
					self.ExecuteSingleOSThread("del /F /Q " + gpj_file_name.replace(".gpj", "_Debug.gpj"))
				else:
					self.ExecuteSingleOSThread(cmd)
					#self.ExecuteSingleOSThread(r"C:\toolbase\greenhills_jdp\comp_201354_testversion2\gbuild.exe -preprocess -top " + gpj_file_name)
				
				''' stop parallel thread for the cancel function '''
				if (self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_IMPLEMENTED and 
				self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()] != CFG_NOT_REQUIRED):
					self.threadCancelBuild.stop()
					''' the cancel button is disabled again (just to be sure) '''
					bcmf_builder_main.build_cancel_button_application.config(state=DISABLED)
				
				''' postbuild '''
				self.CommonPostBuild()
			
				''' status '''
				if self.buildSuccess == True:
					__statusText = "Rebuild complete [Last build: " + str(self.endTime)[:-7] + "]"  
				else:
					__statusText = "!! Rebuild errors !! [Last build: " + str(self.endTime)[:-7] + "]"
				self.actual_status.set(__statusText)
				print "Complete..."

			
			''' update GUI enabling all controls '''
			self.controls_enabled = True
			self.UpdateGUI()

			
			
	# -------------------------------------------------------------------------
	# Function to cancel the current project build / rebuild operation
	# -------------------------------------------------------------------------

	def CancelBuildProjectApplication(self):
		
		__killCommand = "taskkill /F /IM " + self.commandArray[CFG_PREFIX_BUILDTASK][self.variantRadioGroup.get()]
		os.system(__killCommand) 
		
		
			
	# -------------------------------------------------------------------------
	# Function to execute a project build. (variant dependant)
	# -------------------------------------------------------------------------

	def OmakeBuildProjectApplication(self):
		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
			
		''' the SW version is tested only if the user want to update it '''
		resultCheckVersion = 0
		if(self.autoVersionUpdate.get() == 1):
			resultCheckVersion = self.CheckECUSoftwareVersion()
			
		if(self.autoVersionUpdate.get() ^ resultCheckVersion) == 0:
			self.PrintVariantDOSLabel("Build", True)

			self.CommonPreBuild()

			projectBuildFile = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS.mak"
			buildFile = self.buildTempOut + "\\BUILD_DIRS.mak"

			if(os.path.exists(buildFile)==FALSE):
				shutil.copyfile(projectBuildFile, buildFile)
			else:
				if (filecmp.cmp(projectBuildFile, buildFile) == 0)|(os.path.exists(buildFile)==FALSE):
					shutil.copyfile(projectBuildFile, buildFile)

			self.actual_status.set("Building...")
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_OBUILD][self.variantRadioGroup.get()])

			self.CommonPostBuild()

			self.actual_status.set("Complete...")
			print "Complete..."

		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()
			

	# -------------------------------------------------------------------------
	# Function to execute a project rebuild. (variant dependant)
	# -------------------------------------------------------------------------

	def OmakeRebuildProjectApplication(self):
		rebuildRequired = 1
		
		if self.configuration[CFG_ASK_BEFORE_REBUILD] == CFG_ENABLED:
			''' ask the user before rebuild the project '''
			rebuildRequired = tkMessageBox.askokcancel(title="Project rebuild", message="Do you really want to rebuild the selected application?")
			
		if rebuildRequired == 1:
			''' update GUI disabling all controls '''
			self.controls_enabled = False
			self.UpdateGUI()

			''' the SW version is tested only if the user want to update it '''
			resultCheckVersion = 0
			if(self.autoVersionUpdate.get() == 1):
				resultCheckVersion = self.CheckECUSoftwareVersion()
				
			if(self.autoVersionUpdate.get() ^ resultCheckVersion) == 0:
				self.PrintVariantDOSLabel("ReBuild", True)

				self.CommonPreBuild()

				self.actual_status.set("Rebuilding...")
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_OREBUILD][self.variantRadioGroup.get()])

				self.CommonPostBuild()

				self.actual_status.set("Complete...")
				print "Complete..."

			''' update GUI enabling all controls '''
			self.controls_enabled = True
			self.UpdateGUI()


			
	# -------------------------------------------------------------------------
	# Function to execute RTA-OS.
	# -------------------------------------------------------------------------

	def RtaOsBuilder(self):
		self.PrintVariantDOSLabel("Execute RTA-OS", False)
		absConfFile = os.path.abspath(self.commandArray[CFG_PREFIX_OSCFG][self.variantRadioGroup.get()])
		self.command_compl = self.command_rtaos + " " + absConfFile
		self.ExecuteSingleOSThread(self.command_compl)


		
	# -------------------------------------------------------------------------
	# Function to load the emulator. (variant dependant)
	# -------------------------------------------------------------------------

	def DebuggerExecute(self):
		self.PrintVariantDOSLabel("Execute emulator", True)
		command = "\"" + os.environ.get("WINIDEA_LOCAL") + "\winIDEA.exe\" " + self.commandArray[CFG_PREFIX_EMULATOR][self.variantRadioGroup.get()]
		self.ExecuteSingleOSThread(command)

	def ProfilerExecute(self):
		self.PrintVariantDOSLabel("Execute Profiler", True)
		command = "\"" + os.environ.get("WINIDEA_LOCAL") + "\winIDEA.exe\" " + self.commandArray[CFG_PREFIX_PROFILER][self.variantRadioGroup.get()]
		self.ExecuteSingleOSThread(command)

	def ProfilerHowToExecute(self):
		self.PrintVariantDOSLabel("Execute How-To", True)
		command = "\"" + os.environ.get("BCMF_SCRIPTS_ROOT") + "\\documentation\\" + "bcmf_winidea_profiler_howto.pdf"
		self.ExecuteSingleOSThread(command)
	
	def CodeCoverageExecute(self):
		self.PrintVariantDOSLabel("Execute Code Coverage", True)
		command = "\"" + os.environ.get("WINIDEA_LOCAL") + "\winIDEA.exe\" " + self.commandArray[CFG_PREFIX_CODECOVER][self.variantRadioGroup.get()]
		self.ExecuteSingleOSThread(command)
		
	def LoggerExecute(self):
		self.PrintVariantDOSLabel("Execute Logger", True)
		command = "\"" + os.environ.get("BCMF_SCRIPTS_ROOT") + "\\bcmf_logger\\" + "BCMF_Logger.exe"
		self.ExecuteSingleOSThread(command)
	
	
	# -------------------------------------------------------------------------
	# Function to open the resource analyse report.
	# -------------------------------------------------------------------------

	def OpenResourceAnalyseResults(self):
		self.ExecuteSingleOSThread(self.command_open_analysis_results)
		
	def OpenStackFile(self):
		self.ExecuteSingleOSThread(self.command_open_stack_results)


	# -------------------------------------------------------------------------
	# Function to execute QAC analysis of the project.
	# -------------------------------------------------------------------------

	def QACAnalysisAll(self):

		''' If the parser and the GHS parser optimisation is used: '''
		''' the analysis is done only if the include list is based on the project specific dir list [RCM Activity EBRCM00065125] '''
		if (self.component_QAC_PARSER_active == True) & (self.component_QAC_PARSER_OPT_active == "GHS") &\
		(self.newSourceDirectory.IsIncDirListParserWithoutOptimisationUsed() == True):
			tkMessageBox.showerror("QAC Analysis", "Can not analyse the project!\n\nIn order to run a QAC analysis, you first have to build the project.\nPlease restart the GUI after.")
			''' End: no analysis is possible because of the wrong include list '''
			return

		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()

		print " "
		print "--------------------"
		print "Execute QAC - ALL..."
		print "--------------------"

		''' ask the user if he really doesn't want to generate the QAC report '''
		if(self.performPostAnalysis.get() == 0):
			if(tkMessageBox.askyesno("QAC Report", "Do you want to generate an Excel report at the end of the analysis?") == True):
				self.performPostAnalysis.set(1)
				self.post_analysis_button.select()
		
		''' prevent the user to close EXCEL before running the QAC report script '''
		if(self.performPostAnalysis.get() == 1):
			tkMessageBox.showinfo("QAC Report", "In order to generate the QAC report at the end of the analysis,\nplease close all your Excel applications before continuing.")
		
		
		''' Prepare QAC analysis in case the parser is disabled '''			
		if self.component_QAC_PARSER_active == False:
			projectFile = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS.mak"
			projectFileThirdParty = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS_THIRD_PARTY.mak"

			''' set analysis file '''
			if self.onlyThirdPartyAnalysis.get() == False:
				analysisFile = self.qacTempOut + "\\ANALYSIS_DIRS.mak"
				if(os.path.exists(analysisFile)==FALSE):
					shutil.copyfile(projectFile, analysisFile)
				else:
					if (filecmp.cmp(projectFile, analysisFile) == 0):
						shutil.copyfile(projectFile, analysisFile)
			else:
				''' Third party analysis '''
				analysisFile = self.qacTempOut + "\\ANALYSIS_DIRS.mak"
				if(os.path.exists(analysisFile)==FALSE):
					shutil.copyfile(projectFileThirdParty, analysisFile)
				else:
					if (filecmp.cmp(projectFileThirdParty, analysisFile) == 0):
						shutil.copyfile(projectFileThirdParty, analysisFile)
						
		
		''' Prepare QAC analysis in case the parser is used '''
		if self.component_QAC_PARSER_active == True:
			projectFileTemplate = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS_TEMPLATE.mak"
			projectFileGenerated = self.qacTempOut + "\\PROJECT_DIRS_GENERATED.mak"

			self.actual_status.set("Generating file list..")

			srcDirs = self.newSourceDirectory.GetSourceDirs()
			incDirs = self.newSourceDirectory.GetIncludeDirs()

			GenerateQACDirList(srcDirs, incDirs, projectFileTemplate, projectFileGenerated, 'BCMF_SOFTWARE_BASE', self.onlyThirdPartyAnalysis.get(), self.includeThirdPartyAnalysis.get())

			''' set analysis file '''
			analysisFile = self.qacTempOut + "\\ANALYSIS_DIRS.mak"
			if(os.path.exists(analysisFile)==FALSE):
				shutil.copyfile(projectFileGenerated, analysisFile)
			else:
				if (filecmp.cmp(projectFileGenerated, analysisFile) == 0):
					shutil.copyfile(projectFileGenerated, analysisFile)
					
					
		''' Start QAC analysis '''
		self.actual_status.set("Starting QAC...")
		if self.onlyThirdPartyAnalysis.get() == False:
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACALL][self.variantRadioGroup.get()])
			self.actual_status.set("QAC analysis finished...")

			if(self.performCrossAnalysis.get() == 1):
				self.actual_status.set("Running CMA analysis...")
				self.ExecuteSingleOSThread(self.command_cross_analysis)
				self.actual_status.set("QAC CMA analysis finished...")
				''' create a QAC project file which can be used for CMA '''
				GenerateQACproject()
				
			self.actual_status.set("Starting QAC Viewer..")
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACVIEW][self.variantRadioGroup.get()])

			if(self.performPostAnalysis.get() == 1):
				self.actual_status.set("Generating report...")
				self.ExecuteSingleOSThread(self.command_post_analysis)
			
		else:
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QAC3RD][self.variantRadioGroup.get()])
			self.actual_status.set("QAC analysis finished...")

			self.actual_status.set("Starting QAC Viewer..")
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QAC3VIEW][self.variantRadioGroup.get()])

		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()


	# -------------------------------------------------------------------------
	# Function to view QAC analysis results of the project.
	# -------------------------------------------------------------------------

	def QACViewAll(self):

		print " "
		print "---------------------------"
		print "Execute QAC Viewer - ALL..."
		print "---------------------------"

		''' before launching the viewer, we test if the analysis has already be done '''
		if self.onlyThirdPartyAnalysis.get() == False:
			projectFile = self.qacOutpath + "project_out\\QAC_FILES.lst"
		else:
			projectFile = self.qacOutpath + "third_party_out\\QAC_FILES.lst"

		if os.path.exists(projectFile):
			self.actual_status.set("Starting QAC Viewer..")
			if self.onlyThirdPartyAnalysis.get() == False:
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACVIEW][self.variantRadioGroup.get()])
			else:
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QAC3VIEW][self.variantRadioGroup.get()])
		else:
			tkMessageBox.showerror("QAC viewer error", "The project has still not been analyzed!\nPlease run the QAC analyze.")

			
	# -------------------------------------------------------------------------
	# Function to execute QAC analysis of a module.
	# -------------------------------------------------------------------------

	def QACAnalysisMod(self):

		''' If the parser and the GHS parser optimisation is used: '''
		''' the analysis is done only if the include list is based on the project specific dir list [RCM Activity EBRCM00065125] '''
		if (self.component_QAC_PARSER_active == True) & (self.component_QAC_PARSER_OPT_active == "GHS") &\
		(self.newSourceDirectory.IsIncDirListParserWithoutOptimisationUsed() == True):
			tkMessageBox.showerror("QAC Analysis", "Can not analyse the project!\n\nIn order to run a QAC analysis, you first have to build the project.\nPlease restart the GUI after.")
			''' End: no analysis is possible because of the wrong include list '''
			return

		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()

		print " "
		print "-----------------------"
		print "Execute QAC - Module..."
		print "-----------------------"

		self.actual_status.set("Starting QAC..")
		
		
		''' Check if the user chose a module '''
		localString = self.moduleName.get()
		if localString == "Select Module":
			tkMessageBox.showerror("Selection error", "Please select module first!\n")
			return
		if localString.find('\\') != -1:
			firstHalfIndex = localString.index('\\') + 1
			subDirString = localString[firstHalfIndex:]
		else:
			subDirString = localString
		output = "Analysing module \n" + localString
		self.actual_status.set(output)
		
		
		''' Prepare QAC module analysis in case the parser is disabled '''			
		if self.component_QAC_PARSER_active == False:
			projectFile = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS.mak"
			''' the include dir list is used for the module analysis '''
			incDirs = self.newSourceDirectory.GetIncludeDirs()
			
			
		''' Prepare QAC module analysis in case the parser is enabled '''
		''' In this case, the project file has to be created according to the template file '''
		''' The project file will be then used as basis to create the module file '''
		if self.component_QAC_PARSER_active == True:
			projectFileTemplate = os.environ.get("BCMF_CFG_ROOT") + "\\PROJECT_DIRS_TEMPLATE.mak"
			projectFile = self.qacTempOut + "\\PROJECT_DIRS_GENERATED.mak"
			srcDirs = self.newSourceDirectory.GetSourceDirs()
			incDirs = self.newSourceDirectory.GetIncludeDirs()
			GenerateQACDirList(srcDirs, incDirs, projectFileTemplate, projectFile, 'BCMF_SOFTWARE_BASE', False, False)
		
		
		''' Module file creation '''
		moduleFile = self.qacTempOut + "\\MODULE_DIRS_GENERATED.mak"
		analysisFile = self.qacTempOut + "\\ANALYSIS_DIRS.mak"
		''' the module directory list is updated if:
		 - the user choose another module OR
		 - the filter dependencies checkbox state has changed '''
		if (self.modulenameOld != localString) | (self.filter_dependencies_button_state != self.filter_dependencies_button_state_old):
			print "Generating source directory list..." 
			GenerateQACDirModuleList(incDirs, projectFile, moduleFile, self.sourceDir, self.moduleName.get(), self.filterDependencies.get(), self.configuration_file)

		''' The module file is copied only if it has changed, otherwise the timestamp will be 
		changed unnecessarily and omake does detect changed dependencies incorrectly 
		Note: This can also happen if a project analysis was done before, so always check 
			  if the analysis file has been changed'''
		if(os.path.exists(analysisFile)==FALSE):
			shutil.copyfile(moduleFile, analysisFile)
		else:
			if (filecmp.cmp(moduleFile, analysisFile) == 0):
				shutil.copyfile(moduleFile, analysisFile)

		self.modulenameOld = localString
		print "Analysing..."
		self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACMOD][self.variantRadioGroup.get()])
		
		
		''' rename the outputfiles according to the modules '''
		
		''' the report file '''
		reportFile = self.qacOutpath + "module_out\\report.html"
		newName = self.qacOutpath + "module_out\\" + subDirString + "_report.html"
		if os.path.exists(newName):
			os.remove(newName)
		'''os.rename(reportFile, newName)'''
		shutil.copy(reportFile, newName)

		''' the result file '''
		resultFile = self.qacOutpath + "module_out\\QAC_Summary.txt"
		newName = self.qacOutpath + "module_out\\" + subDirString + "_results.txt"
		if os.path.exists(newName):
			os.remove(newName)
		'''os.rename(resultFile, newName)'''
		shutil.copy(resultFile, newName)

		''' the list file '''
		listFile = self.qacOutpath + "module_out\\QAC_FILES.lst"
		newName = self.qacOutpath + "module_out\\" + subDirString + "_FILES.lst"
		if os.path.exists(newName):
			os.remove(newName)
		shutil.copy(listFile, newName)

		''' metrics analysis '''
		#parameters preparation
		__metFilesPath	= self.qacOutpath + "module_out"
		__metFileCMA	  = "No"
		__metConfigFile   = self.metrics_configuration_file
		__projectDatabase = "No"
		__databaseFilter  = "No"
		__printErrorLog   = "No"
		
		#launch script as a single OS thread (standalone script)
		__command = "%s %s\\jenkinsServer\\Rb_MetricsAnalysis.py %s %s %s %s %s %s" % (self.pythonExe,self.scriptsPath,__metFilesPath,__metFileCMA,__metConfigFile,__projectDatabase,__databaseFilter,__printErrorLog)
		self.ExecuteSingleOSThread(__command)
		
		#open results
		self.QACMetricsMod()
		
		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()

		if localString != "Select Module":
			self.actual_status.set("Starting QAC Viewer..")
			self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()])


	# -------------------------------------------------------------------------
	# Function to view QAC analysis results of the module.
	# -------------------------------------------------------------------------
	
	def QACViewerMod(self):

		print " "
		print "-----------------------"
		print "Execute QAC Viewer - Module..."
		print "-----------------------"

		localString = self.moduleName.get()

		if localString == "Select Module":
			tkMessageBox.showerror("Selection error", "Please select module first!\n")
		else:
			if localString.find('\\') != -1:
				firstHalfIndex = localString.index('\\') + 1
				subDirString = localString[firstHalfIndex:]
			else:
				subDirString = localString

			''' rename the list file '''
			listFile = self.qacOutpath + "module_out\\QAC_FILES.lst"
			moduleFile = self.qacOutpath + "module_out\\" + subDirString + "_FILES.lst"
			if os.path.exists(moduleFile):
				if os.path.exists(listFile):
					os.remove(listFile)
				shutil.copy(moduleFile, listFile)
				self.actual_status.set("Starting QAC Viewer..")
				self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_QACMVIEW][self.variantRadioGroup.get()])
			else:
				tkMessageBox.showerror("Selection error", "No results for this module!\n")
		
	
	# -------------------------------------------------------------------------
	# Function to view QAC analysis results of the module.
	# -------------------------------------------------------------------------
	
	def QACMetricsMod(self):
		__command = "start %s" % self.metricsAnalysisResultFile
		self.ExecuteSingleOSThread(__command)
		
	
	# -------------------------------------------------------------------------
	# Function to generate all m files
	# -------------------------------------------------------------------------

	def GenerateMFiles(self):
		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
		
		self.PrintVariantDOSLabel("Generate M files", False)
		self.actual_status.set("Generating M files...")
		genClass = MFileGen()
		genClass.MFileGenerate(self.mfile_configuration_file)
		print "Complete.."
		self.actual_status.set("Complete...")
		
		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()


	# -------------------------------------------------------------------------
	# Function to execute eclipse.
	# -------------------------------------------------------------------------

	def EclipseExecute(self):
		self.PrintVariantDOSLabel("Execute eclipse", False)
		self.actual_status.set("Starting Eclipse...")

		''' If the parser is enabled for Eclipse, a batch file is generated to set some include environment variables '''
		if self.component_ECLIPSE_PARSER_active == True:
			
			''' if the parser is not ready, the toolchain waits before starting Eclipse '''
			''' the Eclipse button state is disable in this case in the function updateGUI '''
			if self.newSourceDirectory.threadRunning == True:
				self.EclipseStartSuspended = True
				self.UpdateGUI()
				return
				
			print "Generating Eclipse batch file... "
			incDirs = self.newSourceDirectory.GetIncludeDirs()
			tempOutpath = os.environ.get("BCMF_TEMP_OUT")
			outputFile = tempOutpath + "\\headerPaths.bat"
			__includeDirectories = IncludeDirectories(outputFile, incDirs)
			print "Number of generated environment variables: " + str(__includeDirectories.GetSetCommandNumber()) + " (used for the Eclipse parser)"
				
		self.ExecuteSingleOSThread(self.command_eclipse)

		
	# -------------------------------------------------------------------------
	# Function to generate documentation.
	# -------------------------------------------------------------------------

	def GenerateDocumentation(self):
		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
		
		self.PrintVariantDOSLabel("Documentation generation", True)
		self.actual_status.set("Generating Doc...")
		self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_DOXYGEN][self.variantRadioGroup.get()])

		print "Complete.."
		self.actual_status.set("Complete...")

		''' update GUI enabling all controls '''
		self.controls_enabled = True
		self.UpdateGUI()
		

		
	# -------------------------------------------------------------------------
	# Function to view generated documentation - Windiows help format.
	# -------------------------------------------------------------------------

	def ViewHELPDocumentation(self):
		self.PrintVariantDOSLabel("Viewing help (Windows Format) documentation", True)
		print "Checking out help file..."
		command_string = "cleartool checkout -unreserved -c \"BCMF Builder AutoCheckout...\" " + "..\\_doc_output\\windows_help\\bcmf_project.chm"
		subprocess.call(command_string)
		self.ExecuteSingleOSThread(self.commandArray[CFG_PREFIX_DOCHELP][self.variantRadioGroup.get()])


		
	# -------------------------------------------------------------------------
	# Function to view gui help.
	# -------------------------------------------------------------------------

	def Help(self):
		self.PrintVariantDOSLabel("Viewing GUI help", False)
		self.ExecuteSingleOSThread(self.command_help_viewer)

	
	# -------------------------------------------------------------------------
	# Function to get the WinIDEA local path
	# -------------------------------------------------------------------------
	
	def GetWinideaLocalPath(self):
		''' we read the local path only if WinIDEA is used in the project '''
		if CFG_EMULATOR_MODULE in self.configuration:
			if (self.configuration[CFG_EMULATOR_MODULE] == CFG_REQUIRED):
				
				try:
					''' WinIDEA has already been installed: we used the current path '''
					__hKey = OpenKey (HKEY_CLASSES_ROOT, r".xjrf\shell\open\command")
					__value, __type = QueryValueEx (__hKey,"")
					# "value" can have the following form: C:\iSYSTEM\winIDEA\2012\winIDEA.exe "%1" 
					# -> we just keep C:\\iSYSTEM\\winIDEA\\2012
					__result = re.split("\winIDEA.exe", __value)
					os.environ['WINIDEA_LOCAL'] = __result[0]
					print "Info: The following WinIDEA path has been found in your registry: " + __result[0]
				except:
					''' No WinIDEA installation on this system: we let WinIDEA set the install path '''
					pass
					
	
	# -------------------------------------------------------------------------
	# Function to install WinIDEA
	# -------------------------------------------------------------------------

	def InstallWinIdea(self):
		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
		
		self.PrintVariantDOSLabel("Install WinIDEA", False)
		self.actual_status.set("Installing WinIDEA...")
		self.status_label.config(background='red')

		__command_install_winidea   = "start %BCMF_WINIDEA_ROOT%\_installWinIDEA.bat"
		self.ExecuteSingleOSThread(__command_install_winidea)

		''' a thread is launched to check the installation status '''
		self.threadInstallWinIdeaExist = 1
		self.threadInstallWinIdea = ThreadedInstallWinIdea()
		self.threadInstallWinIdea.setName("Emulator_Installation")
		self.threadInstallWinIdea.setDaemon(True)
		self.threadInstallWinIdea.start()


		
	# -------------------------------------------------------------------------
	# Function to update WinIDEA
	# -------------------------------------------------------------------------

	def UpdateWinIdea(self):
		''' update GUI disabling all controls '''
		self.controls_enabled = False
		self.UpdateGUI()
		
		self.PrintVariantDOSLabel("Update WinIDEA", False)
		self.actual_status.set("Updating WinIDEA...")
		self.status_label.config(background='red')

		__command_update_winidea = "start %BCMF_WINIDEA_ROOT%\_updateWinIDEA.bat"
		self.ExecuteSingleOSThread(__command_update_winidea)

		''' we deactivate the button after the user clicked once '''
		try:
			self.WinIdea_update_button.config(state=DISABLED)
		except AttributeError:
			''' this kind of error is in this case ignored '''
			pass

		''' a thread is launched to check the update status '''
		self.threadUpdateWinIdeaExist = True
		self.threadUpdateWinIdea = ThreadedUpdateWinIdea()
		self.threadUpdateWinIdea.setName("Emulator_Update")
		self.threadUpdateWinIdea.setDaemon(True)
		self.threadUpdateWinIdea.start()


		
	# -------------------------------------------------------------------------
	# Function to clear the status screen.
	# -------------------------------------------------------------------------

	def ClearStatusScreen(self):
		os.system("cls")



	# -------------------------------------------------------------------------
	# Function to start the GUI.
	# Function is entered when gui is exited through "quit"
	# -------------------------------------------------------------------------

	def ExecuteGUI(self):
		self.gui.mainloop()

		''' call shutdown routine '''
		self.ShutGUIDown()



	# -------------------------------------------------------------------------
	# Function to shutdown the program.
	# Function is entered after "quit" processing or upon forcing the
	# GUI closed.
	# -------------------------------------------------------------------------

	def ShutGUIDown(self):
		self.PrintVariantDOSLabel("EXECUTING SHUTDOWN. Open shell commands (i.e. build, rebuild) will finish.", False)

		self.newSourceDirectory.stop()

		# TO DO replace the WinIDEA shutdown part by a special function
		if self.threadInstallWinIdeaExist == True:
			self.threadInstallWinIdea.stop()

		if self.threadUpdateWinIdeaExist == True:
			self.threadUpdateWinIdea.stop()

		''' save GUI settings '''
		self.SaveUserGUISettings(self.variantRadioGroup.get())
			
		''' exit of the program - hard exit - terminate all threads'''
		raise SystemExit


				
	# -------------------------------------------------------------------------
	# News function
	# Function to popup a news message while opening the GUI
	# - The function can be enabled / disabled via NEWS_POPUP in the GUI config file
	# - The news is print only once in these 2 cases: 
	#	   * if a tmp file has not been created in the script tmp output
	#	   * if the news version is newer than the one in the tmp file
	# - The news can be edited in the file ToolChainNewsMessage.txt
	#	   * its version is kept in this file and incremented for each new news
	# -------------------------------------------------------------------------

	def ToolChainNews(self):
		if self.component_NEWS_active == True:
				
			''' read news file '''
			try:
				tmpFile = os.environ.get("BCMF_CFG_ROOT") + "\\ToolChainNewsMessage.txt"
				f = open(tmpFile, "r")
				contentNewsListedFile = f.readlines()
				f.close()

				''' get news version and file content'''
				versionFound = False
				for line in contentNewsListedFile:
					if re.findall("Version=", line):
						result = re.split("=", line)
						version = result[1]
						versionFound = True
				if versionFound == False: 
					''' error with the version in the news file '''
					print "\nError with the tool chain news function!!"
					print "The file " + tmpFile + " contains an error with the version string."
					print "Please verify that the file begins with Version=[version number]\n\n"
					return
			
				''' if the tmp file exists, the news has already been published '''
				''' the news version is then compared with the tmp news version'''
				try:
					tmpFile = os.environ.get("BCMF_TEMP_OUT") + "\\newsTmp.txt"
					f2 = open(tmpFile, "r")
					contentTempListedFile = f2.readlines()
					f2.close()
					if contentTempListedFile[0] != version:
						raise IOError
						
				except:
					''' if the file does not exists or the news is newer, the news is printed '''
					del contentNewsListedFile[0]	# the news version is not required to be printed
					str = ""
					for line in contentNewsListedFile:
						str = str + line
					tkMessageBox.showinfo("Tool chain news", str)
					''' write the news version in the temp file '''
					try:
						f3 = open(tmpFile, "w")
						print >> f3, version
						f3.close()
					except:
						''' error with the news file newsTmp.txt '''
						print "\nError with the tool chain news function!!"
						print "The file newsTmp.txt can not be created.\n\n"
			
			except:
				''' error with the news file ToolChainNewsMessage.txt '''
				print "\nError with the tool chain news function!!"
				print "The file " + tmpFile + " can not be opened.\n\n"
			
		
		
	# -------------------------------------------------------------------------
	# What's new? function
	# Popup a news message if the user clicks on the what's new? button
	# -------------------------------------------------------------------------
	def WhatsNew(self):
		if self.component_NEWS_active == True:
		
			''' read news file '''
			try:
				tmpFile = os.environ.get("BCMF_CFG_ROOT") + "\\ToolChainNewsMessage.txt"
				f = open(tmpFile, "r")
				contentNewsListedFile = f.readlines()
				f.close()
				i = 1;
			except:
				''' error with the news file ToolChainNewsMessage.txt '''
				print "\nError with the tool chain news function!!"
				print "The file " + tmpFile + " can not be opened.\n\n"
				return
			
			content=""
			for line in contentNewsListedFile:
				''' the 3 first lines are not printed '''
				if (i != 1) and (i != 2) and ((i != 3) or (line != "\n")):
					content = content+line
				i = i + 1
			
			tkMessageBox.showinfo('What\'s new?', content)
	

	def MergingOutputFiles(self):
		# checking existence of files
		app_file_name = r"%s\Appl_XMC12vHigh.s19" % (os.environ.get("BCMF_BUILD_OUTPUT"))
		fbl_file_name = r"%s\FBL_XMC.s19" % (os.environ.get("BCMF_BUILD_OUTPUT"))
		
		if(os.path.isfile(app_file_name) and os.path.isfile(fbl_file_name)):
			# merge files
			cmd = r"%s /MO:%s;0:0x00F8C000,0x00FAFFFF+%s;0:0x00FD8000,0x0127FFFF /XS:28 -o %s /s" % (r"%s\HexView\hexview.exe" % os.environ.get("BCMF_TOOLS_ROOT"),
																									 os.environ.get("BCMF_BUILD_OUTPUT") + r"\FBL_XMC.s19",
																									 os.environ.get("BCMF_BUILD_OUTPUT") + r"\Appl_XMC12vHigh.s19",
																									 os.environ.get("BCMF_BUILD_OUTPUT") + r"\XMC12vHigh_Mergred.s19")
			self.ExecuteSingleOSThread(cmd)
			
			# add 0102030405060708090A0B0C0D0E0F10
			cmd = r"%s %s /CR:0x0127FFE0,16 /XS:28 -o %s /s" % (r"%s\HexView\hexview.exe" % os.environ.get("BCMF_TOOLS_ROOT"),
																os.environ.get("BCMF_BUILD_OUTPUT") + r"\XMC12vHigh_Mergred.s19",
																os.environ.get("BCMF_BUILD_OUTPUT") + r"\XMC12vHigh_Mergred.s19")
			self.ExecuteSingleOSThread(cmd)
			cmd = r"%s %s /FR:0x0127FFE0,16 /FP:0102030405060708090A0B0C0D0E0F10 /XS:28 -o %s /s" % (r"%s\HexView\hexview.exe" % os.environ.get("BCMF_TOOLS_ROOT"),
																									 os.environ.get("BCMF_BUILD_OUTPUT") + r"\XMC12vHigh_Mergred.s19",
																									 os.environ.get("BCMF_BUILD_OUTPUT") + r"\XMC12vHigh_Mergred.s19")
			self.ExecuteSingleOSThread(cmd)
		else:
			tkMessageBox.showinfo("Info", "Need APPL and FBl s19 files for merging.\nPlease make sure both are built")
			
# -------------------------------------------------------------------------
# MAIN program.
# -------------------------------------------------------------------------

if __name__ == '__main__':

	try:
		''' set up a command line instance of the class'''
		bcmf_builder_main = BCMFBuilder(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])

		''' manage the project options and GUI widgets '''
		bcmf_builder_main.UpdateGUI()
		
		''' for the first launch of the GUI: print a news message to inform the user '''
		bcmf_builder_main.ToolChainNews()


	except IndexError:

		error_message = "Usage: python buildGUI.py config_file.cfg version_config.cfg"

		print "\n" + "-" * len(error_message)
		print error_message
		print "-" * len(error_message) + "\n"
		raise

	''' start the GUI '''
	bcmf_builder_main.ExecuteGUI()
