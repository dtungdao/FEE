# generateDirList.py - Class and fucntionality for BCMF build GUI
#
# G. Robinson (AE-BE/ENG5)
# 18-02-2008
#
# Revision history:
#
# Version 001.00 - 13.08.2008 - S. Weber (AE-BE/ENG3)
#   Initial revision. 
# Version 002.00 - 20.01.2009 - S. Weber (AE-BE/ENG3)
#   Pruned the directory list so that the parsing takes less time
# Version 002.01 - 22.01.2009 - S. Weber (AE-BE/ENG3)
#   Removed the test directories and all _xx-directories:
#   _xx-directries are not checked anyway, and test directories have to be
#   analysed as well!
# Version 002.02 - 08.02.2010 - S. Weber (AE-BE/ENG31-AU)
#   Adapted module so the resulting filelist can be used for multiple purposes
#----------------------------------------------------------------------------------------
# Version 003.00 - 20.04.2011 - C. Baudry (AE-BE/ENG3)
#   RCM85194: The exclude list is read from the GUI configuration file
#   A log file is created with the exclude, source and include lists
#----------------------------------------------------------------------------------------


''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import the configuration file handler '''
from configFile import ConfigFile


''' Main class '''
class GenerateDirList:

    def __init__(self, topLevelDir, configuration_file):

        ''' Get the subdirectories in the toplevel directory: '''
        self.topDir = topLevelDir
        dirList = []
        
        ''' prepare the exclude list '''
        searchExcludeList = ConfigFile(configuration_file).ParserExcludeList()
                             
        print "Walking source directory: [",
        for root, dirs, files in os.walk(self.topDir, True):
            print ".",
            for expr in searchExcludeList:
                if expr in dirs:
                    dirs.remove(expr)  # don't visit directory

            tupel = root, dirs, files
            dirList.append(tupel)
        print "]"
        self.allSubdirsC = []
        self.allSubdirsH = []

        ''' sort the tuple, just take the entries where there are c or h files in the subdirectory '''
        print "Seaching for c and h-files: [",
        for entry in dirList:
            print ".",
            cPass = False
            hPass = False
            for string in entry[2]:
                '''check for c files. Once we have found one, we stop'''
                if (string[-2:] == '.c') and (cPass == False):
                    ''' copy entry into list '''
                    self.allSubdirsC.append(entry[0])
                    cPass = True
                '''check for h files. Once we have found one, we stop'''
                if (string[-2:] == '.h') and (hPass == False):
                    ''' copy entry into list '''
                    self.allSubdirsH.append(entry[0])
                    hPass = True
                '''if both a c and a h file have been found we can end the loop
                   otherwise continue searching'''
                if (hPass == True) and (cPass == True):
                    break
        print "] Done!"

        ''' create log file '''
        parserLogFile = os.environ.get("BCMF_TEMP_OUT") + "\\ParserLOGFile.txt"
        try:
            f = open(parserLogFile, "w")
            f.write("Parser log file\n\n")
            f.write("--Exclude list:\n")
            for element in searchExcludeList:
                f.write(element + "\n")
            f.write("\n--Source list:\n")
            for element in self.allSubdirsC:
                f.write(element + "\n")
            f.write("\n--Include list:\n")
            for element in self.allSubdirsH:
                f.write(element + "\n")
            f.close()
        except:
            ''' error with the log file '''
            print "\n\nError with the parser!!"
            print "The parser log file can not be created.\n\n"
        

    def GetSourceDirList(self):
        return self.allSubdirsC
        

    def GetIncludeDirList(self):
        return self.allSubdirsH
        
        

if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        bcmf_builder_main = GenerateDirList(sys.argv[1], sys.argv[2])

    except IndexError:

        error_message = "wrong number of parameters"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
