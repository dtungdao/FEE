# generateGHSDirList.py - Class and fucntionality for BCMF build GUI
#
# C. Baudry (AE_BE/ENG3)
# 26.02.2010
#
# Revision history:
#
# Version 001.00 - 26.02.2010 -  C. Baudry (AE_BE/ENG3)
#   Initial revision. 
#---------------------------------------------------------------------------
# Version 001.01 - 04.05.2010 -  C. Baudry (AE_BE/ENG3)
#   The way to delete unrequired elements in the SRC list has been optimized
#---------------------------------------------------------------------------
# Version 001.02 - 05.05.2010 -  C. Baudry (AE_BE/ENG3)
#   Modifications required due to compiler update 517: the path given by gbuild 
#      is sometimes absolut and sometimes relative
#---------------------------------------------------------------------------
# Version 001.03 - 12.07.2010 -  C. Baudry (AE_BE/ENG3)
#   The absolut path given by gbuild are not taken into account: they are SW 
#      part which are not done by RB: compiler files, RTA-OS lib

''' required for system arguments '''
import sys

''' import os for executing commands '''
import os

''' import re for regular expressions '''
import re

''' import threading '''
import threading

''' import subprocess for executing commands '''
import subprocess


''' Main class '''
class GenerateGHSDirList:

    def __init__(self, commandSource, commandInclude):
        
        self.tempOutpath = os.environ.get("BCMF_TEMP_OUT")
        self.sofwarePath = os.environ.get("BCMF_SOFTWARE_BASE")
        
        ''' results tables '''
        self.allSubdirsC = []
        self.allSubdirsH = []
        
        ''' temporary variables '''
        self.GHScommandResult = ""
        self.tempAllSubdirsC = []
        self.tempAllSubdirsH = []
        
        
        ''' GENERATE SOURCE FILES LIST '''
        
        ''' get the list of all source files contained in the GHS project '''
        SourcesTempFile = self.tempOutpath + "\\GHSListSourcesTempFile.txt"
        self.GHScommand = commandSource + " > " + SourcesTempFile
        os.system(self.GHScommand)
        
        ''' read the temporary file where the command results is saved'''
        GHSListFile = open(SourcesTempFile)
        GHSListFileData = GHSListFile.read()
        GHSListFile.close()
        
        ''' the file content is converted in a list '''
        self.allSubdirsC = GHSListFileData.splitlines()
        
        ''' the spaces are deleted '''
        for index in range(len(self.allSubdirsC)):
            self.allSubdirsC[index] = self.allSubdirsC[index].lstrip()

        ''' we delete from the list what we do not need '''
        ''' .gpj paths are not required '''
        self.allSubdirsC = [element for element in self.allSubdirsC if (re.search("\.gpj", element) == None)]
        ''' .ld paths are not required '''
        self.allSubdirsC = [element for element in self.allSubdirsC if (re.search("\.ld", element) == None)]
        
        ''' if the path is absolut (without ".." at the beginning), we remove it: it is not appart of the RB SW; ex: compiler include files '''
        self.allSubdirsC = [element for element in self.allSubdirsC if (element[:2] == "..")]
        
        ''' we remove the file name to keep only the directory name '''
        for index in range(len(self.allSubdirsC)):
            result = os.path.split(self.allSubdirsC[index])
            self.allSubdirsC[index] = result[0]
        
        ''' we delete the double entries in the list '''
        for element in self.allSubdirsC:
            try:
                ind = self.tempAllSubdirsC.index(element)
            except:
                self.tempAllSubdirsC.append(element)
        
        ''' we delete the first double points of each entry if required'''
        ''' we complete the path to go from the script folder '''
        for index in range(len(self.tempAllSubdirsC)):
            if self.tempAllSubdirsC[index][:2] == "..":
                self.tempAllSubdirsC[index] = self.tempAllSubdirsC[index][2:] 
                self.tempAllSubdirsC[index] = self.sofwarePath + self.tempAllSubdirsC[index]
        
        ''' the temporary list is saved on the result list '''
        self.allSubdirsC = self.tempAllSubdirsC
             

        ''' GENERATE INCLUDE FILES LIST '''
        
        ''' get the list of all include files contained in the GHS project '''
        includesTempFile = self.tempOutpath + "\\GHSListIncludesTempFile.txt"
        self.GHScommand = commandInclude + " > " + includesTempFile
        os.system(self.GHScommand)
        
        ''' read the temporary file where the command results is saved'''
        GHSListFile = open(includesTempFile)
        GHSListFileData = GHSListFile.read()
        GHSListFile.close()
        
        ''' the file content is converted in a list '''
        self.allSubdirsH = GHSListFileData.splitlines()
        
        ''' if the list is empty, the command did not return any result which means that the project has still not been compiled '''
        ''' the user has to compile at least the project once to get the dependency list '''
        if len(self.allSubdirsH) != 0: 
            ''' the spaces are deleted '''
            for index in range(len(self.allSubdirsH)):
                self.allSubdirsH[index] = self.allSubdirsH[index].lstrip()
                
            ''' if the path is absolut (without ".." at the beginning), we remove it: it is not appart of the RB SW; ex: compiler include files '''
            self.allSubdirsH = [element for element in self.allSubdirsH if (element[:2] == "..")]
            
            ''' we remove the file name to keep only the directory name '''
            for index in range(len(self.allSubdirsH)):
                result = os.path.split(self.allSubdirsH[index])
                self.allSubdirsH[index] = result[0]
            
            ''' we delete the double entries in the list '''
            for element in self.allSubdirsH:
                try:
                    ind = self.tempAllSubdirsH.index(element)
                except:
                    self.tempAllSubdirsH.append(element)
            
            ''' we delete the first double points of each entry when it is required'''
            ''' we complete the path to go from the script folder when it is required'''
            for index in range(len(self.tempAllSubdirsH)):
                if self.tempAllSubdirsH[index][:2] == "..":
                    self.tempAllSubdirsH[index] = self.tempAllSubdirsH[index][2:] 
                    self.tempAllSubdirsH[index] = self.sofwarePath + self.tempAllSubdirsH[index]
            
            ''' the temporary list is saved on the result list '''
            self.allSubdirsH = self.tempAllSubdirsH
        else:
            '''no way to go on with the script!!! '''
        
    def GetSourceDirList(self):
        return self.allSubdirsC

    def GetIncludeDirList(self):
        return self.allSubdirsH

if __name__ == '__main__':

    try:
        ''' set up a command line instance of the class'''
        bcmf_builder_main = GenerateGHSDirList(sys.argv[1], sys.argv[2])

    except IndexError:

        error_message = "wrong number of parameters"

        print "\n" + "-" * len(error_message)
        print error_message
        print "-" * len(error_message) + "\n"
        raise
