#! /usr/bin/perl -w

package ELF;


sub do_symtab_entry {
  my ($self, $str, $rhash) = @_;

  (
   $$rhash{'st_name'},
   $$rhash{'st_value'},
   $$rhash{'st_size'},
   $$rhash{'st_info'},
   $$rhash{'st_other'},
   $$rhash{'st_shndx'}
  )
    = unpack($self->{'s_symtab'}, $str);
}


sub do_shdr {
  my ($self, $str, $rhash) = @_;

  (
   $$rhash{'sh_name'},
   $$rhash{'sh_type'},
   $$rhash{'sh_flags'},
   $$rhash{'sh_addr'},
   $$rhash{'sh_offset'},
   $$rhash{'sh_size'},
   $$rhash{'sh_link'},
   $$rhash{'sh_info'},
   $$rhash{'sh_addralign'},
   $$rhash{'sh_entsize'}
  )
    = unpack($self->{'s_shdr'}, $str);
}


sub rdo_shdr {
  my ($self, $rhash) = @_;

  my $str = pack($self->{'s_shdr'},
		 $$rhash{'sh_name'},
		 $$rhash{'sh_type'},
		 $$rhash{'sh_flags'},
		 $$rhash{'sh_addr'},
		 $$rhash{'sh_offset'},
		 $$rhash{'sh_size'},
		 $$rhash{'sh_link'},
		 $$rhash{'sh_info'},
		 $$rhash{'sh_addralign'},
		 $$rhash{'sh_entsize'}
		);

  return $str;
}


sub do_phdr {
  my ($self, $str, $rhash) = @_;

  (
   $$rhash{'p_type'},
   $$rhash{'p_offset'},
   $$rhash{'p_vaddr'},
   $$rhash{'p_paddr'},
   $$rhash{'p_filesz'},
   $$rhash{'p_memsz'},
   $$rhash{'p_flags'},
   $$rhash{'p_align'}
  )
    = unpack($self->{'s_phdr'}, $str);
}


sub rdo_phdr {
  my ($self, $rhash) = @_;

  my $str = pack($self->{'s_phdr'},
		  $$rhash{'p_type'},
		  $$rhash{'p_offset'},
		  $$rhash{'p_vaddr'},
		  $$rhash{'p_paddr'},
		  $$rhash{'p_filesz'},
		  $$rhash{'p_memsz'},
		  $$rhash{'p_flags'},
		  $$rhash{'p_align'}
		 );

  return $str;
}


sub save {
  my ($self, $fname) = @_;

  local *FH;

  $ors = $/;
  undef $/;
  open FH, "> $fname" or die "can't write-open '$fname'\n";
  binmode FH;
  print FH $self->{'raw'};
  close FH;
  $/ = $ors;
}


sub load {
  my ($self, $fname) = @_;

  my $raw;
  my $phdr;
  my $ors;
  my $i;
  my ($ix, $debug_abbrev, $abbrev_code, $tag, $has_children);
  my ($attr_name, $attr_form, $ra, $k, $fspf);
  my ($debug_info, $pV, $pv, $abbrev, $ps);
  my ($fh, $sz);
  local *FH;

#  unlink $df;
#  open(DF, ">> $df") or die "can't write-open '$df'";

  $fspf = '%08i'; # format to generate the key from the index

  open FH, "< $fname" or die "can't read-open '$fname'\n";
  binmode FH;
  $sz = -s $fname;
  $self->{'raw'} = '';
  read FH, $self->{'raw'}, $sz;
  close FH;

  $raw = \$self->{'raw'};

  $self->{'e_data'} = ord(substr($$raw, 5, 1));
  $self->{'phdr'} = [];

  if ($self->{'e_data'} == 1) { # LSB
    $pV = 'V';
    $pv = 'v';

    $self->{'V'} = 'V';
    $self->{'v'} = 'v';
    $self->{'s_head'} = 'a16vvVVVVVvvvvvv';
    $self->{'s_symtab'} = 'VVVCCv';
    $self->{'s_shdr'} = 'VVVVVVVVVV';
    $self->{'s_phdr'} = 'VVVVVVVV';

  }
  elsif ($self->{'e_data'} == 2) { # MSB
    $pV = 'N';
    $pv = 'n';

    $self->{'V'} = 'N';
    $self->{'v'} = 'n';
    $self->{'s_head'} = 'a16nnNNNNNnnnnnn';
    $self->{'s_symtab'} = 'NNNCCn';
    $self->{'s_shdr'} = 'NNNNNNNNNN';
    $self->{'s_phdr'} = 'NNNNNNNN';
  }
  else {
    die "Endianness $self->{'e_data'} unknown\n";
  }

  (
   $self->{'e_ident'},
   $self->{'e_type'},
   $self->{'e_machine'},
   $self->{'e_version'},
   $self->{'e_entry'},
   $self->{'e_phoff'},
   $self->{'e_shoff'},
   $self->{'e_flags'},
   $self->{'e_ehsize'},
   $self->{'e_phentsize'},
   $self->{'e_phnum'},
   $self->{'e_shentsize'},
   $self->{'e_shnum'},
   $self->{'e_shstrndx'}
  )
    = unpack($self->{'s_head'}, $$raw);


  for ($i = 0; $i < $self->{'e_phnum'}; $i++) {
    $self->{'phdr'}->[$i] = {};
    $phdr = substr($$raw, $self->{'e_phoff'} + $i * $self->{'e_phentsize'}, $self->{'e_phentsize'});

    $self->do_phdr($phdr, $self->{'phdr'}->[$i]);
  }


  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $self->{'shdr'}->[$i] = {};
    $phdr = substr($$raw, $self->{'e_shoff'} + $i * $self->{'e_shentsize'}, $self->{'e_shentsize'});

    $self->do_shdr($phdr, $self->{'shdr'}->[$i]);
  }
  $self->{'section_names'} = $self->{'shdr'}->[$self->{'e_shstrndx'}];
  $self->{'strtab'} = section_raw($self, section_index($self, '.strtab'));
}


# set_byte_at
sub set_byte_at {
  my ($self, $addr, $val) = @_;

  return $self->set_val_at($addr, $val, 1);
}


# set_val_at
#
# Write a value $val into the ELF file at address $adr with the length $sz.
# The endianness of the ELF file is considered and the value that is written
# can be read at runtime.
sub set_val_at {
  my ($self, $adr, $val, $sz) = @_;

  my ($i, $srect, $beg, $len, $offset);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rsect = $self->{'shdr'}->[$i];

    if ($self->is_in_rom($i)) {
      $beg = $rsect->{'sh_addr'};
      $len = $rsect->{'sh_size'};
      if ($beg <= $adr and $adr < $beg+$len+$sz) {
        $offset = $rsect->{'sh_offset'} + $adr - $beg;
        if ($self->{'e_data'} == 1) { # LSB
          for ($j = 0; $j < $sz; $j++) {
            substr($self->{'raw'}, $offset+$j, 1) = chr($val& 255);
            $val /= 256;
          }
        } elsif ($self->{'e_data'} == 2) { # MSB
          for ($j = $sz-1; $j >= 0; $j--) {
            substr($self->{'raw'}, $offset+$j, 1) = chr($val& 255);
            $val /= 256;
          }
        }
        else {
          die "set_val_at:_endianness unknown\n";
        }
        return 1;
      }
    }
  }

  return 0;
}


sub get_byte_at {
  my ($self, $addr) = @_;

  return $self->get_val_at($addr, 1);
}


# get_val_at
#
# Read a value from the ELF file from logical address $adr with
# the size $sz bytes.  The endianness of the ELF file is considered,
# so e.g. reading 4 bytes from an ELF file returns the same value
# as if it would be read at runtime by the uC.
sub get_val_at {
  my ($self, $adr, $sz) = @_;

  my ($i, $srect, $beg, $len, $offset, $ret, $j);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {

    $rsect = $self->{'shdr'}->[$i];

    if ($self->is_in_rom($i)) {
      $beg = $rsect->{'sh_addr'};
      $len = $rsect->{'sh_size'};

      if ($beg <= $adr and $adr < $beg+$len-$sz) {
        $offset = $rsect->{'sh_offset'} + $adr - $beg;

        $ret = 0;
        if ($self->{'e_data'} == 2) { # MSB
          for ($j = 0; $j < $sz; $j++) {
            $ret *= 256;
            $ret += ord(substr($self->{'raw'}, $offset+$j, 1));
          }
        } elsif ($self->{'e_data'} == 1) { # LSB
          for ($j = $sz-1; $j >= 0; $j--) {
            $ret *= 256;
            $ret += ord(substr($self->{'raw'}, $offset+$j, 1));
          }
        } else {
          $ret = undef;
        }
        return $ret;
      }
    }
  }

  return undef;
}


sub is_in {
  my ($b, $a, $l) = @_;

  if ($b <= $a and $a < $b + $l) {
    return 1;
  } else {
    return 0;
  }
}


sub is_in_rom {
  my ($self, $sect) = @_;

  return 0 if($self->{'shdr'}->[$sect]->{'sh_type'} != 1);
  return 1 if($self->{'shdr'}->[$sect]->{'sh_flags'} & 2);

  return 0;
}


sub find_sect {
  my ($self, $addr) = @_;

  my ($ret);
  my ($i, $srect, $sbeg, $slen, $offset);

  my $amin = 0xffffffff;

  $self->{'r_un_to'} = undef;

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rsect = $self->{'shdr'}->[$i];
    if (is_in_rom($self, $i)) {
      $sbeg = $rsect->{'sh_addr'};
      $slen = $rsect->{'sh_size'};
      if (is_in($sbeg, $addr, $slen)) {
        $self->{'r_un_to'} = undef;
        return $i;
      } elsif ($addr < $sbeg and $sbeg < $amin) {
        $amin = $sbeg;
        $self->{'r_un_to'} = $amin;
      }
    }
  }

  return -1;
}


# set_read_addr
#
# To continuously read from an ELF file, a read-address must be set.
# If the read-address falls into an undefined region, the continuous
# read returns a default value.  This default value can be set with
# the second parameter.
sub set_read_addr {
  my ($self, $addr, $und) = @_;

#  printf "set_read_addr %08x, %04x\n", $addr, $und;

  $self->{'r_un_to'} = undef;

  $self->{'r_und'} = $und;
  $self->{'r_addr'} = $addr;
  $self->{'r_sect'} = find_sect($self, $addr);

#  print "found section $self->{'r_sect'}\n";

  if (defined($self->{'r_sect'}) and $self->{'r_sect'} >= 0) {
    $self->{'r_beg'} = $self->{'shdr'}->[$self->{'r_sect'}]->{'sh_addr'};
    $self->{'r_len'} = $self->{'shdr'}->[$self->{'r_sect'}]->{'sh_size'};
  } else {
    $self->{'r_beg'} = undef;
    $self->{'r_len'} = undef;
  }
}


# get_byte
#
# continuously read from the ELF file, beginning from a previously set
# read-address.  That read-address is increased each time get_byte() is
# called.  If the read-address falls into an undefined range, the
# defined value for undefined values is returned.
sub get_byte {
  my ($self) = @_;

  my $addr = $self->{'r_addr'};
  my $rsect = $self->{'shdr'}->[$self->{'r_sect'}];

  my $beg = $self->{'r_beg'};
  my $len = $self->{'r_len'};

  my ($i, $srect, $offset);


#  printf "get_byte addr %08X\n", $addr;
#  printf "get_byte beg %08X\n", $beg;
#  printf "get_byte len %04X\n", $len;


  # if the read-address is in an undefined range in the ELF file,
  # r_un_to is set.  In this part, it is checked if we're reading
  # in an undefined area at the moment.
  if(defined($self->{'r_un_to'})) {
    if ($self->{'r_addr'} < $self->{'r_un_to'}) {
      $self->{'r_addr'}++;
 #     print "UNDEF 1\n";
      return $self->{'r_und'};
    }
  }

  # As we passed the previous connditional return, we at least passed
  # the previous region of undefined values or are not in an undefined region.

  # So let's check if we're in a valid region, if not, the new read-address
  if(!defined($beg) or !is_in($beg, $addr, $len)) {
    set_read_addr($self, $addr, $self->{'r_und'});

    if (defined($self->{'r_un_to'})) {
      if ($self->{'r_addr'} < $self->{'r_un_to'}) {
        $self->{'r_addr'}++;
 #       print "UNDEF 2\n";
        return $self->{'r_und'};
      }
    }

    $beg = $self->{'r_beg'};
    $len = $self->{'r_len'};
    $rsect = $self->{'shdr'}->[$self->{'r_sect'}];
    if (!is_in($beg, $addr, $len)) {
      $self->{'r_addr'}++;
 #     print "UNDEF 3\n";
      return $self->{'r_und'};
    }
  }

  $offset = $rsect->{'sh_offset'} + $addr - $beg;

  $self->{'r_addr'}++;
  return ord(substr($self->{'raw'}, $offset, 1));
}


# get_rom
#
# get a list of ROM sections, ordered by start address
sub get_rom {
  my ($self) = @_;

  my $ret = [];

  my ($i, $j, $ix, $rhash, $rstr, $name, $rtmp, $sect, $sraw);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rhash = $self->{'shdr'}->[$i];

    if($self->is_in_rom($i) and $$rhash{'sh_size'} != 0) {

      my $ix = 0;

      for($j = 0; $j < scalar(@$ret); $j++) {
        my $r1i = $$ret[$j];
        my $r1 = $self->{'shdr'}->[$r1i];

        if($$r1{'sh_addr'} < $$rhash{'sh_addr'}) {
          $ix = $j + 1;
        }
      }

      splice(@$ret, $ix, 0, $i);
    }
  }

  return $ret;
}


# overlap_min
#
# find the overlap (union) of two memory regions that might overlap
sub overlap_min {
  my ($b0, $e0, $b1, $e1) = @_;

  my ($b, $e);

  $b = $b0 < $b1 ? $b1 : $b0;
  $e = $e0 < $e1 ? $e0 : $e1;

  if($b < $e) {
    return $b, $e;
  }
  else {
    return undef, undef;
  }
}


# get_mem
#
# return the memory described by begin - end-1 as a structure
# for further processing
sub get_mem {
  my ($self, $beg, $end) = @_;

  my ($rom, $i, $st, $rhash, $rhashi, $before, $b, $e, $rhb, $rhe);

  my $ret = [];

  $rom = $self->get_rom();
  $ne = scalar(@$rom);
  $i = 0;
  $before = 0;
  $st = 0;
  while($i < $ne) {
    $rhashi = $$rom[$i];
    $rhash = $self->{'shdr'}->[$rhashi];
    $rhb = $$rhash{'sh_addr'};
    $rhe = $rhb + $$rhash{'sh_size'};

    if($st == 0) {
      ($b, $e) = overlap_min($beg, $end, $before, $rhb);
      if(defined($b)) {
        my $xx = [$b, $e, ''];
        push(@$ret, $xx);
      }

      $st = 1;
    }
    elsif($st == 1) {
      ($b, $e) = overlap_min($beg, $end, $rhb, $rhe);
      if(defined($b)) {

        my $section = substr($self->{'raw'}, $self->{'shdr'}->[$rhashi]->{'sh_offset'} + ($b - $rhb), $e-$b);
        my $xx = [$b, $e, $section];

        push(@$ret, $xx);
      }

      if($i == $ne - 1) {
        $st = 2;
      }
      else {
        $i++;
        $st = 0;
      }

      $before = $rhe;
    }
    elsif($st == 2) {
      ($b, $e) = overlap_min($beg, $end, $rhe, $end);
      if(defined($b)) {
        my $xx = [$b, $e, ''];
        push(@$ret, $xx);
      }

      $i++; #stop
    }
  }

  return $ret;
}


sub write_string_into_sym {
  my ($self, $sym, $str, $off) = @_;

  my ($i, $addr, $size, $s, $ret);

  if(!defined($off)) {
    $off = 0;
  }

  $s = $self->get_symbol($sym);
  if(!defined($s)) {
    die "symbol '$sym' not found\n";
  }

  $addr = $$s{'st_value'} + $off;
  $size = $$s{'st_size'};

  if($size - $off <= length($str)) {
    substr($str, $off + $size - 1) = '';
  }
  $str .= "\0";
  for($i = 0; $i < length($str); $i++) {
    $ret = $self->set_byte_at($addr+$i, ord(substr($str, $i, 1)));
    if($ret != 1) {
      die "could not write at address ". "$addr+$i" .", symbol '$sym', offset $i\n";
    }
  }
}


sub new {
  my ($class, $fname) = @_;
  my $self = {};

  bless $self, $class;

  $self->{'raw'} = '';
  if (defined($fname)) {
    $self->load($fname);
  }

  return $self;
}


sub get_symbol {
  my ($self, $sym_name) = @_;

  my ($i, $j, $ix, $t1, $ix2, $comp, $rhash, $rtmp, $sect, $dbg, $s);
  my (@STRTAB);

  $rtmp = {};
  $ix = 0;
  while ($ix = index($self->{'strtab'}, $sym_name, $ix), $ix != -1) {
    $t1 = substr($self->{'strtab'}, $ix-1, 1);
    if (defined($t1) and ord($t1) != 0) {
      $ix++;
    } else {
      $comp = substr($self->{'strtab'}, $ix);
      $comp =~ s/\0.*//;
      if ($comp eq $sym_name) {
        $s = substr($self->{'strtab'}, 0, $ix);
        $ix2 = $s =~ tr/\0//;

        for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
          $rhash = $self->{'shdr'}->[$i];
          if ($$rhash{'sh_type'} == 2) {
            $sect = section_raw($self, $i, '');

            for ($j = 0; $j < length($sect); $j+=16) {
              $s = substr($sect, $j, 16);
              $self->do_symtab_entry(substr($sect, $j, 16), $rtmp);
              if ($rtmp->{'st_name'} == $ix) {
                return $rtmp;
              }
            }
          }
        }
        return undef;
      } else {
        # didn't find "comp"
        $ix++;
      }
    }
  }

  return undef;
}


sub show_rom {
  my ($self) = @_;

  my ($i, $j, $rhash, $rstr, $name, $rtmp, $sect, $sraw);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rhash = $self->{'shdr'}->[$i];

    if ($self->is_in_rom($i)) {
      print sprintf "%i '%s' from 0x%08X to 0x%08X\n",
        $i, section_name($self, $i), $$rhash{'sh_addr'},
          $$rhash{'sh_addr'} + $$rhash{'sh_size'};
    }
  }
}


sub show_sections {
  my ($self) = @_;

  my ($i, $j, $rhash, $rstr, $name, $rtmp, $sect, $sraw);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rhash = $self->{'shdr'}->[$i];

    print sprintf "%i '%s' from 0x%08X to 0x%08X\n",
      $i, section_name($self, $i), $$rhash{'sh_addr'},
        $$rhash{'sh_addr'} + $$rhash{'sh_size'};
  }
}


sub p_addr {
  my ($self, $a) = @_;

  my ($ra, $i, $rp, $va, $pa, $fs, $ms);

  for($i = 0; $i < $self->{'e_phnum'}; $i++) {
    $rp = $self->{'phdr'}->[$i];
    if($rp->{'p_type'} == 1) {
      $va = $rp->{'p_vaddr'};
      $pa = $rp->{'p_paddr'};
      $fs = $rp->{'p_memsz'};
      $ms = $rp->{'p_filesz'};
      if($va <= $a and $a < $va+$fs) {
#        $ra = $pa + $a;
        $ra = $pa - $va + $a;
      }
#      print sprintf("type 1 0x%08X  0x%08X  0x%08X %i  %i\n", $va, $pa, $ra, $fs, $ms);
    }
  }

  return $ra;
}


sub shadowmem {
  my ($self, $rba, $rea, $undef, $use_phdr) = @_;

  my @SA;

  if (!defined($undef)) {
    $undef = 0xff;
  }
  my $cu = chr($undef);

  my $ret = [];

  my ($tmp, $i, $c, $a, $l, $o, $m, $va);

  $l = $#{@$rba};
  die "ELF->shadowmem(): size of begin and end arrays differ\n" if($l != $#{$rea});

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rhash = $self->{'shdr'}->[$i];

    if ($self->is_in_rom($i)) {
      $va = $$rhash{'sh_addr'};
      if($use_phdr) {
        $a = $self->p_addr($va);
      }
      else {
        $a = $va;
      }
      $c = $self->section_raw($i);

      for ($j = 0; $j <= $l; $j++) {

        if ($$rba[$j] <= $a and $a <= $$rea[$j]) {
          if (!defined($$ret[$j])) {
            $$ret[$j] = $cu x ($$rea[$j] + 1 - $$rba[$j]);
          }
          $o = $a - $$rba[$j];
          $m = $$rea[$j] + 1 - $$rba[$j] - $o;
          if ($m > length($c)) {
            $m = length($c);
          }
	  $tmp = substr($$ret[$j], $o, $m);
	  $tmp =~ s/$cu//g;
	  if($tmp ne '') {
	    print sprintf("overlap between 0x%08X - 0x%08X, offset %i\n", $$rba[$j], $$rea[$j], $o);
	    die;
	  }
	  substr($$ret[$j], $o, $m) = substr($c, 0, $m);
          substr($c, 0, $m) = '';
          $a += $m;
        }
      }
      if (length($c) > 0) {
        print sprintf("still %i bytes left at 0x%08X\n", length($c), $a);
        die;
      }
    }
  }

  for ($j = 0; $j <= $l; $j++) {
    if(defined($$ret[$j])) {
      $$ret[$j] =~ s/$cu*$//;
    }
  }

  return (1, $ret);
}


sub show_info {
  my ($self) = @_;

  my ($i, $j, $rhash, $rstr, $name, $rtmp, $sect, $sraw);

  print "ident\n";
  print hex_dump($self->{'e_ident'}, 0, 16);

  print sprintf "e_data 0x%02X\n", $self->{'e_data'};

  print sprintf "e_type 0x%04X\n", $self->{'e_type'};
  print sprintf "e_machine 0x%04X %s\n", $self->{'e_machine'},
    machname($self->{'e_machine'});
  print sprintf "e_version 0x%04X\n", $self->{'e_version'};
  print sprintf "e_entry 0x%08X\n", $self->{'e_entry'};
  print sprintf "e_phoff 0x%08X\n", $self->{'e_phoff'};
  print sprintf "e_shoff 0x%08X\n", $self->{'e_shoff'};
  print sprintf "e_flags 0x%04X\n", $self->{'e_flags'};
  print sprintf "e_ehsize 0x%08X\n", $self->{'e_ehsize'};
  print sprintf "e_phentsize 0x%04X\n", $self->{'e_phentsize'};
  print sprintf "e_phnum 0x%04X\n", $self->{'e_phnum'};
  print sprintf "e_shentsize 0x%04X\n", $self->{'e_shentsize'};
  print sprintf "e_shnum 0x%04X\n", $self->{'e_shnum'};
  print sprintf "e_shstrndx 0x%04X\n", $self->{'e_shstrndx'};

  for ($i = 0; $i < $self->{'e_phnum'}; $i++) {
    print "---- program header $i\n";
    $rhash = $self->{'phdr'}->[$i];

    print sprintf "p_type 0x%04X\n", $$rhash{'p_type'};
    print sprintf "p_offset 0x%08X\n", $$rhash{'p_offset'};
    print sprintf "p_vaddr 0x%08X\n", $$rhash{'p_vaddr'};
    print sprintf "p_paddr 0x%08X\n", $$rhash{'p_paddr'};
    print sprintf "p_filesz 0x%04X\n", $$rhash{'p_filesz'};
    print sprintf "p_memsz 0x%04X\n", $$rhash{'p_memsz'};
    print sprintf "p_flags 0x%04X\n", $$rhash{'p_flags'};
    print sprintf "p_align 0x%04X\n", $$rhash{'p_align'};
  }

  print "----------------------\n";

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    print "---- section header $i\n";
    $rhash = $self->{'shdr'}->[$i];

    print sprintf "sh_name 0x%08X '%s'\n", $$rhash{'sh_name'}, section_name($self, $i);
    print sprintf "sh_type 0x%08X '%s'\n", $$rhash{'sh_type'}, section_header_type($$rhash{'sh_type'});
    print sprintf "sh_flags 0x%08X, '%s'\n", $$rhash{'sh_flags'}, section_header_flags($$rhash{'sh_flags'});
    print sprintf "sh_addr 0x%08X\n", $$rhash{'sh_addr'};
    print sprintf "sh_offset 0x%08X\n", $$rhash{'sh_offset'};
    print sprintf "sh_size 0x%08X\n", $$rhash{'sh_size'};
    print sprintf "sh_link 0x%08X\n", $$rhash{'sh_link'};
    print sprintf "sh_info 0x%08X\n", $$rhash{'sh_info'};
    print sprintf "sh_addralign 0x%08X\n", $$rhash{'sh_addralign'};
    print sprintf "sh_entsize 0x%08X\n", $$rhash{'sh_entsize'};
  }
  print "----------------------\n";

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    $rhash = $self->{'shdr'}->[$i];
    if ($$rhash{'sh_type'} == 2) {
      $sect = section_raw($self, $i, '');
      for ($j = 0; $j < length($sect); $j += 16) {
        print "---- section $i, sym at $j\n";
        $rtmp = {};
        $self->do_symtab_entry(substr($sect, $j, 16), $rtmp);
        $sraw = section_raw($self, section_index($self, '.strtab'));
        $sname = substr($self->{'strtab'}, $$rtmp{'st_name'});
        $sname =~ s/\0.*//;

        print sprintf "st_name 0x%08X '%s'\n", $$rtmp{'st_name'}, $sname;
        print sprintf "st_value 0x%08X\n", $$rtmp{'st_value'};
        print sprintf "st_size 0x%08X\n", $$rtmp{'st_size'};
        print sprintf "st_info 0x%08X\n", $$rtmp{'st_info'};
        print sprintf "st_other 0x%08X\n", $$rtmp{'st_other'};
        print sprintf "st_shndx 0x%08X\n", $$rtmp{'st_shndx'};

      }
    }
  }
}


sub section_index {
  my ($self, $sname) = @_;

  my ($i);

  for ($i = 0; $i < $self->{'e_shnum'}; $i++) {
    if (section_name($self, $i) eq $sname) {
      return $i;
    }
  }

  return -1;
}


sub section_name {
  my ($self, $num) = @_;

  my ($rstr, $rhash, $name, $sname);

  $sname = undef;

  $rstr = $self->{'section_names'};
  $name = substr($self->{'raw'}, $rstr->{'sh_offset'}, $rstr->{'sh_size'});
  $rhash = $self->{'shdr'}->[$num];

  $sname = substr($name, $$rhash{'sh_name'});
  $sname =~ s/\0.*//;

  return $sname;
}


sub section_offset {
  my ($self, $num, $sname) = @_;

  my ($rstr, $name, $ix);

  if (defined($sname) and !defined($num)) {
    $num = $self->section_index($sname);
  }

  $ix = $self->{'e_shoff'} + $num * $self->{'e_shentsize'};

  return $ix;
}


sub pheader_offset {
  my ($self, $num) = @_;

  my ($rstr, $ix);

  $ix = $self->{'e_phoff'} + $num * $self->{'e_phentsize'};

  return $ix;
}


sub get_section_header {
  my ($self, $num, $sname) = @_;

  my $rh = {};

  my $off = $self->section_offset($num, $sname);

  $self->do_shdr(substr($self->{'raw'}, $off), $rh);

  return $rh;
}


sub set_section_header {
  my ($self, $num, $sname, $rh) = @_;

  my $off = $self->section_offset($num, $sname);
  my $s = $self->rdo_shdr($rh);
  my $l = length($s);

  substr($self->{raw}, $off, $l) = $s;
}


sub get_program_header {
  my ($self, $num) = @_;

  my $rh = {};

  my $off = $self->pheader_offset($num);

  $self->do_phdr(substr($self->{'raw'}, $off), $rh);

  return $rh;
}


sub set_program_header {
  my ($self, $num, $rh) = @_;

  my $off = $self->pheader_offset($num);
  my $s = $self->rdo_phdr($rh);
  my $l = length($s);

  foreach my $k (keys %$rh) {
    print sprintf "++ %s - 0x%08X\n", $k, $$rh{$k};
  }

  substr($self->{raw}, $off, $l) = $s;
}


sub section_raw {
  my ($self, $num , $sname) = @_;

  my ($rstr, $name, $section);

  if (defined($sname) and !defined($snum)) {
    $snum = $self->section_index($sname);
  }

  $rstr = $self->{'section_names'};
  $name = substr($self->{'raw'}, $rstr->{'sh_offset'}, $rstr->{'sh_size'});

  $section = substr($self->{'raw'}, $self->{'shdr'}->[$num]->{'sh_offset'}, $self->{'shdr'}->[$num]->{'sh_size'});

  return $section;
}


sub machname {
  my ($par) = @_;

  my $ret;
  my %name = (
	      0 => 'none',
	      1 => 'EM_M32, AT&T WE 32100',
	      2 => 'EM_SPARC, SUN SPARC',
	      3 => 'EM_386, Intel 80386',
	      4 => 'EM_68K, Motorola m68k family',
	      5 => 'EM_88K, Motorola m88k family',
	      6 => 'EM_486, Intel 80486',
	      7 => 'EM_860, Intel 80860',
	      8 => 'EM_MIPS, MIPS R3000 (officially, big-endian only)',
	      9 => 'EM_S370, IBM System/370',
	      10 => 'EM_MIPS_RS3_LE, MIPS R3000 little-endian (Oct 4 1999 Draft) Deprecated',
	      15 => 'EM_PARISC, HPPA',
	      17 => 'EM_VPP550, Fujitsu VPP500',
	      18 => 'EM_SPARC32PLUS, Suns "v8plus"',
	      19 => 'EM_960, Intel 80960',
	      20 => 'EM_PPC, PowerPC',
	      21 => 'EM_PPC64, 64-bit PowerPC',
	      22 => 'EM_S390, IBM S/390',
	      36 => 'EM_V800, NEC V800 series',
	      37 => 'EM_FR20, Fujitsu FR20',
	      38 => 'EM_RH32, TRW RH32',
	      39 => 'EM_MCORE, Motorola M*Core',
	      39 => 'EM_RCE, Old name for MCore',
	      40 => 'EM_ARM, ARM',
	      41 => 'EM_OLD_ALPHA, Digital Alpha',
	      42 => 'EM_SH, Renesas (formerly Hitachi) / SuperH SH',
	      43 => 'EM_SPARCV9, SPARC v9 64-bit',
	      44 => 'EM_TRICORE, Siemens Tricore embedded processor',
	      45 => 'EM_ARC, ARC Cores',
	      46 => 'EM_H8_300, Renesas (formerly Hitachi) H8/300',
	      47 => 'EM_H8_300H, Renesas (formerly Hitachi) H8/300H',
	      48 => 'EM_H8S, Renesas (formerly Hitachi) H8S',
	      49 => 'EM_H8_500, Renesas (formerly Hitachi) H8/500',
	      50 => 'EM_IA_64, Intel IA-64 Processor',
	      51 => 'EM_MIPS_X, Stanford MIPS-X',
	      52 => 'EM_COLDFIRE, Motorola Coldfire',
	      53 => 'EM_68HC12, Motorola M68HC12',
	      54 => 'EM_MMA, Fujitsu Multimedia Accelerator',
	      55 => 'EM_PCP, Siemens PCP',
	      56 => 'EM_NCPU, Sony nCPU embedded RISC processor',
	      57 => 'EM_NDR1, Denso NDR1 microprocesspr',
	      58 => 'EM_STARCORE, Motorola Star*Core processor',
	      59 => 'EM_ME16, Toyota ME16 processor',
	      60 => 'EM_ST100, STMicroelectronics ST100 processor',
	      61 => 'EM_TINYJ, Advanced Logic Corp. TinyJ embedded processor',
	      62 => 'EM_X86_64, Advanced Micro Devices X86-64 processor',
	      64 => 'EM_PDP10, Digital Equipment Corp. PDP-10',
	      65 => 'EM_PDP11, Digital Equipment Corp. PDP-11',
	      66 => 'EM_FX66, Siemens FX66 microcontroller',
	      67 => 'EM_ST9PLUS, STMicroelectronics ST9+ 8/16 bit microcontroller',
	      68 => 'EM_ST7, STMicroelectronics ST7 8-bit microcontroller',
	      69 => 'EM_68HC16, Motorola MC68HC16 Microcontroller',
	      70 => 'EM_68HC11, Motorola MC68HC11 Microcontroller',
	      71 => 'EM_68HC08, Motorola MC68HC08 Microcontroller',
	      72 => 'EM_68HC05, Motorola MC68HC05 Microcontroller',
	      73 => 'EM_SVX, Silicon Graphics SVx',
	      74 => 'EM_ST19, STMicroelectronics ST19 8-bit cpu',
	      75 => 'EM_VAX, Digital VAX',
	      76 => 'EM_CRIS, Axis Communications 32-bit embedded processor',
	      77 => 'EM_JAVELIN, Infineon Technologies 32-bit embedded cpu',
	      78 => 'EM_FIREPATH, Element 14 64-bit DSP processor',
	      79 => 'EM_ZSP, LSI Logic\'s 16-bit DSP processor',
	      80 => 'EM_MMIX, Donald Knuth\'s educational 64-bit processor',
	      81 => 'EM_HUANY, Harvard\'s machine-independent format',
	      82 => 'EM_PRISM, SiTera Prism',
	      83 => 'EM_AVR, Atmel AVR 8-bit microcontroller',
	      84 => 'EM_FR30, Fujitsu FR30',
	      85 => 'EM_D10V, Mitsubishi D10V',
	      86 => 'EM_D30V, Mitsubishi D30V',
	      87 => 'EM_V850, NEC v850',
	      88 => 'EM_M32R, Renesas M32R (formerly Mitsubishi M32R)',
	      89 => 'EM_MN10300, Matsushita MN10300',
	      90 => 'EM_MN10200, Matsushita MN10200',
	      91 => 'EM_PJ, picoJava',
	      92 => 'EM_OPENRISC, OpenRISC 32-bit embedded processor',
	      93 => 'EM_ARC_A5, ARC Cores Tangent-A5',
	      94 => 'EM_XTENSA, Tensilica Xtensa Architecture',
	      101 => 'EM_IP2K, Ubicom IP2022 micro controller',
	      103 => 'EM_CR, National Semiconductor CompactRISC',
	      105 => 'EM_MSP430, TI msp430 micro controller',
	      114 => 'EM_CRX, National Semiconductor CRX'
             );

  $ret = $name{$par};
  $ret = 'none' unless defined($ret);
	
  return $ret;
}


sub section_header_type {
  my ($par) = @_;

  my $ret;
  my %name = (
              0 => 'NULL',
              1 => 'PROGBITS',
              2 => 'SYMTAB',
              3 => 'STRTAB',
              4 => 'RELA',
              5 => 'HASH',
              6 => 'DYNAMIC',
              7 => 'NOTE',
              8 => 'NOBITS',
              9 => 'REL',
              10 => 'SHLIB',
              11 => 'DYNSYM',
              12 => 'NUM',
              0x60000000 => 'LOOS',
              0x6fffffff => 'HIOS',
              0x70000000 => 'LOPROC',
              0x7fffffff => 'HIPROC',
              0x80000000 => 'LOUSER',
              0xffffffff => 'HIUSER',
              0x6ffffffa => 'SUNW_move',
              0x6ffffffb => 'SUNW_COMDAT',
              0x6ffffffc => 'SUNW_syminfo',
              0x6ffffffd => 'SUNW/GNU_verdef',
              0x6ffffffe => 'SUNW/GNU_verneed',
              0x6fffffff => 'SUNW/GNU_versym'
             );

  $ret = $name{$par};
  $ret = 'none' unless defined($ret);
	
  return $ret;
}


sub section_header_flags {
  my ($par) = @_;
  my $ret = '';

  if ($par & 0x01) {
    $ret .= 'W';
  }
  if ($par & 0x02) {
    $ret .= 'A';
  }
  if ($par & 0x04) {
    $ret .= 'X';
  }
  if ($par & 0x0f000000) {
    $ret .= 'O';
  }
  if ($par & 0xf0000000) {
    $ret .= 'P';
  }

  return $ret;
}


sub hex_dump {
  my ($str, $beg, $len) = @_;

  my ($i, $line1, $line2, $char, $tp, $ret);
  my $n = 8;

  $tp = ref $str;
  $ret = '';

  if(!defined($beg)) {
    $beg = 0;
  }
  if(!defined($len)) {
    if($tp eq 'ARRAY') {
      $len = $#{@$str} + 1;
    }
    elsif($tp eq 'SCALAR') {
      $len = length $$str;
    }
    else {
      $len = length $str;
    }
  }

  $i = $beg % $n;
  if($i != 0) {
    $line1 = sprintf "%06i  %06x  ", $beg, $beg;
    $line1 .= '   ' x $i;
    $line2 = ' ' x $i;
  }
  for($i = $beg; $i < $len; $i++) {
    if($i % $n == 0) {
      $line1 = sprintf "%06i  %06x  ", $i, $i;
      $line2 = '';
    }
    if($tp eq 'ARRAY') {
      $char = chr($$str[$i]);
    }
    elsif($tp eq 'SCALAR') {
      $char = substr($$str, $i, 1);
    }
    else {
      $char = substr($str, $i, 1);
    }

    $line1 .= sprintf "%02x", ord($char);
    $line1 .= ' ';
    if($char =~ /[\ \w\d!\"§$%&\/()=?\\+*~#-_.:,;@äöüÄÖÜß<>|{}\[\]^]/) {
      $line2 .= $char;
    }
    else {
      $line2 .= '.';
    }
    if($i % $n == $n - 1) {
      $ret .= "$line1 - $line2\n";
    }
  }
  if(($len+$beg) % $n != 0) {
    $n = $n - ($len % $n);
    $line1 .= "   " x $n;
    $ret .= "$line1 - $line2\n";
  }
  return $ret;
}


return 1;
