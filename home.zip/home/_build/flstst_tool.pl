#! /usr/bin/perl -w

use ELF;
use Getopt::Long;

$Getopt::Long::ignorecase = 0;

my $poly;     # CRC polynomial, w/o leading 1 bit
my $width;    # Size of CRC check value in bits
my $crcinit = 0;    # Initialization value, defaut zero
my $refin   = 0;    # =true: Input data bytes to be reflected
my $refalg  = 0;    # =true: Use reflected algorithm
my $refout  = 0;    # =true: CRC to be reflected
my $xorcrc  = 0;    # Value to XOR crc with after calculation
my $patlen  = 8;    # Length of the input bit pattern, default 8
                    # Must be a power of 2
                    # Defines the size of the table:
                    # size of table is 1<<$patlen

my @CRCtable;
my $mask;
my $patmask;
my $refpoly;

sub prepare_crc() {
	$poly    = 0x04C11DB7;
	$width   = 32;
	$crcinit = 0xFFFFFFFF;
	$refin   = 1;
	$refout  = 1;
	$xorcrc  = 0xFFFFFFFF;

	$refpoly = reflect( $poly, $width );
	$crcinit = reflect( $crcinit, $width ) unless ( $refin ^ $refalg );

	unless ($refalg) {
		$refin  ^= 1;
		$refout ^= 1;
	}

	$mask    = mask($width);
	$patmask = ( 1 << $patlen ) - 1;

	for ( my $i = 0 ; $i < ( 1 << $patlen ) ; $i++ ) {
		$CRCtable[$i] = GetTabEntry($i);
	}
}

sub GetTabEntry {
	my $crc = $_[0];

	for ( my $i = 0 ; $i < $patlen ; $i++ ) {
		my $crcsave = $crc;

		$crc >>= 1;
		if ( $crcsave & 1 ) {
			$crc ^= $refpoly;
		}
	}

	return $crc;
}

sub mask {
	my $width = $_[0];

	return ( ( ( 1 << ( $width - 1 ) ) - 1 ) << 1 ) | 1;
}

sub reflect($$) {
	my $val  = $_[0];
	my $size = $_[1];

	my $t = $val;
	for ( my $i = $size - 1 ; $i >= 0 ; $i-- ) {
		if ( $t & 1 ) {
			$val |= ( 1 << $i );
		}
		else {
			$val &= ~1 << $i;
		}
		$t >>= 1;
	}

	return $val;
}

sub opts() {
	$result = Getopt::Long::GetOptions(
		"in=s"    => \$file,
		"out=s"   => \$outfile,
		"undef=s" => \$undefval,
		"sym=s"   => \@symlist
	);

	$abort = 0;

	if ( !defined($file) ) {
		$abort = 1;
		print "No '--in' defined\n";
	}

	if ( !defined($outfile) ) {
		$outfile = $file;
		$outfile =~ s/\.(.*)$/_rominfo\.$1/;
	}

	$crc_type = 'CRC-32';

	if ( !defined($undefval) ) {
		$undefval = '0xFF';
	}

	$undefval = hex($undefval);

	if ( $abort || $result == 0 ) {
		die "dying for given reason\n";
	}
}

sub __chksum($$$) {
	my ( $e, $beg, $end ) = @_;

	my $crc = $crcinit;

	$e->set_read_addr( $beg, $undefval );
	for ( my $i = 0 ; $i < ( $end - $beg ) ; $i++ ) {
		my $inpbyte = $e->get_byte();

		my $byte = $inpbyte;
		$byte = reflect( $inpbyte, 8 ) if ($refin);
		$crc ^= $byte;

		for ( my $j = 0 ; $j < 8 ; $j += $patlen ) {
			my $idx = $crc & $patmask;

			$crc >>= $patlen;
			$crc ^= $CRCtable[$idx];
		}
	}

	$crc = reflect( $crc, $width ) if ($refout);
	$crc ^= $xorcrc;

	return $crc;
}

sub chksum($$$) {
	my ( $e, $beg, $end ) = @_;

	my $crc = $crcinit;
	my $rom = $e->get_mem( $beg, $end );

	foreach my $q ( @{$rom} ) {
		my $bb = $$q[0];
		my $ee = $$q[1];
		my $ss = $$q[2];

		if ( length($ss) != 0 ) {
			for ( my $i = 0 ; $i < ( $ee - $bb ) ; $i++ ) {
				my $inpbyte = ord( substr( $ss, $i, 1 ) );

				my $byte = $inpbyte;
				$byte = reflect( $inpbyte, 8 ) if ($refin);
				$crc ^= $byte;

				for ( my $j = 0 ; $j < 8 ; $j += $patlen ) {
					my $idx = $crc & $patmask;

					$crc >>= $patlen;
					$crc ^= $CRCtable[$idx];
				}
			}
		}
		else {
			for ( my $i = 0 ; $i < ( $ee - $bb ) ; $i++ ) {
				$inpbyte = $undefval;

				my $byte = $inpbyte;
				$byte = reflect( $inpbyte, 8 ) if ($refin);
				$crc ^= $byte;

				for ( my $j = 0 ; $j < 8 ; $j += $patlen ) {
					my $idx = $crc & $patmask;

					$crc >>= $patlen;
					$crc ^= $CRCtable[$idx];
				}
			}
		}
	}

	$crc = reflect( $crc, $width ) if ($refout);
	$crc ^= $xorcrc;

	return $crc;
}

sub test_crc {
	my $crc = $crcinit;

    my $ss = "abcdefghijklmnopqrstuvwxyz!\xff\x80\x00\x01ABC";

	for ( my $i = 0 ; $i < length($ss) ; $i++ ) {
		my $inpbyte = ord( substr( $ss, $i, 1 ) );

		my $byte = $inpbyte;
		$byte = reflect( $inpbyte, 8 ) if ($refin);
		$crc ^= $byte;

		for ( my $j = 0 ; $j < 8 ; $j += $patlen ) {
			my $idx = $crc & $patmask;

			$crc >>= $patlen;
			$crc ^= $CRCtable[$idx];
		}
	}

    return $crc;
}

@symlist = ();
opts();

prepare_crc();

my $tst = test_crc();
if($tst != 0x2E750B8E) {
	die(sprintf "internal CRC calculation failed, got 0x%08x, expected 0x2E750B8E.\n", $tst);
}

print "-------------\n";
print "Input File $file\n";
print "Output File $outfile\n";
print sprintf( "Assuming 0x%02X for gaps\n", $undefval );
print "CRC $crc_type\n";

my $e = ELF->new($file);

my $ptrsize;
if ( $$e{e_data} == 1 ) {

	# LITTLE_ENDIAN
}
elsif ( $$e{e_data} == 2 ) {

	# BIG_ENDIAN
}
else {
	die "Endianness incorrect\n";
}

$mch = $$e{e_machine};
print "Machine Type $mch\n";

# check machine types PowerPC, NEC V850, ARM and TriCore
if ( $mch == 20 or $mch == 36 or $mch == 40 or $mch == 44 ) {
	$ptrsize = 4;
}
else {
	warn "don't know pointer size for machine type, assuming 4\n";
    $ptrsize = 4;
}

foreach $sym (@symlist) {
	my $ri;
	$ri = $e->get_symbol($sym);
	if ( not defined($ri) ) {
		$ri = $e->get_symbol( '_' . $sym );
	}
	if ( not defined($ri) ) {
		print "Symbol $sym not found.\n";
		die;
	}

	$sz   = $$ri{st_size};
	$addr = $$ri{st_value};
	printf "\nRom area description for $sym at address %08X (length $sz)\n",
	  $addr;

	$exp_sz = 12 + 2 * $ptrsize;
	if ( $sz != $exp_sz ) {
		die "Expected ROM descriptor size $exp_sz, got $sz\n";
	}

	$magic = $e->get_val_at( $addr, 4 );
	printf "Magic number 0x%08X\n", $magic;

	if ( $magic != 0x31415926 ) {
		die "Magic number does not contain the expected value\n";
	}

	$version = $e->get_val_at( $addr + 4, 4 );
	print "Rom Information version number $version\n";
	if ( $version == 1 ) {
		$beg = $e->get_val_at( $addr + 8,            $ptrsize );
		$ed  = $e->get_val_at( $addr + 8 + $ptrsize, $ptrsize );

		if ( $addr + $exp_sz > $beg and $addr < $ed ) {
			printf
			  "Symbol $sym at address 0x%08x inside area 0x%08X - 0x%08X\n",
			  $addr, $beg, $ed;
			die;
		}

		printf "creating checksum from 0x%08X to 0x%08X", $beg, $ed;
		$chk = chksum( $e, $beg, $ed );
		printf "  =>  0x%08X\n", $chk;
		$e->set_val_at( $addr + 8 + 2 * $ptrsize, $chk, 4 );
	}
	elsif ( $version == 2 ) {

	}
	else {
		die "Rom Information version number not (yet) handled by PC tool.\n";
	}
}

$e->save($outfile);

print "Saved patched ELF file at <$outfile>\n";

